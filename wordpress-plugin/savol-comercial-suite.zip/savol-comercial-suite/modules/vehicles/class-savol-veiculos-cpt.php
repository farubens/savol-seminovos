<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('Savol_Veiculos_CPT')) :

final class Savol_Veiculos_CPT {
    private const POST_TYPE = 'veiculo';
    private const SELL_YOUR_CAR_POST_TYPE = 'venda_carro_lead';
    private const SELLER_ROLE = 'vendedor_savol';
    private const SELLER_ROLE_LABEL = 'Vendedor SAVOL';
    private const SELLER_CAPABILITY = 'savol_venda_seu_carro_vendedor';
    private const SELLER_MENU_SLUG = 'savol-venda-seu-carro-vendedores';
    private const SELLER_LEADS_MENU_SLUG = 'savol-vendedor-venda-seu-carro';
    private const ASSIGNED_SELLER_META = '_savol_vsc_assigned_seller_id';
    private const GESTOR_ROLE = 'gestor_savol';
    private const MANAGE_DELEGATION_CAPABILITY = 'savol_manage_venda_seu_carro_delegation';
    private const SELLER_USER_CAPS = [
        'list_users',
        'create_users',
        'edit_users',
        'promote_users',
    ];
    private const PUBLIC_SITE_URL = 'https://savolseminovos.com.br';
    private const SELL_YOUR_CAR_PUBLIC_PATH = '/venda-seu-carro';
    private const SELL_LEAD_CAPS = [
        'edit_post' => 'edit_venda_carro_lead',
        'read_post' => 'read_venda_carro_lead',
        'delete_post' => 'delete_venda_carro_lead',
        'edit_posts' => 'edit_venda_carro_leads',
        'edit_others_posts' => 'edit_others_venda_carro_leads',
        'publish_posts' => 'publish_venda_carro_leads',
        'read_private_posts' => 'read_private_venda_carro_leads',
        'delete_posts' => 'delete_venda_carro_leads',
        'delete_private_posts' => 'delete_private_venda_carro_leads',
        'delete_published_posts' => 'delete_published_venda_carro_leads',
        'delete_others_posts' => 'delete_others_venda_carro_leads',
        'edit_private_posts' => 'edit_private_venda_carro_leads',
        'edit_published_posts' => 'edit_published_venda_carro_leads',
        'create_posts' => 'do_not_allow',
    ];
    private const NONCE_ACTION = 'savol_veiculos_save_meta';
    private const NONCE_NAME = 'savol_veiculos_nonce';
    private const AUTOSYNC_OPTION = 'savol_veiculos_autosync_token';
    private const AUTOSYNC_LAST_ERROR_OPTION = 'savol_veiculos_autosync_last_error';
    private const AUTOSYNC_PROGRESS_OPTION = 'savol_veiculos_autosync_progress';
    private const AUTOSYNC_ENDPOINT_OPTION = 'savol_veiculos_autosync_endpoint';
    private const AUTOSYNC_ENTITY_IDS_OPTION = 'savol_veiculos_autosync_entity_ids';
    private const AUTOSYNC_CNPJS_OPTION = 'savol_veiculos_autosync_cnpjs';
    private const APOLO_ALLOWED_SITUATIONS_OPTION = 'savol_apolo_allowed_situations';
    private const APOLO_ALLOWED_COMPANY_RESELLERS_OPTION = 'savol_apolo_allowed_company_resellers';
    private const AUTOSYNC_LAST_API_CALL_OPTION = 'savol_veiculos_autosync_last_api_call';
    private const AUTOSYNC_API_LOCK_OPTION = 'savol_veiculos_autosync_api_lock';
    private const AUTOSYNC_API_MIN_INTERVAL = 180;
    private const AUTOSYNC_API_LOCK_TTL = 180;
    private const AUTOSYNC_PROGRESS_STALE_TTL = 300;
    private const AUTOSYNC_RECURRING_HOOK = 'savol_veiculos_autosync_recurring';
    private const AUTOSYNC_RECURRING_SCHEDULE = 'savol_every_40_minutes';
    private const AUTOSYNC_RECURRING_INTERVAL = 2400;
    private const AUTOSYNC_ENDPOINT_DEFAULT = 'https://sync-backend.autoavaliar.com.br/vehicle/stock';
    private const AUTOSYNC_BATCH_OPTION = 'savol_veiculos_autosync_batch';
    private const AUTOSYNC_BATCH_SIZE = 10;
    private const AUTOSYNC_BATCH_TIME_LIMIT = 45;
    private const DASHBOARD_OPERATIONS_OPTION = 'savol_dashboard_operations_log';
    private const DASHBOARD_OPERATIONS_MAX_ITEMS = 5000;
    private const APOLO_STOCK_URL = 'https://drive.google.com/uc?export=download&id=1zyCN8JXUa5kUD-kjeIsO49y7J3wRmFd4';
    private const APOLO_ALLOWED_COMPANY_RESELLERS_DEFAULT = [
        '16:1',
        '17:1',
        '1:1',
        '1:2',
        '14:1',
        '5:1',
        '14:3',
        '14:4',
    ];
    private const APOLO_ALLOWED_SITUATIONS_DEFAULT = ['ES', 'ED'];
    private const APOLO_DRAFT_REASONS = [
        'Não cadastrado no APOLO',
        'Sem dados no AutoSync',
        'Sem preco de venda no APOLO',
        'Empresa não autorizada no APOLO',
        'Situação não permitida no APOLO',
        'Preço de compra acima do preço de venda',
    ];
    private const PRICE_OVERRIDE_REASON = 'Preço de compra acima do preço de venda';
    private const PRICE_OVERRIDE_REASON_META = 'publicacao_preco_justificativa_motivo';
    private const PRICE_OVERRIDE_DETAILS_META = 'publicacao_preco_justificativa_detalhes';
    private const PRICE_OVERRIDE_USER_ID_META = 'publicacao_preco_usuario_id';
    private const PRICE_OVERRIDE_USER_NAME_META = 'publicacao_preco_usuario_nome';
    private const PRICE_OVERRIDE_DATE_META = 'publicacao_preco_data';
    private const PRICE_OVERRIDE_NOTICE_TRANSIENT = 'savol_preco_publicacao_notice_';
    private const MANUAL_STATUS_LOCK_META = 'savol_status_manual_lock';
    private const PHOTO_IMPORT_TIMEOUT = 5;
    private const SELL_YOUR_CAR_MAX_PHOTO_SIZE = 8388608;
    private const SELL_YOUR_CAR_REST_NAMESPACE = 'savol/v1';
    private const SELL_YOUR_CAR_REST_ROUTE = '/venda-seu-carro';
    // Legacy list kept for backward reference. The active site flow uses sell_your_car_photo_fields().
    private const SELL_YOUR_CAR_PHOTO_FIELDS = [
        'photo_front' => 'FOTO FRENTE VEÍCULO',
        'photo_leftSide' => 'Lateral esquerda',
        'photo_rightSide' => 'Lateral direita',
        'photo_rear' => 'Traseira',
        'photo_dashboard' => 'Painel',
        'photo_odometer' => 'Odômetro',
        'photo_spare' => 'Estepe',
        'photo_trunk' => 'Porta-malas',
        'photo_roof' => 'Teto',
        'photo_tire' => 'Pneu',
        'photo_engine' => 'Motor',
        'photo_chassis' => 'Chassi',
    ];
    private const UNIDADE_CONTACTS = [
        'unidade savol toyota santo andre' => [
            'telefone' => '(11) 4979-6000',
            'whatsapp' => '(11) 4979-6000',
            'endereco' => 'Av. Artur de Queiros, 469 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol toyota sao bernardo do campo' => [
            'telefone' => '(11) 3809-1000',
            'whatsapp' => '(11) 4979-6000',
            'endereco' => 'Av. Senador Vergueiro, 2332 - Anchieta, Sao Bernardo do Campo - SP, 09600-004',
        ],
        'unidade savol toyota maua' => [
            'telefone' => '',
            'whatsapp' => '(11) 4979-6000',
            'endereco' => 'Av. Joao Ramalho, 1853 - Vila Noemia, Maua - SP, 09371-520',
        ],
        'unidade savol toyota praia grande' => [
            'telefone' => '(13) 3476-7000',
            'whatsapp' => '(11) 4979-6000',
            'endereco' => 'Av. Guilhermina, 1021 - Guilhermina, Praia Grande - SP, 11701-500',
        ],
        'unidade savol toyota dom pedro ii' => [
            'telefone' => '(11) 4979-6000',
            'whatsapp' => '(11) 4979-6000',
            'endereco' => 'Av. Dom Pedro II, 2500 - Santo Andre - SP, 09080110',
        ],
        'unidade savol volkswagen santo andre' => [
            'telefone' => '(11) 4435-1000',
            'whatsapp' => '(11) 4435-1000',
            'endereco' => 'Av. Artur de Queiros, 701 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol volkswagen pereira barreto' => [
            'telefone' => '(11) 4435-1000',
            'whatsapp' => '(11) 4435-1000',
            'endereco' => 'Av. Pereira Barreto, 888 - Paraiso - Santo Andre - SP',
        ],
        'unidade savol peugeot santo andre' => [
            'telefone' => '(11) 3381-1000',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Artur de Queiros, 426 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol peugeot sao bernardo do campo' => [
            'telefone' => '(11) 3381-1000',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Senador Vergueiro, 2302 - Anchieta, Sao Bernardo do Campo - SP, 09600-004',
        ],
        'unidade savol peugeot sao caetano do sul' => [
            'telefone' => '(11) 3381-1000',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Goias, 2155 - Santo Antonio, Sao Caetano do Sul - SP, 09521-300',
        ],
        'unidade savol citroen santo andre' => [
            'telefone' => '(11) 3381-1001',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Artur de Queiros, 424 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol citroen sao bernardo do campo' => [
            'telefone' => '(11) 3381-1001',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Senador Vergueiro, 2302 - Rudge Ramos, Sao Bernardo do Campo - SP, 09600-004',
        ],
        'unidade savol citroen sao caetano do sul' => [
            'telefone' => '(11) 3381-1001',
            'whatsapp' => '(11) 3381-1005',
            'endereco' => 'Av. Goias, 2155 - Santo Antonio, Sao Caetano do Sul - SP, 09521-300',
        ],
        'unidade savol fiat santo andre' => [
            'telefone' => '(11) 3319-1000',
            'whatsapp' => '(11) 3319-1000',
            'endereco' => 'Av. Artur de Queiros, 414 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol fiat sao caetano do sul' => [
            'telefone' => '(11) 3319-1000',
            'whatsapp' => '(11) 3319-1000',
            'endereco' => 'Av. Goias, 2145 - Barcelona, Sao Caetano do Sul - SP, 09550-001',
        ],
        'unidade savol fiat sao bernardo do campo' => [
            'telefone' => '(11) 3319-1000',
            'whatsapp' => '(11) 3319-1000',
            'endereco' => 'Av. Senador Vergueiro, 2348 - Anchieta, Sao Bernardo do Campo - SP, 09600-004',
        ],
        'unidade savol kia santo andre' => [
            'telefone' => '(11) 3381-1010',
            'whatsapp' => '(11) 4331-1000',
            'endereco' => 'Av. Artur de Queiros, 727 - Casa Branca, Santo Andre - SP, 09015-510',
        ],
        'unidade savol kia sao paulo' => [
            'telefone' => '(11) 3381-1010',
            'whatsapp' => '(11) 4331-1000',
            'endereco' => 'Av. Nazare, 444 - Ipiranga, Sao Paulo - SP, 04262-000',
        ],
        'unidade savol mg motor' => [
            'telefone' => '(11) 3809-1010',
            'whatsapp' => '(11) 3809-1010',
            'endereco' => 'Av. Goias, 3048 - Santo Antonio, Sao Caetano do Sul - SP, 09521-310',
        ],
        'unidade savol jetour' => [
            'telefone' => '(11) 3319-1010',
            'whatsapp' => '(11) 3319-1010',
            'endereco' => 'Av. D. Pedro II, 2550 - Bairro Campestre - Santo Andre - SP',
        ],
        'unidade savol jetour sao caetano do sul' => [
            'telefone' => '(11) 3319-1010',
            'whatsapp' => '(11) 3319-1010',
            'endereco' => 'Alameda Terracota, 545 - Piso 1 (Terreo) - Ceramica, Sao Caetano do Sul - SP, 09531-190',
        ],
    ];

    /**
     * Campos de metadados do veiculo.
     * type: text|number|boolean
     */
    private static function fields(): array {
        return [
            'condicao' => ['label' => 'Condicao', 'type' => 'text'],
            'placa' => ['label' => 'Placa', 'type' => 'text'],
            'renavam' => ['label' => 'Renavam', 'type' => 'text'],
            'chassi_vin' => ['label' => 'Chassi (VIN)', 'type' => 'text'],
            'ano' => ['label' => 'Ano', 'type' => 'number'],
            'ano_modelo' => ['label' => 'Ano modelo', 'type' => 'number'],
            'km' => ['label' => 'KM', 'type' => 'number'],
            'preco' => ['label' => 'Preco', 'type' => 'number'],
            'status' => ['label' => 'Status', 'type' => 'text'],
            'combustivel' => ['label' => 'Combustivel', 'type' => 'text'],
            'cambio' => ['label' => 'Cambio', 'type' => 'text'],
            'categoria' => ['label' => 'Categoria', 'type' => 'text'],
            'carroceria' => ['label' => 'Carroceria', 'type' => 'text'],
            'portas' => ['label' => 'Portas', 'type' => 'number'],
            'lugares' => ['label' => 'Lugares', 'type' => 'number'],
            'tracao' => ['label' => 'Tracao', 'type' => 'text'],
            'motor' => ['label' => 'Motor', 'type' => 'text'],
            'potencia_cv' => ['label' => 'Potencia (cv)', 'type' => 'number'],
            'torque_nm' => ['label' => 'Torque (Nm)', 'type' => 'number'],
            'qtd_donos' => ['label' => 'Qtd. de donos', 'type' => 'number'],
            'identificador_externo' => ['label' => 'Identificador externo', 'type' => 'text'],
            'galeria_fotos' => ['label' => 'Galeria de fotos', 'type' => 'gallery'],
            'autosync_foto_destaque_url' => ['label' => 'Foto de destaque AutoSync', 'type' => 'text'],
            'autosync_galeria_urls' => ['label' => 'Galeria AutoSync (URLs)', 'type' => 'textarea'],
            'quantidade_fotos' => ['label' => 'Quantidade de fotos', 'type' => 'number'],
            'ipva_pago' => ['label' => 'IPVA pago', 'type' => 'boolean'],
            'licenciado' => ['label' => 'Licenciado', 'type' => 'boolean'],
            'blindado' => ['label' => 'Blindado', 'type' => 'boolean'],
            'negociacao' => ['label' => 'Em negociacao', 'type' => 'boolean'],
            'repasse' => ['label' => 'Repasse', 'type' => 'boolean'],
            'transito' => ['label' => 'Transito', 'type' => 'boolean'],
            'dias_estoque' => ['label' => 'Dias de estoque', 'type' => 'number'],
            'dias_proposta' => ['label' => 'Dias de proposta', 'type' => 'number'],
        ];
    }

    private static function rest_fields(): array {
        return self::fields() + [
            'apolo_val_compra' => ['label' => 'Custo APOLO', 'type' => 'number'],
            'apolo_valor_venda' => ['label' => 'Venda APOLO', 'type' => 'number'],
            'fipe' => ['label' => 'FIPE', 'type' => 'number'],
        ];
    }

    /**
     * Taxonomias associadas ao veiculo.
     */
    private static function taxonomies(): array {
        return [
            'veiculo_marca' => ['label' => 'Marca', 'hierarchical' => true],
            'veiculo_modelo' => ['label' => 'Modelo', 'hierarchical' => true],
            'veiculo_versao' => ['label' => 'Versao', 'hierarchical' => false],
            'veiculo_cor' => ['label' => 'Cor', 'hierarchical' => false],
            'veiculo_cidade' => ['label' => 'Cidade', 'hierarchical' => false],
            'veiculo_uf' => ['label' => 'UF', 'hierarchical' => false],
            'veiculo_unidade' => ['label' => 'Unidade', 'hierarchical' => false],
            'status-loja' => ['label' => 'Status loja', 'hierarchical' => false],
            'veiculo_informacao_destaque' => ['label' => 'Informação de destaque', 'hierarchical' => false],
            'veiculo_destaque_secundario' => ['label' => 'Destaque secundario', 'hierarchical' => false],
        ];
    }

    public static function init(): void {
        add_action('init', [__CLASS__, 'sync_seller_role'], 30);
        add_action('init', [__CLASS__, 'register_post_type']);
        add_action('init', [__CLASS__, 'register_taxonomies']);
        add_action('init', [__CLASS__, 'register_meta']);
        add_action('init', [__CLASS__, 'register_sell_your_car_api_alias']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_routes']);
        add_action('transition_post_status', [__CLASS__, 'capture_vehicle_publish_user'], 10, 3);
        add_filter('query_vars', [__CLASS__, 'register_sell_your_car_query_vars']);
        add_filter('wp_insert_post_data', [__CLASS__, 'enforce_price_override_before_insert'], 10, 2);
        add_action('parse_request', [__CLASS__, 'handle_sell_your_car_api_alias_request']);
        add_action('template_redirect', [__CLASS__, 'handle_sell_your_car_api_alias']);
        add_action('admin_notices', [__CLASS__, 'render_price_override_admin_notice']);
        add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes']);
        add_action('save_post_' . self::POST_TYPE, [__CLASS__, 'save_meta']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_assets']);
        add_action('admin_menu', [__CLASS__, 'register_admin_menu'], 1001);
        add_action('admin_init', [__CLASS__, 'restrict_seller_admin']);
        add_filter('user_has_cap', [__CLASS__, 'grant_runtime_caps'], 20, 4);
        add_action('admin_post_savol_vsc_create_seller', [__CLASS__, 'handle_create_seller']);
        add_action('admin_post_savol_vsc_assign_lead', [__CLASS__, 'handle_assign_lead']);
        add_action('admin_post_savol_vsc_email_lead', [__CLASS__, 'handle_email_lead']);
        add_action('admin_post_savol_vsc_export_pdf', [__CLASS__, 'handle_export_pdf']);
        add_action('admin_post_savol_veiculos_save_autosync', [__CLASS__, 'handle_save_autosync']);
        add_action('admin_post_savol_veiculos_run_autosync', [__CLASS__, 'handle_run_autosync']);
        add_action('admin_post_savol_veiculos_refresh_unidades', [__CLASS__, 'handle_refresh_unidades']);
        add_action('admin_post_savol_veiculos_import_json', [__CLASS__, 'handle_import_json']);
        add_action('wp_ajax_savol_veiculos_run_autosync', [__CLASS__, 'handle_run_autosync_ajax']);
        add_action('wp_ajax_savol_veiculos_autosync_progress', [__CLASS__, 'handle_autosync_progress_ajax']);
        add_action('savol_veiculos_run_autosync_cron', [__CLASS__, 'run_autosync_cron_job']);
        add_action(self::AUTOSYNC_RECURRING_HOOK, [__CLASS__, 'run_recurring_autosync_job']);
        add_filter('cron_schedules', [__CLASS__, 'register_cron_schedules']);
        add_action('init', [__CLASS__, 'ensure_autosync_schedule'], 100);
        add_action('restrict_manage_posts', [__CLASS__, 'render_vehicle_admin_filters']);
        add_action('pre_get_posts', [__CLASS__, 'apply_vehicle_admin_filters']);
        add_filter('manage_edit-' . self::POST_TYPE . '_sortable_columns', [__CLASS__, 'register_vehicle_sortable_columns']);
        add_filter('posts_clauses', [__CLASS__, 'apply_vehicle_taxonomy_ordering'], 20, 2);
        add_filter('manage_' . self::SELL_YOUR_CAR_POST_TYPE . '_posts_columns', [__CLASS__, 'register_sell_your_car_columns']);
        add_action('manage_' . self::SELL_YOUR_CAR_POST_TYPE . '_posts_custom_column', [__CLASS__, 'render_sell_your_car_column'], 10, 2);
        add_action('veiculo_cor_add_form_fields', [__CLASS__, 'render_cor_add_fields']);
        add_action('veiculo_cor_edit_form_fields', [__CLASS__, 'render_cor_edit_fields']);
        add_action('created_veiculo_cor', [__CLASS__, 'save_cor_term_meta']);
        add_action('edited_veiculo_cor', [__CLASS__, 'save_cor_term_meta']);
        add_action('veiculo_marca_add_form_fields', [__CLASS__, 'render_marca_add_fields']);
        add_action('veiculo_marca_edit_form_fields', [__CLASS__, 'render_marca_edit_fields']);
        add_action('created_veiculo_marca', [__CLASS__, 'save_marca_term_meta']);
        add_action('edited_veiculo_marca', [__CLASS__, 'save_marca_term_meta']);
        add_action('veiculo_unidade_add_form_fields', [__CLASS__, 'render_unidade_add_fields']);
        add_action('veiculo_unidade_edit_form_fields', [__CLASS__, 'render_unidade_edit_fields']);
        add_action('created_veiculo_unidade', [__CLASS__, 'save_unidade_term_meta']);
        add_action('edited_veiculo_unidade', [__CLASS__, 'save_unidade_term_meta']);
    }

    public static function activate(): void {
        self::register_post_type();
        self::register_taxonomies();
        self::register_sell_your_car_api_alias();
        self::sync_seller_role();
        self::ensure_autosync_schedule();
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook(self::AUTOSYNC_RECURRING_HOOK);
        wp_clear_scheduled_hook('savol_veiculos_run_autosync_cron');
        flush_rewrite_rules();
    }

    public static function register_cron_schedules(array $schedules): array {
        if (!isset($schedules[self::AUTOSYNC_RECURRING_SCHEDULE])) {
            $schedules[self::AUTOSYNC_RECURRING_SCHEDULE] = [
                'interval' => self::AUTOSYNC_RECURRING_INTERVAL,
                'display' => 'A cada 40 minutos',
            ];
        }
        return $schedules;
    }

    public static function ensure_autosync_schedule(): void {
        if (!wp_next_scheduled(self::AUTOSYNC_RECURRING_HOOK)) {
            wp_schedule_event(
                time() + self::AUTOSYNC_RECURRING_INTERVAL,
                self::AUTOSYNC_RECURRING_SCHEDULE,
                self::AUTOSYNC_RECURRING_HOOK
            );
        }
    }

    public static function sync_seller_role(): void {
        $caps = [
            'read' => true,
            self::SELLER_CAPABILITY => true,
        ];

        $seller = get_role(self::SELLER_ROLE);
        if (!$seller) {
            add_role(self::SELLER_ROLE, self::SELLER_ROLE_LABEL, $caps);
        } else {
            foreach ($caps as $cap => $grant) {
                $seller->add_cap($cap, $grant);
            }
        }

        $admin = get_role('administrator');
        if ($admin) {
            $admin->add_cap(self::SELLER_CAPABILITY);
            $admin->add_cap(self::MANAGE_DELEGATION_CAPABILITY);
            foreach (self::SELLER_USER_CAPS as $cap) {
                $admin->add_cap($cap);
            }
            foreach (self::sell_lead_role_caps() as $cap) {
                $admin->add_cap($cap);
            }
        }

        $gestor = get_role(self::GESTOR_ROLE);
        if ($gestor) {
            $gestor->add_cap('read');
            $gestor->add_cap(self::MANAGE_DELEGATION_CAPABILITY);
            $gestor->add_cap('savol_access_dashboard');
            foreach (self::SELLER_USER_CAPS as $cap) {
                $gestor->add_cap($cap);
            }
            foreach (self::sell_lead_role_caps() as $cap) {
                $gestor->add_cap($cap);
            }
        }
    }

    private static function sell_lead_role_caps(): array {
        return array_values(array_unique(array_filter(self::SELL_LEAD_CAPS, static function ($cap): bool {
            return is_string($cap) && $cap !== 'do_not_allow';
        })));
    }

    public static function grant_runtime_caps(array $allcaps, array $caps, array $args, \WP_User $user): array {
        $has_gestor_access = in_array(self::GESTOR_ROLE, (array) $user->roles, true)
            || !empty($user->allcaps['savol_access_dashboard'])
            || !empty($user->allcaps[self::MANAGE_DELEGATION_CAPABILITY])
            || !empty($user->allcaps['edit_venda_carro_leads']);

        if ($has_gestor_access) {
            $allcaps['read'] = true;
            $allcaps['upload_files'] = true;
            $allcaps['list_users'] = true;
            $allcaps['create_users'] = true;
            $allcaps['edit_users'] = true;
            $allcaps['promote_users'] = true;
            $allcaps['savol_access_dashboard'] = true;
            $allcaps[self::MANAGE_DELEGATION_CAPABILITY] = true;
            foreach (self::SELLER_USER_CAPS as $cap) {
                $allcaps[$cap] = true;
            }
            foreach (self::sell_lead_role_caps() as $cap) {
                $allcaps[$cap] = true;
            }
        }

        if (in_array(self::SELLER_ROLE, (array) $user->roles, true)) {
            $allcaps['read'] = true;
            $allcaps[self::SELLER_CAPABILITY] = true;
        }

        return $allcaps;
    }

    public static function register_post_type(): void {
        $labels = [
            'name' => 'Veiculos',
            'singular_name' => 'Veiculo',
            'menu_name' => 'Veiculos',
            'add_new' => 'Adicionar novo',
            'add_new_item' => 'Adicionar novo veiculo',
            'edit_item' => 'Editar veiculo',
            'new_item' => 'Novo veiculo',
            'view_item' => 'Ver veiculo',
            'search_items' => 'Buscar veiculos',
            'not_found' => 'Nenhum veiculo encontrado',
            'not_found_in_trash' => 'Nenhum veiculo na lixeira',
        ];

        register_post_type(self::POST_TYPE, [
            'labels' => $labels,
            'public' => true,
            'show_in_rest' => true,
            'menu_icon' => 'dashicons-car',
            // Necessario para garantir exposicao dos post meta no WP REST API.
            'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
            'has_archive' => true,
            'rewrite' => ['slug' => 'veiculos'],
        ]);

        register_post_type(self::SELL_YOUR_CAR_POST_TYPE, [
            'labels' => [
                'name' => 'Venda Seu Carro',
                'singular_name' => 'Lead Venda Seu Carro',
                'menu_name' => 'Venda Seu Carro',
                'add_new' => 'Adicionar novo',
                'add_new_item' => 'Adicionar novo lead',
                'edit_item' => 'Ver lead',
                'new_item' => 'Novo lead',
                'view_item' => 'Ver lead',
                'search_items' => 'Buscar leads',
                'not_found' => 'Nenhum lead encontrado',
                'not_found_in_trash' => 'Nenhum lead na lixeira',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_icon' => 'dashicons-clipboard',
            'menu_position' => 27,
            'show_in_rest' => false,
            'supports' => ['title', 'editor', 'custom-fields'],
            'capability_type' => ['venda_carro_lead', 'venda_carro_leads'],
            'capabilities' => self::SELL_LEAD_CAPS,
            'map_meta_cap' => true,
        ]);
    }

    public static function register_taxonomies(): void {
        foreach (self::taxonomies() as $slug => $config) {
            register_taxonomy($slug, [self::POST_TYPE], [
                'labels' => [
                    'name' => $config['label'],
                    'singular_name' => $config['label'],
                ],
                'public' => true,
                'show_admin_column' => true,
                'show_in_rest' => true,
                'hierarchical' => $config['hierarchical'],
                'rewrite' => ['slug' => $slug],
            ]);
        }
    }

    public static function register_meta(): void {
        foreach (self::rest_fields() as $key => $field) {
            register_post_meta(self::POST_TYPE, $key, [
                'single' => true,
                'show_in_rest' => true,
                'type' => $field['type'] === 'boolean' ? 'boolean' : ($field['type'] === 'number' ? 'number' : 'string'),
                // Leitura liberada para consumo headless/publico sem 401/403 em GET.
                'auth_callback' => '__return_true',
                'sanitize_callback' => static function($value) use ($field) {
                    if ($field['type'] === 'boolean') {
                        return (bool) $value;
                    }
                    if ($field['type'] === 'number') {
                        return is_numeric($value) ? (float) $value : 0;
                    }
                    if ($field['type'] === 'gallery') {
                        return sanitize_text_field((string) $value);
                    }
                    if ($field['type'] === 'textarea') {
                        return sanitize_textarea_field((string) $value);
                    }
                    return sanitize_text_field((string) $value);
                },
            ]);
        }

        register_post_meta(self::POST_TYPE, self::MANUAL_STATUS_LOCK_META, [
            'single' => true,
            'show_in_rest' => true,
            'type' => 'boolean',
            'auth_callback' => '__return_true',
            'sanitize_callback' => static function($value) {
                return (bool) $value;
            },
        ]);
    }

    public static function add_meta_boxes(): void {
        add_meta_box(
            'savol_veiculos_dados',
            'Dados do veiculo',
            [__CLASS__, 'render_meta_box'],
            self::POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'savol_veiculos_justificativa_publicacao',
            'Justificativa de publicacao',
            [__CLASS__, 'render_price_override_meta_box'],
            self::POST_TYPE,
            'normal',
            'default'
        );

        add_meta_box(
            'savol_venda_carro_dados',
            'Dados do lead',
            [__CLASS__, 'render_sell_your_car_meta_box'],
            self::SELL_YOUR_CAR_POST_TYPE,
            'normal',
            'high'
        );

        add_meta_box(
            'savol_venda_carro_delegacao',
            'Delegacao comercial',
            [__CLASS__, 'render_sell_your_car_assignment_meta_box'],
            self::SELL_YOUR_CAR_POST_TYPE,
            'side',
            'high'
        );
    }

    public static function render_meta_box(\WP_Post $post): void {
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);

        echo '<div class="savol-veiculos-grid">';

        foreach (self::fields() as $key => $field) {
            $value = get_post_meta($post->ID, $key, true);
            echo '<div class="savol-field">';
            echo '<label for="' . esc_attr($key) . '">' . esc_html($field['label']) . '</label>';

            if ($field['type'] === 'boolean') {
                $checked = !empty($value) ? ' checked' : '';
                echo '<label class="savol-switch">';
                echo '<input type="checkbox" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="1"' . $checked . ' />';
                echo '<span class="savol-slider" aria-hidden="true"></span>';
                echo '</label>';
            } elseif ($field['type'] === 'gallery') {
                $ids = array_filter(array_map('absint', explode(',', (string) $value)));
                echo '<input type="hidden" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr((string) $value) . '" class="savol-gallery-ids" />';
                echo '<p><button type="button" class="button savol-gallery-open">Selecionar fotos</button> <button type="button" class="button savol-gallery-clear">Limpar</button></p>';
                echo '<div class="savol-gallery-preview">';
                foreach ($ids as $id) {
                    $thumb = wp_get_attachment_image_url($id, 'thumbnail');
                    if ($thumb) {
                        echo '<img src="' . esc_url($thumb) . '" alt="" />';
                    }
                }
                echo '</div>';
            } elseif ($field['type'] === 'textarea') {
                echo '<textarea id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" rows="5">' . esc_textarea((string) $value) . '</textarea>';
            } else {
                $input_type = $field['type'] === 'number' ? 'number' : 'text';
                $step = $field['type'] === 'number' ? ' step="any"' : '';
                echo '<input type="' . esc_attr($input_type) . '" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr((string) $value) . '"' . $step . ' />';
            }

            echo '</div>';
        }

        echo '</div>';
    }

    private static function price_override_reason_options(): array {
        return [
            'BONUS TRADE IN MONTADORA',
            'VEICULO ANTIGO DE ESTOQUE',
            'AVALIAÇÃO ERRADA',
            'MUITO CARRO IGUAL NO ESTOQUE',
            'QUEDA DE MERCADO',
            'PROBLEMAS MECANICOS APÓS ENTRADA',
            'PREÇO DO USADO MUITO PERTO DO ZERO KM',
        ];
    }

    public static function render_price_override_meta_box(\WP_Post $post): void {
        $reason = (string) get_post_meta($post->ID, 'apolo_reconciliacao_motivo', true);
        $is_price_override = $reason === self::PRICE_OVERRIDE_REASON;
        $selected = (string) get_post_meta($post->ID, self::PRICE_OVERRIDE_REASON_META, true);
        $details = (string) get_post_meta($post->ID, self::PRICE_OVERRIDE_DETAILS_META, true);
        $published_user_name = (string) get_post_meta($post->ID, self::PRICE_OVERRIDE_USER_NAME_META, true);
        $published_user_id = absint(get_post_meta($post->ID, self::PRICE_OVERRIDE_USER_ID_META, true));
        $published_date = (string) get_post_meta($post->ID, self::PRICE_OVERRIDE_DATE_META, true);

        if (!$is_price_override) {
            echo '<p>Este veiculo nao esta bloqueado por preco de compra acima do preco de venda.</p>';
            if ($reason !== '') {
                echo '<p><strong>Motivo atual:</strong> ' . esc_html($reason) . '</p>';
            }
            return;
        }

        echo '<p><strong>Obrigatorio:</strong> selecione uma justificativa antes de publicar um veiculo em rascunho por preco de venda abaixo do preco de compra.</p>';
        echo '<p><label for="' . esc_attr(self::PRICE_OVERRIDE_REASON_META) . '"><strong>Motivo da publicacao *</strong></label></p>';
        echo '<select id="' . esc_attr(self::PRICE_OVERRIDE_REASON_META) . '" name="' . esc_attr(self::PRICE_OVERRIDE_REASON_META) . '" style="width:100%;max-width:520px;">';
        echo '<option value="">Selecione uma justificativa</option>';
        foreach (self::price_override_reason_options() as $option) {
            printf(
                '<option value="%1$s"%2$s>%1$s</option>',
                esc_attr($option),
                selected($selected, $option, false)
            );
        }
        echo '</select>';

        echo '<p><label for="' . esc_attr(self::PRICE_OVERRIDE_DETAILS_META) . '"><strong>Detalhes da justificativa</strong></label></p>';
        echo '<textarea id="' . esc_attr(self::PRICE_OVERRIDE_DETAILS_META) . '" name="' . esc_attr(self::PRICE_OVERRIDE_DETAILS_META) . '" rows="6" style="width:100%;max-width:720px;" placeholder="Descreva melhor a justificativa para publicar este veiculo.">' . esc_textarea($details) . '</textarea>';

        echo '<hr />';
        if ($published_user_id > 0 || $published_user_name !== '') {
            $label = $published_user_name !== '' ? $published_user_name : ('Usuario #' . $published_user_id);
            echo '<p><strong>Publicado por:</strong> ' . esc_html($label) . '</p>';
            if ($published_date !== '') {
                echo '<p><strong>Data da publicacao:</strong> ' . esc_html($published_date) . '</p>';
            }
        } else {
            echo '<p><strong>Publicado por:</strong> Ainda nao publicado manualmente.</p>';
        }
    }

    public static function render_sell_your_car_meta_box(\WP_Post $post): void {
        $protocol = (string) get_post_meta($post->ID, 'savol_vsc_protocol', true);
        $received_at = (string) get_post_meta($post->ID, 'savol_vsc_received_at', true);
        $photo_error = (string) get_post_meta($post->ID, 'savol_vsc_photo_error', true);
        $photo_ids = array_filter(array_map('absint', explode(',', (string) get_post_meta($post->ID, 'savol_vsc_photo_ids', true))));

        $sections = [
            'Veículo' => [
                'Marca' => 'savol_vsc_vehicle_brand',
                'Modelo' => 'savol_vsc_vehicle_model',
                'Placa' => 'savol_vsc_vehicle_plate',
                'Versão' => 'savol_vsc_vehicle_version',
                'Ano' => 'savol_vsc_vehicle_year',
                'Ano modelo' => 'savol_vsc_vehicle_model_year',
                'Ano fabricacao' => 'savol_vsc_vehicle_manufacture_year',
                'Combustível' => 'savol_vsc_vehicle_fuel',
                'Câmbio' => 'savol_vsc_vehicle_transmission',
                'KM' => 'savol_vsc_vehicle_km',
                'Cor' => 'savol_vsc_vehicle_color',
                'Final da placa' => 'savol_vsc_vehicle_plate_ending',
                'Carroceria' => 'savol_vsc_vehicle_body_type',
                'Preço desejado' => 'savol_vsc_vehicle_desired_price',
                'Observações' => 'savol_vsc_vehicle_notes',
            ],
            'Vendedor' => [
                'Nome' => 'savol_vsc_seller_full_name',
                'E-mail' => 'savol_vsc_seller_email',
                'Telefone' => 'savol_vsc_seller_phone',
                'CPF' => 'savol_vsc_seller_cpf',
                'WhatsApp' => 'savol_vsc_seller_whatsapp',
                'Cidade' => 'savol_vsc_seller_city',
                'Estado' => 'savol_vsc_seller_state',
                'Período de contato' => 'savol_vsc_seller_contact_period',
                'Canal de contato' => 'savol_vsc_seller_contact_channel',
            ],
        ];

        echo '<p><strong>Protocolo:</strong> ' . esc_html($protocol) . '</p>';
        echo '<p><strong>Recebido em:</strong> ' . esc_html($received_at) . '</p>';
        if ($photo_error !== '') {
            echo '<div class="notice notice-warning inline"><p><strong>Erro ao salvar fotos:</strong> ' . esc_html($photo_error) . '</p></div>';
        }

        foreach ($sections as $title => $fields) {
            echo '<h3>' . esc_html($title) . '</h3>';
            echo '<table class="widefat striped"><tbody>';
            foreach ($fields as $label => $meta_key) {
                $value = (string) get_post_meta($post->ID, $meta_key, true);
                echo '<tr><th style="width:180px;">' . esc_html($label) . '</th><td>' . esc_html($value) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        if (!empty($photo_ids)) {
            echo '<h3>Fotos</h3>';
            echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px;">';
            foreach ($photo_ids as $photo_id) {
                $thumb = wp_get_attachment_image_url($photo_id, 'thumbnail');
                $label = (string) get_post_meta($photo_id, 'savol_vsc_photo_label', true);
                if ($thumb === false) {
                    continue;
                }
                echo '<div><img src="' . esc_url($thumb) . '" alt="" style="width:100%;height:auto;border:1px solid #ccd0d4;" /><p style="margin:4px 0 0;">' . esc_html($label) . '</p></div>';
            }
            echo '</div>';
        }
    }

    public static function render_sell_your_car_assignment_meta_box(\WP_Post $post): void {
        if (!self::can_manage_sell_your_car_delegation()) {
            echo '<p>Sem permissao para delegar este lead.</p>';
            return;
        }

        $assigned_id = absint(get_post_meta($post->ID, self::ASSIGNED_SELLER_META, true));
        $sellers = self::get_sellers();
        ?>
        <p><strong>Vendedor responsavel</strong></p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="savol_vsc_assign_lead">
            <input type="hidden" name="lead_id" value="<?php echo esc_attr((string) $post->ID); ?>">
            <?php wp_nonce_field('savol_vsc_assign_lead_' . (int) $post->ID); ?>
            <p>
                <select name="seller_id" style="width:100%;" required>
                    <option value="">Selecione</option>
                    <?php foreach ($sellers as $seller) : ?>
                        <option value="<?php echo esc_attr((string) $seller->ID); ?>" <?php selected($assigned_id, (int) $seller->ID); ?>>
                            <?php echo esc_html($seller->display_name . ' - ' . $seller->user_email); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>
            <p><label><input type="checkbox" name="send_email" value="1" checked> Enviar e-mail com PDF</label></p>
            <p><button type="submit" class="button button-primary" style="width:100%;">Salvar delegacao</button></p>
        </form>
        <hr>
        <?php if ($assigned_id > 0) : ?>
            <p><a class="button" style="width:100%;text-align:center;" href="<?php echo esc_url(self::lead_email_url((int) $post->ID)); ?>">Enviar e-mail novamente</a></p>
        <?php endif; ?>
        <p><a class="button" style="width:100%;text-align:center;" target="_blank" href="<?php echo esc_url(self::lead_pdf_url((int) $post->ID)); ?>">Exportar PDF</a></p>
        <p><a href="<?php echo esc_url(self::sellers_admin_url()); ?>">Gerenciar vendedores</a></p>
        <?php
    }

    public static function register_sell_your_car_columns(array $columns): array {
        return [
            'cb' => $columns['cb'] ?? '',
            'title' => 'Lead',
            'savol_vsc_protocol' => 'Protocolo',
            'savol_vsc_seller' => 'Vendedor',
            'savol_vsc_vehicle' => 'Veículo',
            'savol_vsc_assigned_seller' => 'Responsavel',
            'savol_vsc_received_at' => 'Recebido em',
            'date' => $columns['date'] ?? 'Data',
        ];
    }

    public static function render_sell_your_car_column(string $column, int $post_id): void {
        if ($column === 'savol_vsc_protocol') {
            echo esc_html((string) get_post_meta($post_id, 'savol_vsc_protocol', true));
            return;
        }

        if ($column === 'savol_vsc_seller') {
            $name = (string) get_post_meta($post_id, 'savol_vsc_seller_full_name', true);
            $phone = (string) get_post_meta($post_id, 'savol_vsc_seller_phone', true);
            echo esc_html(trim($name . ' ' . $phone));
            return;
        }

        if ($column === 'savol_vsc_vehicle') {
            $brand = (string) get_post_meta($post_id, 'savol_vsc_vehicle_brand', true);
            $model = (string) get_post_meta($post_id, 'savol_vsc_vehicle_model', true);
            $year = (string) get_post_meta($post_id, 'savol_vsc_vehicle_model_year', true);
            if ($year === '') {
                $year = (string) get_post_meta($post_id, 'savol_vsc_vehicle_year', true);
            }
            echo esc_html(trim($brand . ' ' . $model . ' ' . $year));
            return;
        }

        if ($column === 'savol_vsc_received_at') {
            echo esc_html((string) get_post_meta($post_id, 'savol_vsc_received_at', true));
            return;
        }

        if ($column === 'savol_vsc_assigned_seller') {
            $seller_id = absint(get_post_meta($post_id, self::ASSIGNED_SELLER_META, true));
            $seller = $seller_id > 0 ? get_user_by('id', $seller_id) : null;
            echo $seller ? esc_html($seller->display_name) : '<span style="color:#777;">Nao delegado</span>';
        }
    }

    public static function save_meta(int $post_id): void {
        if (!isset($_POST[self::NONCE_NAME]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME])), self::NONCE_ACTION)) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        foreach (self::fields() as $key => $field) {
            if ($field['type'] === 'boolean') {
                update_post_meta($post_id, $key, isset($_POST[$key]) ? 1 : 0);
                continue;
            }

            if (!isset($_POST[$key])) {
                continue;
            }

            $raw = wp_unslash($_POST[$key]);

            if ($field['type'] === 'number') {
                if ($key === 'dias_proposta' && trim((string) $raw) === '') {
                    delete_post_meta($post_id, $key);
                    continue;
                }
                $sanitized = is_numeric($raw) ? (float) $raw : 0;
                update_post_meta($post_id, $key, $sanitized);
                continue;
            }
            if ($field['type'] === 'gallery') {
                $pieces = array_filter(array_map('absint', explode(',', (string) $raw)));
                update_post_meta($post_id, $key, implode(',', $pieces));
                continue;
            }
            if ($field['type'] === 'textarea') {
                update_post_meta($post_id, $key, sanitize_textarea_field((string) $raw));
                continue;
            }

            update_post_meta($post_id, $key, sanitize_text_field((string) $raw));
        }

        $apolo_reason = (string) get_post_meta($post_id, 'apolo_reconciliacao_motivo', true);
        if ($apolo_reason === self::PRICE_OVERRIDE_REASON) {
            $selected_reason = isset($_POST[self::PRICE_OVERRIDE_REASON_META])
                ? sanitize_text_field((string) wp_unslash($_POST[self::PRICE_OVERRIDE_REASON_META]))
                : '';
            if (!in_array($selected_reason, self::price_override_reason_options(), true)) {
                $selected_reason = '';
            }
            $details = isset($_POST[self::PRICE_OVERRIDE_DETAILS_META])
                ? sanitize_textarea_field((string) wp_unslash($_POST[self::PRICE_OVERRIDE_DETAILS_META]))
                : '';

            update_post_meta($post_id, self::PRICE_OVERRIDE_REASON_META, $selected_reason);
            update_post_meta($post_id, self::PRICE_OVERRIDE_DETAILS_META, $details);

            if ($selected_reason === '') {
                delete_post_meta($post_id, self::PRICE_OVERRIDE_USER_ID_META);
                delete_post_meta($post_id, self::PRICE_OVERRIDE_USER_NAME_META);
                delete_post_meta($post_id, self::PRICE_OVERRIDE_DATE_META);
                delete_post_meta($post_id, self::MANUAL_STATUS_LOCK_META);
                if (get_post_status($post_id) === 'publish') {
                    self::force_price_override_back_to_draft($post_id);
                }
                return;
            }

            if ($selected_reason !== '' && get_post_status($post_id) === 'publish') {
                if (!get_post_meta($post_id, self::PRICE_OVERRIDE_USER_ID_META, true)) {
                    self::record_price_override_publisher($post_id);
                } else {
                    update_post_meta($post_id, self::MANUAL_STATUS_LOCK_META, 1);
                }
            }
        }
    }

    public static function capture_vehicle_publish_user(string $new_status, string $old_status, \WP_Post $post): void {
        if ($post->post_type !== self::POST_TYPE || $new_status !== 'publish' || $old_status === 'publish') {
            return;
        }

        $apolo_reason = (string) get_post_meta($post->ID, 'apolo_reconciliacao_motivo', true);
        if ($apolo_reason !== self::PRICE_OVERRIDE_REASON) {
            return;
        }
        if (!self::has_price_override_justification($post->ID)) {
            return;
        }

        self::record_price_override_publisher($post->ID);
    }

    public static function enforce_price_override_before_insert(array $data, array $postarr): array {
        if (($data['post_type'] ?? '') !== self::POST_TYPE || ($data['post_status'] ?? '') !== 'publish') {
            return $data;
        }

        $post_id = isset($postarr['ID']) ? absint($postarr['ID']) : 0;
        if ($post_id <= 0) {
            return $data;
        }

        $apolo_reason = (string) get_post_meta($post_id, 'apolo_reconciliacao_motivo', true);
        if ($apolo_reason !== self::PRICE_OVERRIDE_REASON) {
            return $data;
        }

        $submitted_reason = null;
        if (isset($_POST[self::PRICE_OVERRIDE_REASON_META])) {
            $submitted_reason = sanitize_text_field((string) wp_unslash($_POST[self::PRICE_OVERRIDE_REASON_META]));
        }
        $selected_reason = $submitted_reason !== null
            ? $submitted_reason
            : (string) get_post_meta($post_id, self::PRICE_OVERRIDE_REASON_META, true);

        if (!in_array($selected_reason, self::price_override_reason_options(), true)) {
            $data['post_status'] = 'draft';
            self::set_price_override_required_notice();
        }

        return $data;
    }

    private static function has_price_override_justification(int $post_id): bool {
        $selected_reason = (string) get_post_meta($post_id, self::PRICE_OVERRIDE_REASON_META, true);
        return in_array($selected_reason, self::price_override_reason_options(), true);
    }

    private static function has_manual_status_lock(int $post_id): bool {
        return (string) get_post_meta($post_id, self::MANUAL_STATUS_LOCK_META, true) === '1';
    }

    private static function record_price_override_publisher(int $post_id): void {
        $user_id = get_current_user_id();
        $user = $user_id > 0 ? get_user_by('id', $user_id) : null;
        update_post_meta($post_id, self::PRICE_OVERRIDE_USER_ID_META, $user_id);
        update_post_meta($post_id, self::PRICE_OVERRIDE_USER_NAME_META, $user ? $user->display_name : 'Sistema');
        update_post_meta($post_id, self::PRICE_OVERRIDE_DATE_META, current_time('d/m/Y H:i'));
        if ($user_id > 0) {
            update_post_meta($post_id, self::MANUAL_STATUS_LOCK_META, 1);
        }
    }

    private static function force_price_override_back_to_draft(int $post_id): void {
        self::set_price_override_required_notice();

        remove_action('save_post_' . self::POST_TYPE, [__CLASS__, 'save_meta']);
        wp_update_post([
            'ID' => $post_id,
            'post_status' => 'draft',
        ]);
        add_action('save_post_' . self::POST_TYPE, [__CLASS__, 'save_meta']);
    }

    private static function set_price_override_required_notice(): void {
        set_transient(
            self::price_override_notice_key(),
            'Para publicar este veiculo, selecione uma justificativa para preco de venda abaixo do preco de compra.',
            60
        );
    }

    private static function price_override_notice_key(): string {
        return self::PRICE_OVERRIDE_NOTICE_TRANSIENT . max(0, get_current_user_id());
    }

    public static function render_price_override_admin_notice(): void {
        $message = get_transient(self::price_override_notice_key());
        if (!is_string($message) || $message === '') {
            return;
        }

        delete_transient(self::price_override_notice_key());
        echo '<div class="notice notice-error is-dismissible"><p><strong>SAVOL Veiculos:</strong> ' . esc_html($message) . '</p></div>';
    }

    public static function register_sell_your_car_api_alias(): void {
        add_rewrite_rule('^api/venda-seu-carro/?$', 'index.php?savol_venda_seu_carro_api=1', 'top');
    }

    public static function register_sell_your_car_query_vars(array $vars): array {
        $vars[] = 'savol_venda_seu_carro_api';
        return $vars;
    }

    public static function handle_sell_your_car_api_alias_request(\WP $wp): void {
        $request_path = trim((string) ($wp->request ?? ''), '/');
        if ($request_path !== 'api/venda-seu-carro') {
            return;
        }

        self::send_sell_your_car_api_alias_response();
    }

    public static function handle_sell_your_car_api_alias(): void {
        if ((string) get_query_var('savol_venda_seu_carro_api') !== '1') {
            return;
        }

        self::send_sell_your_car_api_alias_response();
    }

    private static function send_sell_your_car_api_alias_response(): void {
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? '')) !== 'POST') {
            wp_send_json([
                'ok' => false,
                'error' => 'Metodo nao permitido.',
            ], 405);
        }

        $request = new \WP_REST_Request('POST', '/' . self::SELL_YOUR_CAR_REST_NAMESPACE . self::SELL_YOUR_CAR_REST_ROUTE);
        if (isset($_POST['payload'])) {
            $request->set_param('payload', wp_unslash($_POST['payload']));
        }

        $response = self::handle_sell_your_car_request($request);
        wp_send_json($response->get_data(), $response->get_status());
    }

    public static function register_rest_routes(): void {
        register_rest_route(self::SELL_YOUR_CAR_REST_NAMESPACE, self::SELL_YOUR_CAR_REST_ROUTE, [
            'methods' => \WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'handle_sell_your_car_request'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('savol/v1', '/dashboard/veiculos', [
            'methods' => \WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'handle_dashboard_vehicles_request'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('savol/v1', '/dashboard/operacoes', [
            'methods' => \WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'handle_dashboard_operations_request'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('savol/v1', '/dashboard/login', [
            'methods' => \WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'handle_dashboard_login_request'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('savol/v1', '/dashboard/veiculos/(?P<id>\d+)/autorizar-publicacao', [
            'methods' => \WP_REST_Server::EDITABLE,
            'callback' => [__CLASS__, 'handle_dashboard_authorize_vehicle_request'],
            'permission_callback' => [__CLASS__, 'dashboard_can_edit_vehicle'],
        ]);

        register_rest_route('savol/v1', '/dashboard/users', [
            'methods' => \WP_REST_Server::CREATABLE,
            'callback' => [__CLASS__, 'handle_dashboard_create_user_request'],
            'permission_callback' => [__CLASS__, 'dashboard_can_create_users'],
        ]);
    }

    private static function dashboard_token_base64_encode(string $value): string {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private static function dashboard_token_base64_decode(string $value): string {
        $padding = strlen($value) % 4;
        if ($padding > 0) {
            $value .= str_repeat('=', 4 - $padding);
        }
        return (string) base64_decode(strtr($value, '-_', '+/'), true);
    }

    private static function create_dashboard_token(\WP_User $user): string {
        $payload = self::dashboard_token_base64_encode((string) wp_json_encode([
            'user_id' => (int) $user->ID,
            'expires_at' => time() + (8 * HOUR_IN_SECONDS),
        ]));
        $signature = hash_hmac('sha256', $payload, wp_salt('auth'));
        return $payload . '.' . $signature;
    }

    private static function dashboard_request_user(\WP_REST_Request $request): ?\WP_User {
        $authorization = (string) $request->get_header('authorization');
        if (!preg_match('/^Bearer\s+(.+)$/i', $authorization, $matches)) {
            return null;
        }
        $parts = explode('.', trim((string) $matches[1]), 2);
        if (count($parts) !== 2) {
            return null;
        }
        [$payload, $signature] = $parts;
        $expected = hash_hmac('sha256', $payload, wp_salt('auth'));
        if (!hash_equals($expected, $signature)) {
            return null;
        }
        $data = json_decode(self::dashboard_token_base64_decode($payload), true);
        if (!is_array($data) || (int) ($data['expires_at'] ?? 0) < time()) {
            return null;
        }
        $user = get_user_by('id', absint($data['user_id'] ?? 0));
        return $user instanceof \WP_User ? $user : null;
    }

    public static function dashboard_can_edit_vehicle(\WP_REST_Request $request) {
        $user = self::dashboard_request_user($request);
        $post_id = absint($request->get_param('id'));
        if (!$user || $post_id <= 0 || !user_can($user, 'edit_post', $post_id)) {
            return new \WP_Error('savol_dashboard_forbidden', 'Acesso não autorizado.', ['status' => 403]);
        }
        wp_set_current_user((int) $user->ID);
        return true;
    }

    public static function dashboard_can_create_users(\WP_REST_Request $request) {
        $user = self::dashboard_request_user($request);
        if (!$user || !user_can($user, 'create_users')) {
            return new \WP_Error('savol_dashboard_forbidden', 'Acesso não autorizado.', ['status' => 403]);
        }
        wp_set_current_user((int) $user->ID);
        return true;
    }

    public static function handle_dashboard_authorize_vehicle_request(\WP_REST_Request $request): \WP_REST_Response {
        $post_id = absint($request->get_param('id'));
        $post = get_post($post_id);
        if (!$post || $post->post_type !== self::POST_TYPE) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Veículo não encontrado.'], 404);
        }
        $block_reason = (string) get_post_meta($post_id, 'apolo_reconciliacao_motivo', true);
        if ($block_reason !== self::PRICE_OVERRIDE_REASON) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Este veículo não está bloqueado por diferença de preço.'], 409);
        }
        $justification = sanitize_text_field((string) $request->get_param('justification'));
        if (!in_array($justification, self::price_override_reason_options(), true)) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Selecione uma justificativa válida.'], 422);
        }

        update_post_meta($post_id, self::PRICE_OVERRIDE_REASON_META, $justification);
        update_post_meta($post_id, self::PRICE_OVERRIDE_DETAILS_META, sanitize_textarea_field((string) $request->get_param('details')));
        $result = wp_update_post(['ID' => $post_id, 'post_status' => 'publish'], true);
        if (is_wp_error($result) || get_post_status($post_id) !== 'publish') {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Não foi possível publicar o veículo.'], 500);
        }

        self::record_price_override_publisher($post_id);
        return new \WP_REST_Response(['ok' => true, 'message' => 'Veículo autorizado e publicado.'], 200);
    }

    public static function handle_dashboard_create_user_request(\WP_REST_Request $request): \WP_REST_Response {
        $email = sanitize_email((string) $request->get_param('email'));
        $name = sanitize_text_field((string) $request->get_param('name'));
        if (!is_email($email)) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'E-mail inválido.'], 422);
        }
        if (email_exists($email)) {
            return new \WP_REST_Response(['ok' => false, 'message' => 'Já existe um acesso com este e-mail.'], 409);
        }
        $username = sanitize_user(strstr($email, '@', true) ?: $email, true);
        if (username_exists($username)) {
            $username .= '-' . wp_generate_password(4, false, false);
        }
        $password = wp_generate_password(20, true, true);
        $user_id = wp_insert_user([
            'user_login' => $username,
            'user_email' => $email,
            'display_name' => $name !== '' ? $name : $username,
            'user_pass' => $password,
            'role' => 'gestor_savol',
        ]);
        if (is_wp_error($user_id)) {
            return new \WP_REST_Response(['ok' => false, 'message' => $user_id->get_error_message()], 500);
        }
        return new \WP_REST_Response(['ok' => true, 'user' => ['id' => (int) $user_id, 'username' => $username, 'email' => $email], 'temporaryPassword' => $password], 201);
    }

    public static function handle_dashboard_login_request(\WP_REST_Request $request): \WP_REST_Response {
        $username = sanitize_user((string) $request->get_param('username'));
        $password = (string) $request->get_param('password');

        if ($username === '' || $password === '') {
            return new \WP_REST_Response([
                'ok' => false,
                'message' => 'Informe usuario e senha.',
            ], 400);
        }

        $user = wp_authenticate($username, $password);
        if (is_wp_error($user) || !($user instanceof \WP_User)) {
            return new \WP_REST_Response([
                'ok' => false,
                'message' => 'Usuario ou senha invalidos.',
            ], 401);
        }

        if (!user_can($user, 'edit_posts')) {
            return new \WP_REST_Response([
                'ok' => false,
                'message' => 'Usuario sem permissao para acessar o painel.',
            ], 403);
        }

        return new \WP_REST_Response([
            'ok' => true,
            'token' => self::create_dashboard_token($user),
            'user' => [
                'id' => (int) $user->ID,
                'name' => $user->display_name,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'roles' => array_values((array) $user->roles),
            ],
        ], 200);
    }

    public static function handle_dashboard_vehicles_request(\WP_REST_Request $request): \WP_REST_Response {
        $posts = get_posts([
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        $items = array_values(array_filter(
            array_map([__CLASS__, 'dashboard_vehicle_payload'], $posts),
            [__CLASS__, 'dashboard_vehicle_is_allowed_company_reseller']
        ));

        return new \WP_REST_Response([
            'ok' => true,
            'items' => $items,
            'total' => count($items),
            'source' => 'savol-comercial-suite',
            'updatedAt' => current_time('mysql'),
        ], 200);
    }

    public static function handle_dashboard_operations_request(\WP_REST_Request $request): \WP_REST_Response {
        $type = sanitize_key((string) $request->get_param('type'));
        $date_start = sanitize_text_field((string) $request->get_param('dateStart'));
        $date_end = sanitize_text_field((string) $request->get_param('dateEnd'));
        $operations = self::get_dashboard_operations_log();

        $items = array_values(array_filter($operations, static function ($operation) use ($type, $date_start, $date_end): bool {
            if (!is_array($operation)) {
                return false;
            }
            if ($type !== '' && (string) ($operation['type'] ?? '') !== $type) {
                return false;
            }

            $occurred_at = (string) ($operation['occurredAt'] ?? '');
            $date_key = substr($occurred_at, 0, 10);
            if ($date_start !== '' && $date_key < $date_start) {
                return false;
            }
            if ($date_end !== '' && $date_key > $date_end) {
                return false;
            }

            return true;
        }));

        return new \WP_REST_Response([
            'ok' => true,
            'items' => $items,
            'total' => count($items),
            'source' => 'savol-comercial-suite',
            'updatedAt' => current_time('mysql'),
        ], 200);
    }

    public static function handle_sell_your_car_request(\WP_REST_Request $request): \WP_REST_Response {
        $payload_raw = self::get_sell_your_car_payload_raw($request);
        if (trim($payload_raw) === '') {
            return self::sell_your_car_error('Campo payload ausente.', 400);
        }

        $payload = self::decode_sell_your_car_payload($payload_raw);
        if (!is_array($payload)) {
            return self::sell_your_car_error('Payload JSON invalido: ' . json_last_error_msg() . '.', 400);
        }

        $files = self::get_sell_your_car_files($request);
        $photo_validation_error = self::validate_sell_your_car_photos($files);
        if ($photo_validation_error !== '') {
            return self::sell_your_car_error($photo_validation_error, 400);
        }

        $protocol = self::generate_sell_your_car_protocol();
        $received_at = gmdate('Y-m-d\TH:i:s.000\Z');
        $vehicle = isset($payload['vehicle']) && is_array($payload['vehicle']) ? $payload['vehicle'] : [];
        $seller = isset($payload['seller']) && is_array($payload['seller']) ? $payload['seller'] : [];
        $title = self::build_sell_your_car_title($protocol, $vehicle, $seller);

        $post_id = wp_insert_post([
            'post_type' => self::SELL_YOUR_CAR_POST_TYPE,
            'post_title' => $title,
            'post_status' => 'publish',
            'post_content' => self::build_sell_your_car_content($payload),
        ], true);

        if (is_wp_error($post_id) || (int) $post_id <= 0) {
            return self::sell_your_car_error('Nao foi possivel salvar o lead no WordPress.', 500);
        }

        $post_id = (int) $post_id;
        $attachment_ids = self::store_sell_your_car_photos($post_id, $files);
        if (is_wp_error($attachment_ids)) {
            update_post_meta($post_id, 'savol_vsc_photo_error', $attachment_ids->get_error_message());
            $attachment_ids = [];
        }

        update_post_meta($post_id, 'savol_vsc_protocol', $protocol);
        update_post_meta($post_id, 'savol_vsc_received_at', $received_at);
        update_post_meta($post_id, 'savol_vsc_payload_raw', $payload_raw);
        update_post_meta($post_id, 'savol_vsc_payload', wp_json_encode($payload, JSON_UNESCAPED_UNICODE));
        update_post_meta($post_id, 'savol_vsc_vehicle', wp_json_encode($vehicle, JSON_UNESCAPED_UNICODE));
        update_post_meta($post_id, 'savol_vsc_seller', wp_json_encode($seller, JSON_UNESCAPED_UNICODE));
        update_post_meta($post_id, 'savol_vsc_photo_ids', implode(',', array_map('absint', $attachment_ids)));
        self::update_sell_your_car_flat_meta($post_id, $payload, $vehicle, $seller);

        $security = self::build_sell_your_car_security($payload, $protocol, $received_at, count($attachment_ids));
        update_post_meta($post_id, 'savol_vsc_security', wp_json_encode($security, JSON_UNESCAPED_UNICODE));

        return new \WP_REST_Response([
            'ok' => true,
            'protocol' => $protocol,
            'receivedAt' => $received_at,
            'leadId' => $post_id,
            'payloadReceived' => true,
            'payloadKeys' => array_keys($payload),
            'photoCount' => count($attachment_ids),
            'photoError' => (string) get_post_meta($post_id, 'savol_vsc_photo_error', true),
            'security' => $security,
        ], 201);
    }

    private static function get_sell_your_car_payload_raw(\WP_REST_Request $request): string {
        $candidates = [];

        $param_payload = $request->get_param('payload');
        if ($param_payload !== null) {
            $candidates[] = $param_payload;
        }

        $body_params = $request->get_body_params();
        if (is_array($body_params) && array_key_exists('payload', $body_params)) {
            $candidates[] = $body_params['payload'];
        }

        if (isset($_POST['payload'])) {
            $candidates[] = $_POST['payload'];
        }

        foreach ($candidates as $candidate) {
            if (is_array($candidate)) {
                $candidate = wp_json_encode($candidate, JSON_UNESCAPED_UNICODE);
            }

            $candidate = is_string($candidate) ? wp_unslash($candidate) : (string) $candidate;
            $candidate = trim($candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    private static function decode_sell_your_car_payload(string $payload_raw) {
        $payload_raw = preg_replace('/^\xEF\xBB\xBF/', '', $payload_raw);
        $payload_raw = trim((string) $payload_raw);

        $payload = json_decode($payload_raw, true);
        if (is_array($payload)) {
            return $payload;
        }

        $unslashed = stripslashes($payload_raw);
        if ($unslashed !== $payload_raw) {
            $payload = json_decode($unslashed, true);
            if (is_array($payload)) {
                return $payload;
            }
        }

        $decoded_entities = html_entity_decode($payload_raw, ENT_QUOTES, 'UTF-8');
        if ($decoded_entities !== $payload_raw) {
            $payload = json_decode($decoded_entities, true);
            if (is_array($payload)) {
                return $payload;
            }
        }

        return null;
    }

    private static function get_sell_your_car_files(\WP_REST_Request $request): array {
        $files = $request->get_file_params();
        if (!empty($files)) {
            return $files;
        }

        return is_array($_FILES) ? $_FILES : [];
    }

    private static function update_sell_your_car_flat_meta(int $post_id, array $payload, array $vehicle, array $seller): void {
        $consents = isset($payload['consents']) && is_array($payload['consents']) ? $payload['consents'] : [];
        $source = isset($payload['source']) && is_array($payload['source']) ? $payload['source'] : [];

        $meta = [
            'savol_vsc_vehicle_brand' => $vehicle['brand'] ?? '',
            'savol_vsc_vehicle_model' => $vehicle['model'] ?? '',
            'savol_vsc_vehicle_version' => $vehicle['version'] ?? '',
            'savol_vsc_vehicle_plate' => $vehicle['plate'] ?? '',
            'savol_vsc_vehicle_year' => $vehicle['year'] ?? '',
            'savol_vsc_vehicle_model_year' => $vehicle['modelYear'] ?? '',
            'savol_vsc_vehicle_manufacture_year' => $vehicle['manufactureYear'] ?? '',
            'savol_vsc_vehicle_fuel' => $vehicle['fuel'] ?? '',
            'savol_vsc_vehicle_transmission' => $vehicle['transmission'] ?? '',
            'savol_vsc_vehicle_km' => $vehicle['km'] ?? '',
            'savol_vsc_vehicle_color' => $vehicle['color'] ?? '',
            'savol_vsc_vehicle_plate_ending' => $vehicle['plateEnding'] ?? '',
            'savol_vsc_vehicle_body_type' => $vehicle['bodyType'] ?? '',
            'savol_vsc_vehicle_owner_count' => $vehicle['ownerCount'] ?? '',
            'savol_vsc_vehicle_has_manual' => $vehicle['hasManual'] ?? '',
            'savol_vsc_vehicle_has_spare_key' => $vehicle['hasSpareKey'] ?? '',
            'savol_vsc_vehicle_desired_price' => $vehicle['desiredPrice'] ?? '',
            'savol_vsc_vehicle_notes' => $vehicle['notes'] ?? '',
            'savol_vsc_seller_full_name' => $seller['fullName'] ?? '',
            'savol_vsc_seller_email' => $seller['email'] ?? '',
            'savol_vsc_seller_phone' => $seller['phone'] ?? '',
            'savol_vsc_seller_cpf' => $seller['cpf'] ?? '',
            'savol_vsc_seller_whatsapp' => $seller['whatsapp'] ?? '',
            'savol_vsc_seller_city' => $seller['city'] ?? '',
            'savol_vsc_seller_state' => $seller['state'] ?? '',
            'savol_vsc_seller_contact_period' => $seller['contactPeriod'] ?? '',
            'savol_vsc_seller_contact_channel' => $seller['contactChannel'] ?? '',
            'savol_vsc_consent_terms' => !empty($consents['acceptedTerms']) ? '1' : '0',
            'savol_vsc_consent_lgpd' => !empty($consents['acceptedLgpd']) ? '1' : '0',
            'savol_vsc_consent_accepted_at' => $consents['acceptedAt'] ?? '',
            'savol_vsc_source_page_url' => self::normalize_public_page_url((string) ($source['pageUrl'] ?? '')),
            'savol_vsc_source_channel' => $source['channel'] ?? '',
            'savol_vsc_source_user_agent' => $source['userAgent'] ?? '',
            'savol_vsc_source_submitted_at' => $source['submittedAt'] ?? '',
        ];

        foreach ($meta as $key => $value) {
            update_post_meta($post_id, $key, sanitize_text_field((string) $value));
        }
    }

    private static function normalize_public_page_url(string $url): string {
        $url = trim($url);
        $fallback = self::PUBLIC_SITE_URL . self::SELL_YOUR_CAR_PUBLIC_PATH;

        if ($url === '') {
            return $fallback;
        }

        $host = wp_parse_url($url, PHP_URL_HOST);
        $host = is_string($host) ? strtolower($host) : '';
        if (in_array($host, ['localhost', '127.0.0.1', '::1'], true) || str_contains(strtolower($url), 'localhost')) {
            return $fallback;
        }

        return $url;
    }

    private static function sell_your_car_photo_fields(): array {
        return [
            'photo_vehicle' => 'FOTO FRENTE VEÍCULO',
            'photo_documentFront' => 'Frente do documento',
            'photo_odometer' => 'Hodômetro',
        ];
    }

    private static function sell_your_car_optional_photo_fields(): array {
        return [
            'photo_front' => 'FOTO FRENTE VEÍCULO',
            'photo_leftSide' => 'Lateral esquerda',
            'photo_rightSide' => 'Lateral direita',
            'photo_rear' => 'Traseira',
            'photo_dashboard' => 'Painel',
            'photo_spare' => 'Estepe',
            'photo_trunk' => 'Porta-malas',
            'photo_roof' => 'Teto',
            'photo_tire' => 'Pneu',
            'photo_engine' => 'Motor',
            'photo_chassis' => 'Chassi',
        ];
    }

    private static function sell_your_car_all_photo_fields(): array {
        return self::sell_your_car_photo_fields() + self::sell_your_car_optional_photo_fields();
    }

    private static function validate_sell_your_car_photos(array $files): string {
        foreach (self::sell_your_car_photo_fields() as $field => $label) {
            if (empty($files[$field]) || !is_array($files[$field])) {
                return 'Foto obrigatória ausente: ' . $field . '.';
            }

            $file = $files[$field];
            if (!empty($file['error'])) {
                return 'Erro no upload da foto ' . $field . '.';
            }
            if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
                return 'Upload invalido para a foto ' . $field . '.';
            }
            if ((int) ($file['size'] ?? 0) > self::SELL_YOUR_CAR_MAX_PHOTO_SIZE) {
                return 'Foto acima de 8 MB: ' . $field . '.';
            }

            $mime = (string) ($file['type'] ?? '');
            if (!str_starts_with($mime, 'image/')) {
                return 'Arquivo enviado nao e imagem: ' . $field . '.';
            }
        }

        return '';
    }

    private static function store_sell_your_car_photos(int $post_id, array $files) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $attachment_ids = [];
        $errors = [];
        foreach (self::sell_your_car_all_photo_fields() as $field => $label) {
            if (empty($files[$field]) || !is_array($files[$field])) {
                continue;
            }

            $file = $files[$field];
            $upload = wp_handle_upload($file, ['test_form' => false]);
            if (!is_array($upload) || isset($upload['error'])) {
                $message = is_array($upload) && isset($upload['error']) ? (string) $upload['error'] : 'erro desconhecido';
                $errors[] = 'Falha ao salvar a foto ' . $field . ': ' . $message;
                continue;
            }

            $attachment_id = wp_insert_attachment([
                'post_mime_type' => $upload['type'],
                'post_title' => sanitize_file_name(pathinfo((string) $file['name'], PATHINFO_FILENAME)),
                'post_content' => '',
                'post_status' => 'inherit',
                'post_parent' => $post_id,
            ], $upload['file'], $post_id, true);

            if (is_wp_error($attachment_id) || (int) $attachment_id <= 0) {
                $message = is_wp_error($attachment_id) ? $attachment_id->get_error_message() : 'ID do anexo invalido';
                $errors[] = 'Falha ao criar anexo da foto ' . $field . ': ' . $message;
                continue;
            }

            $metadata = wp_generate_attachment_metadata((int) $attachment_id, $upload['file']);
            if (is_array($metadata)) {
                wp_update_attachment_metadata((int) $attachment_id, $metadata);
            }

            update_post_meta((int) $attachment_id, 'savol_vsc_photo_field', $field);
            update_post_meta((int) $attachment_id, 'savol_vsc_photo_label', $label);
            $attachment_ids[] = (int) $attachment_id;
        }

        if (!empty($errors)) {
            update_post_meta($post_id, 'savol_vsc_photo_error', implode(' | ', $errors));
        }

        if (!empty($attachment_ids)) {
            set_post_thumbnail($post_id, $attachment_ids[0]);
        }

        return $attachment_ids;
    }

    private static function build_sell_your_car_security(array $payload, string $protocol, string $received_at, int $photo_count): array {
        $signed_payload = [
            'payload' => $payload,
            'server' => [
                'protocol' => $protocol,
                'receivedAt' => $received_at,
                'photoCount' => $photo_count,
            ],
        ];
        $secret = self::get_sell_your_car_token_secret();
        $token = $secret !== '' ? hash_hmac('sha256', wp_json_encode($signed_payload, JSON_UNESCAPED_UNICODE), $secret) : '';

        return [
            'tokenType' => 'hmac-sha256',
            'token' => $token,
            'signedFields' => ['payload', 'server.protocol', 'server.receivedAt', 'server.photoCount'],
        ];
    }

    private static function get_sell_your_car_token_secret(): string {
        if (defined('SELL_YOUR_CAR_TOKEN_SECRET')) {
            return (string) constant('SELL_YOUR_CAR_TOKEN_SECRET');
        }

        $secret = getenv('SELL_YOUR_CAR_TOKEN_SECRET');
        return is_string($secret) ? $secret : '';
    }

    private static function build_sell_your_car_title(string $protocol, array $vehicle, array $seller): string {
        $parts = [
            (string) ($seller['fullName'] ?? ''),
            (string) ($vehicle['brand'] ?? ''),
            (string) ($vehicle['model'] ?? ''),
            (string) ($vehicle['modelYear'] ?? $vehicle['year'] ?? ''),
        ];
        $title = trim(preg_replace('/\s+/', ' ', implode(' - ', array_filter($parts))));
        return $title !== '' ? $protocol . ' - ' . $title : $protocol;
    }

    private static function build_sell_your_car_content(array $payload): string {
        $vehicle = isset($payload['vehicle']) && is_array($payload['vehicle']) ? $payload['vehicle'] : [];
        $seller = isset($payload['seller']) && is_array($payload['seller']) ? $payload['seller'] : [];

        $lines = [
            'Vendedor: ' . (string) ($seller['fullName'] ?? ''),
            'E-mail: ' . (string) ($seller['email'] ?? ''),
            'Telefone: ' . (string) ($seller['phone'] ?? ''),
            'CPF: ' . (string) ($seller['cpf'] ?? ''),
            'WhatsApp: ' . (string) ($seller['whatsapp'] ?? ''),
            'Placa: ' . (string) ($vehicle['plate'] ?? ''),
            'Veiculo: ' . trim((string) ($vehicle['brand'] ?? '') . ' ' . (string) ($vehicle['model'] ?? '') . ' ' . (string) ($vehicle['version'] ?? '')),
            'Ano modelo: ' . (string) ($vehicle['modelYear'] ?? $vehicle['year'] ?? ''),
            'Ano fabricacao: ' . (string) ($vehicle['manufactureYear'] ?? ''),
            'KM: ' . (string) ($vehicle['km'] ?? ''),
            'Preco desejado: ' . (string) ($vehicle['desiredPrice'] ?? ''),
            '',
            'Payload completo salvo no campo personalizado savol_vsc_payload.',
        ];

        return implode("\n", $lines);
    }

    private static function generate_sell_your_car_protocol(): string {
        return 'SAVOL-VSC-' . gmdate('Ymd-His') . '-' . wp_generate_password(6, false, false);
    }

    private static function sell_your_car_error(string $message, int $status): \WP_REST_Response {
        return new \WP_REST_Response([
            'ok' => false,
            'error' => $message,
        ], $status);
    }

    public static function enqueue_admin_assets(string $hook): void {
        global $post_type;
        $taxonomy = isset($_GET['taxonomy']) ? sanitize_key((string) $_GET['taxonomy']) : '';

        $is_veiculo_post_screen = ($hook === 'post.php' || $hook === 'post-new.php') && $post_type === self::POST_TYPE;
        $is_sell_your_car_post_screen = ($hook === 'post.php' || $hook === 'post-new.php') && $post_type === self::SELL_YOUR_CAR_POST_TYPE;
        $is_tax_screen = ($hook === 'edit-tags.php' || $hook === 'term.php') && in_array($taxonomy, ['veiculo_cor', 'veiculo_marca'], true);
        $is_autosync_screen = $hook === 'veiculo_page_savol-veiculos-autosync';
        $is_seller_screen = in_array($hook, [
            self::SELL_YOUR_CAR_POST_TYPE . '_page_' . self::SELLER_MENU_SLUG,
            'toplevel_page_' . self::SELLER_LEADS_MENU_SLUG,
        ], true);

        if (!$is_veiculo_post_screen && !$is_sell_your_car_post_screen && !$is_tax_screen && !$is_autosync_screen && !$is_seller_screen) {
            return;
        }

        $css = '
            .savol-veiculos-grid {
                display: grid;
                gap: 14px;
                grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            }
            .savol-field {
                display: flex;
                flex-direction: column;
                gap: 6px;
            }
            .savol-field label {
                font-weight: 600;
            }
            .savol-field input[type="text"],
            .savol-field input[type="number"] {
                width: 100%;
            }
            .savol-switch {
                align-items: center;
                display: inline-flex;
            }
            .savol-switch input {
                display: none;
            }
            .savol-slider {
                position: relative;
                width: 44px;
                height: 24px;
                border-radius: 24px;
                background: #ccd0d4;
                transition: 0.2s;
            }
            .savol-slider::before {
                content: "";
                position: absolute;
                width: 18px;
                height: 18px;
                border-radius: 50%;
                top: 3px;
                left: 3px;
                background: #fff;
                transition: 0.2s;
            }
            .savol-switch input:checked + .savol-slider {
                background: #2271b1;
            }
            .savol-switch input:checked + .savol-slider::before {
                transform: translateX(20px);
            }
            .savol-term-logo-preview {
                margin-top: 8px;
                max-width: 120px;
                max-height: 120px;
                display: block;
            }
            .savol-gallery-preview {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                margin-top: 8px;
            }
            .savol-gallery-preview img {
                width: 80px;
                height: 80px;
                object-fit: cover;
                border-radius: 4px;
                border: 1px solid #dcdcde;
            }
            .savol-vsc-admin {
                max-width: 1280px;
            }
            .savol-vsc-cards {
                display: grid;
                gap: 18px;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                margin: 18px 0;
            }
            .savol-vsc-card {
                background: #fff;
                border: 1px solid #dcdcde;
                border-radius: 8px;
                box-shadow: 0 8px 20px rgba(15, 23, 42, .05);
                padding: 18px;
            }
            .savol-vsc-card h2 {
                margin-top: 0;
            }
            .savol-vsc-card select,
            .savol-vsc-card input.regular-text {
                max-width: 100%;
                width: 100%;
            }
            @media (max-width: 900px) {
                .savol-vsc-cards {
                    grid-template-columns: 1fr;
                }
            }
        ';

        wp_register_style('savol-veiculos-admin', false);
        wp_enqueue_style('savol-veiculos-admin');
        wp_add_inline_style('savol-veiculos-admin', $css);

        if ($is_tax_screen) {
            if ($taxonomy === 'veiculo_cor') {
                wp_enqueue_style('wp-color-picker');
                wp_enqueue_script('wp-color-picker');
                wp_add_inline_script('wp-color-picker', 'jQuery(function($){$(".savol-color-field").wpColorPicker();});');
            }

            if ($taxonomy === 'veiculo_marca') {
                wp_enqueue_media();
                $logo_js = <<<JS
jQuery(function($){
    var frame;
    function openFrame(){
        if (frame) {
            frame.open();
            return;
        }
        frame = wp.media({
            title: 'Selecionar logo da marca',
            button: { text: 'Usar esta imagem' },
            library: { type: ['image/png', 'image/webp'] },
            multiple: false
        });
        frame.on('select', function(){
            var attachment = frame.state().get('selection').first().toJSON();
            var mime = attachment.mime || '';
            if (mime !== 'image/png' && mime !== 'image/webp') {
                window.alert('Use apenas imagens PNG ou WebP.');
                return;
            }
            $('.savol-marca-logo-id').val(attachment.id);
            $('.savol-term-logo-preview').attr('src', attachment.url).show();
        });
        frame.open();
    }
    $(document).on('click', '.savol-marca-logo-upload', function(e){
        e.preventDefault();
        openFrame();
    });
    $(document).on('click', '.savol-marca-logo-remove', function(e){
        e.preventDefault();
        $('.savol-marca-logo-id').val('');
        $('.savol-term-logo-preview').attr('src', '').hide();
    });
});
JS;
                wp_add_inline_script('jquery-core', $logo_js);
            }
        }

        if ($is_veiculo_post_screen) {
            wp_enqueue_media();
            $gallery_js = <<<JS
jQuery(function($){
    var frame;
    function renderPreview(ids, container){
        container.empty();
        ids.forEach(function(id){
            var attachment = wp.media.attachment(id);
            attachment.fetch().then(function(){
                var sizes = attachment.get('sizes');
                var url = (sizes && sizes.thumbnail ? sizes.thumbnail.url : attachment.get('url'));
                if (url) {
                    container.append($('<img>', { src: url, alt: '' }));
                }
            });
        });
    }
    $(document).on('click', '.savol-gallery-open', function(e){
        e.preventDefault();
        var wrap = $(this).closest('.savol-field');
        var input = wrap.find('.savol-gallery-ids');
        var preview = wrap.find('.savol-gallery-preview');
        var selected = input.val() ? input.val().split(',').map(Number).filter(Boolean) : [];
        frame = wp.media({
            title: 'Selecionar fotos do veiculo',
            button: { text: 'Usar fotos' },
            multiple: true
        });
        frame.on('open', function(){
            var selection = frame.state().get('selection');
            selected.forEach(function(id){
                var attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add(attachment);
            });
        });
        frame.on('select', function(){
            var ids = frame.state().get('selection').map(function(item){ return item.get('id'); });
            input.val(ids.join(','));
            renderPreview(ids, preview);
        });
        frame.open();
    });
    $(document).on('click', '.savol-gallery-clear', function(e){
        e.preventDefault();
        var wrap = $(this).closest('.savol-field');
        wrap.find('.savol-gallery-ids').val('');
        wrap.find('.savol-gallery-preview').empty();
    });
});
JS;
            wp_add_inline_script('jquery-core', $gallery_js);
        }

        if ($is_autosync_screen) {
            $autosync_nonce = wp_create_nonce('savol_veiculos_run_autosync');
            $autosync_js = <<<JS
jQuery(function($){
    var btn = $('#savol-autosync-run');
    var wrap = $('#savol-autosync-progress-wrap');
    var bar = $('#savol-autosync-progress-bar');
    var text = $('#savol-autosync-progress-text');
    function setProgress(percent, message){
        bar.css('width', percent + '%');
        text.text(message);
    }
    function poll(){
        $.post(ajaxurl, { action: 'savol_veiculos_autosync_progress' }).done(function(resp){
            if (!resp || !resp.success) {
                return;
            }
            var p = resp.data || {};
            var percent = p.percent || 0;
            var message = p.message || 'Processando...';
            setProgress(percent, message);
            if (p.status === 'running' || p.status === 'queued') {
                wrap.show();
                btn.prop('disabled', true);
                setTimeout(poll, 1200);
                return;
            }
            if (p.status === 'done' || p.status === 'error') {
                wrap.show();
                btn.prop('disabled', false);
            }
        });
    }
    poll();
    btn.on('click', function(){
        btn.prop('disabled', true);
        wrap.show();
        setProgress(1, 'Iniciando sincronizacao...');
        $.post(ajaxurl, { action: 'savol_veiculos_run_autosync', nonce: '{$autosync_nonce}' })
            .done(function(resp){
                if (resp && resp.success) {
                    setProgress(1, resp.data && resp.data.message ? resp.data.message : 'Sincronizacao enfileirada.');
                    poll();
                    return;
                }
                var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Falha na sincronizacao.';
                setProgress(100, msg);
                btn.prop('disabled', false);
            })
            .fail(function(xhr){
                var msg = 'Falha na sincronizacao.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    msg = xhr.responseJSON.data.message;
                }
                setProgress(100, msg);
                btn.prop('disabled', false);
            });
    });
});
JS;
            wp_add_inline_script('jquery-core', $autosync_js);
        }
    }

    public static function register_admin_menu(): void {
        if (self::is_seller()) {
            add_menu_page(
                'Meus leads',
                'Venda Seu Carro',
                self::SELLER_CAPABILITY,
                self::SELLER_LEADS_MENU_SLUG,
                [__CLASS__, 'render_seller_leads_page'],
                'dashicons-id',
                27
            );
        }

        add_submenu_page(
            null,
            'Vendedores',
            'Vendedores',
            self::MANAGE_DELEGATION_CAPABILITY,
            self::SELLER_MENU_SLUG,
            [__CLASS__, 'render_sellers_page']
        );

        add_submenu_page(
            'edit.php?post_type=' . self::SELL_YOUR_CAR_POST_TYPE,
            'Vendedores',
            'Vendedores',
            self::MANAGE_DELEGATION_CAPABILITY,
            self::SELLER_MENU_SLUG,
            [__CLASS__, 'render_sellers_page']
        );

        add_submenu_page(
            'edit.php?post_type=' . self::POST_TYPE,
            'AutoSync',
            'AutoSync',
            'manage_options',
            'savol-veiculos-autosync',
            [__CLASS__, 'render_autosync_page']
        );
    }

    public static function render_vehicle_admin_filters(): void {
        global $typenow;
        if ($typenow !== self::POST_TYPE) {
            return;
        }

        $selected_unit = isset($_GET['savol_veiculo_unidade_filter'])
            ? absint(wp_unslash($_GET['savol_veiculo_unidade_filter']))
            : 0;
        $plate = isset($_GET['savol_veiculo_placa_filter'])
            ? sanitize_text_field((string) wp_unslash($_GET['savol_veiculo_placa_filter']))
            : '';

        $terms = get_terms([
            'taxonomy' => 'veiculo_unidade',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ]);

        if (!is_wp_error($terms) && !empty($terms)) {
            echo '<label class="screen-reader-text" for="savol_veiculo_unidade_filter">Filtrar por unidade</label>';
            echo '<select name="savol_veiculo_unidade_filter" id="savol_veiculo_unidade_filter">';
            echo '<option value="">Todas as unidades</option>';
            foreach ($terms as $term) {
                printf(
                    '<option value="%1$d"%2$s>%3$s</option>',
                    (int) $term->term_id,
                    selected($selected_unit, (int) $term->term_id, false),
                    esc_html((string) $term->name)
                );
            }
            echo '</select>';
        }

        printf(
            '<label class="screen-reader-text" for="savol_veiculo_placa_filter">Buscar por placa</label><input type="search" name="savol_veiculo_placa_filter" id="savol_veiculo_placa_filter" value="%s" placeholder="Placa" style="width: 110px;" />',
            esc_attr($plate)
        );
    }

    public static function apply_vehicle_admin_filters(\WP_Query $query): void {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        $post_type = $query->get('post_type');
        if (!$post_type && isset($_GET['post_type'])) {
            $post_type = sanitize_key((string) wp_unslash($_GET['post_type']));
        }
        if (is_array($post_type)) {
            $post_type = reset($post_type);
        }
        if ($post_type !== self::POST_TYPE) {
            return;
        }

        $selected_unit = isset($_GET['savol_veiculo_unidade_filter'])
            ? absint(wp_unslash($_GET['savol_veiculo_unidade_filter']))
            : 0;
        if ($selected_unit > 0) {
            $existing_tax_query = $query->get('tax_query');
            $tax_query = is_array($existing_tax_query) ? $existing_tax_query : [];
            $tax_query[] = [
                'taxonomy' => 'veiculo_unidade',
                'field' => 'term_id',
                'terms' => [$selected_unit],
            ];
            $query->set('tax_query', $tax_query);
        }

        $plate = isset($_GET['savol_veiculo_placa_filter'])
            ? self::normalize_plate(sanitize_text_field((string) wp_unslash($_GET['savol_veiculo_placa_filter'])))
            : '';
        if ($plate !== '') {
            $existing_meta_query = $query->get('meta_query');
            $meta_query = is_array($existing_meta_query) ? $existing_meta_query : [];
            $meta_query[] = [
                'key' => 'placa',
                'value' => $plate,
                'compare' => 'LIKE',
            ];
            $query->set('meta_query', $meta_query);
        }
    }

    public static function register_vehicle_sortable_columns(array $columns): array {
        foreach (array_keys(self::taxonomies()) as $taxonomy) {
            $column = 'taxonomy-' . $taxonomy;
            if (isset($columns[$column])) {
                $columns[$column] = 'savol_taxonomy_' . $taxonomy;
            }
        }

        return $columns;
    }

    public static function apply_vehicle_taxonomy_ordering(array $clauses, \WP_Query $query): array {
        if (!is_admin() || !$query->is_main_query()) {
            return $clauses;
        }

        $post_type = $query->get('post_type');
        if (is_array($post_type)) {
            $post_type = reset($post_type);
        }
        if ($post_type !== self::POST_TYPE) {
            return $clauses;
        }

        $orderby = (string) $query->get('orderby');
        $prefix = 'savol_taxonomy_';
        if (!str_starts_with($orderby, $prefix)) {
            return $clauses;
        }

        $taxonomy = substr($orderby, strlen($prefix));
        if (!array_key_exists($taxonomy, self::taxonomies())) {
            return $clauses;
        }

        global $wpdb;
        $alias = 'savol_taxonomy_sort';
        if (strpos($clauses['join'], $alias) === false) {
            $clauses['join'] .= $wpdb->prepare(
                " LEFT JOIN (
                    SELECT tr.object_id, MIN(t.name) AS sort_name
                    FROM {$wpdb->term_relationships} tr
                    INNER JOIN {$wpdb->term_taxonomy} tt
                        ON tt.term_taxonomy_id = tr.term_taxonomy_id
                        AND tt.taxonomy = %s
                    INNER JOIN {$wpdb->terms} t ON t.term_id = tt.term_id
                    GROUP BY tr.object_id
                ) {$alias} ON {$wpdb->posts}.ID = {$alias}.object_id",
                $taxonomy
            );
        }

        $order = strtoupper((string) $query->get('order')) === 'DESC' ? 'DESC' : 'ASC';
        $clauses['orderby'] = "COALESCE({$alias}.sort_name, '') {$order}, {$wpdb->posts}.post_title ASC";

        return $clauses;
    }

    public static function restrict_seller_admin(): void {
        $script = basename((string) ($_SERVER['PHP_SELF'] ?? ''));
        if ($script === 'admin.php') {
            $page = isset($_GET['page']) ? sanitize_text_field((string) wp_unslash($_GET['page'])) : '';
            if ($page === self::SELLER_MENU_SLUG && self::can_manage_sell_your_car_delegation()) {
                return;
            }
        }

        if ($script === 'edit.php') {
            $page = isset($_GET['page']) ? sanitize_text_field((string) wp_unslash($_GET['page'])) : '';
            if ($page === self::SELLER_MENU_SLUG && self::can_manage_sell_your_car_delegation()) {
                wp_safe_redirect(self::sellers_admin_url());
                exit;
            }
        }

        if (!self::is_seller() || current_user_can('manage_options') || wp_doing_ajax()) {
            return;
        }

        if (in_array($script, ['admin-ajax.php', 'async-upload.php'], true)) {
            return;
        }

        if ($script === 'index.php') {
            wp_safe_redirect(admin_url('admin.php?page=' . self::SELLER_LEADS_MENU_SLUG));
            exit;
        }

        if ($script === 'admin.php') {
            if (isset($_GET['page']) && sanitize_text_field((string) wp_unslash($_GET['page'])) === self::SELLER_LEADS_MENU_SLUG) {
                return;
            }
        }

        if ($script === 'admin-post.php') {
            $action = isset($_REQUEST['action']) ? sanitize_key((string) wp_unslash($_REQUEST['action'])) : '';
            if (in_array($action, ['savol_vsc_export_pdf'], true)) {
                return;
            }
        }

        wp_die('Acesso restrito aos leads delegados.', 'Venda Seu Carro', ['response' => 403]);
    }

    public static function render_sellers_page(): void {
        if (!self::can_manage_sell_your_car_delegation()) {
            wp_die('Sem permissao.');
        }

        $message = isset($_GET['savol_msg']) ? sanitize_text_field((string) wp_unslash($_GET['savol_msg'])) : '';
        $sellers = self::get_sellers();
        $leads = self::get_sell_your_car_leads();
        ?>
        <div class="wrap savol-vsc-admin">
            <h1>Venda Seu Carro - Vendedores</h1>
            <?php if ($message !== '') : ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html(self::seller_notice_label($message)); ?></p></div>
            <?php endif; ?>

            <div class="savol-vsc-cards">
                <div class="savol-vsc-card">
                    <h2>Criar vendedor</h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="savol_vsc_create_seller">
                        <?php wp_nonce_field('savol_vsc_create_seller'); ?>
                        <p><label>Nome<br><input class="regular-text" type="text" name="seller_name" required></label></p>
                        <p><label>E-mail<br><input class="regular-text" type="email" name="seller_email" required></label></p>
                        <p><label>Senha inicial<br><input class="regular-text" type="text" name="seller_password" placeholder="Gerar automaticamente se vazio"></label></p>
                        <p><button type="submit" class="button button-primary">Criar vendedor</button></p>
                    </form>
                </div>

                <div class="savol-vsc-card">
                    <h2>Delegar lead</h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="savol_vsc_assign_lead">
                        <?php wp_nonce_field('savol_vsc_assign_lead_0'); ?>
                        <p>
                            <label>Lead<br>
                                <select name="lead_id" required>
                                    <option value="">Selecione</option>
                                    <?php foreach ($leads as $lead) : ?>
                                        <option value="<?php echo esc_attr((string) $lead->ID); ?>"><?php echo esc_html(self::lead_short_label((int) $lead->ID)); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </p>
                        <p>
                            <label>Vendedor<br>
                                <select name="seller_id" required>
                                    <option value="">Selecione</option>
                                    <?php foreach ($sellers as $seller) : ?>
                                        <option value="<?php echo esc_attr((string) $seller->ID); ?>"><?php echo esc_html($seller->display_name . ' - ' . $seller->user_email); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </label>
                        </p>
                        <p><label><input type="checkbox" name="send_email" value="1" checked> Enviar e-mail com PDF ao vendedor</label></p>
                        <p><button type="submit" class="button button-primary">Delegar lead</button></p>
                    </form>
                </div>
            </div>

            <div class="savol-vsc-card">
                <h2>Leads recebidos</h2>
                <?php self::render_assignment_table($leads); ?>
            </div>
        </div>
        <?php
    }

    public static function render_seller_leads_page(): void {
        if (!self::is_seller()) {
            wp_die('Sem permissao.');
        }

        $lead_id = isset($_GET['lead_id']) ? absint($_GET['lead_id']) : 0;
        $leads = self::get_assigned_leads(get_current_user_id());
        ?>
        <div class="wrap savol-vsc-admin">
            <h1>Meus leads - Venda Seu Carro</h1>

            <?php if ($lead_id > 0 && self::can_view_assigned_lead($lead_id)) : ?>
                <div class="savol-vsc-card">
                    <h2><?php echo esc_html(self::lead_short_label($lead_id)); ?></h2>
                    <p><a class="button button-primary" target="_blank" href="<?php echo esc_url(self::lead_pdf_url($lead_id)); ?>">Exportar PDF</a></p>
                    <?php self::render_lead_details($lead_id); ?>
                </div>
            <?php endif; ?>

            <div class="savol-vsc-card">
                <h2>Leads delegados para voce</h2>
                <?php if (empty($leads)) : ?>
                    <p>Nenhum lead delegado ainda.</p>
                <?php else : ?>
                    <table class="widefat striped">
                        <thead><tr><th>Lead</th><th>Cliente</th><th>Veiculo</th><th>Recebido</th><th></th></tr></thead>
                        <tbody>
                            <?php foreach ($leads as $lead) : ?>
                                <tr>
                                    <td><?php echo esc_html((string) get_post_meta($lead->ID, 'savol_vsc_protocol', true)); ?></td>
                                    <td><?php echo esc_html((string) get_post_meta($lead->ID, 'savol_vsc_seller_full_name', true)); ?></td>
                                    <td><?php echo esc_html(self::lead_vehicle_label((int) $lead->ID)); ?></td>
                                    <td><?php echo esc_html(get_the_date('d/m/Y H:i', $lead)); ?></td>
                                    <td><a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=' . self::SELLER_LEADS_MENU_SLUG . '&lead_id=' . (int) $lead->ID)); ?>">Ver</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    public static function handle_create_seller(): void {
        if (!self::can_manage_sell_your_car_delegation()) {
            wp_die('Sem permissao.');
        }
        check_admin_referer('savol_vsc_create_seller');

        $name = sanitize_text_field((string) wp_unslash($_POST['seller_name'] ?? ''));
        $email = sanitize_email((string) wp_unslash($_POST['seller_email'] ?? ''));
        $password = sanitize_text_field((string) wp_unslash($_POST['seller_password'] ?? ''));

        if ($email === '' || !is_email($email)) {
            self::redirect_sellers('email_invalido');
        }
        if ($password === '') {
            $password = wp_generate_password(14, true);
        }

        $user_id = email_exists($email);
        if (!$user_id) {
            $email_parts = explode('@', $email);
            $username = sanitize_user((string) ($email_parts[0] ?? 'vendedor'), true);
            if ($username === '') {
                $username = 'vendedor_' . wp_generate_password(6, false, false);
            }
            $base_username = $username;
            $suffix = 1;
            while (username_exists($username)) {
                $username = $base_username . '_' . $suffix;
                $suffix++;
            }
            $user_id = wp_create_user($username, $password, $email);
        }

        if (is_wp_error($user_id)) {
            self::redirect_sellers('erro_usuario');
        }

        $user = get_user_by('id', (int) $user_id);
        if ($user) {
            $user->set_role(self::SELLER_ROLE);
            wp_update_user([
                'ID' => (int) $user_id,
                'display_name' => $name !== '' ? $name : $email,
                'first_name' => $name,
            ]);
        }

        self::redirect_sellers('vendedor_salvo');
    }

    public static function handle_assign_lead(): void {
        if (!self::can_manage_sell_your_car_delegation()) {
            wp_die('Sem permissao.');
        }

        $lead_id = absint($_POST['lead_id'] ?? 0);
        $nonce = isset($_POST['_wpnonce']) ? sanitize_text_field((string) wp_unslash($_POST['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'savol_vsc_assign_lead_' . $lead_id) && !wp_verify_nonce($nonce, 'savol_vsc_assign_lead_0')) {
            wp_die('Nonce invalido.');
        }

        $seller_id = absint($_POST['seller_id'] ?? 0);
        if (!self::is_sell_your_car_lead($lead_id) || !self::is_seller_user($seller_id)) {
            self::redirect_sellers('dados_invalidos');
        }

        update_post_meta($lead_id, self::ASSIGNED_SELLER_META, $seller_id);
        if (!empty($_POST['send_email'])) {
            self::send_lead_email($lead_id, $seller_id);
        }

        self::redirect_sellers('lead_delegado');
    }

    public static function handle_email_lead(): void {
        $lead_id = isset($_GET['lead_id']) ? absint($_GET['lead_id']) : 0;
        if (!self::can_manage_sell_your_car_delegation()) {
            wp_die('Sem permissao.');
        }
        check_admin_referer('savol_vsc_email_lead_' . $lead_id);

        $seller_id = absint(get_post_meta($lead_id, self::ASSIGNED_SELLER_META, true));
        if ($seller_id <= 0 || !self::send_lead_email($lead_id, $seller_id)) {
            self::redirect_sellers('email_erro');
        }
        self::redirect_sellers('email_enviado');
    }

    public static function handle_export_pdf(): void {
        $lead_id = isset($_GET['lead_id']) ? absint($_GET['lead_id']) : 0;
        if (!self::can_manage_sell_your_car_delegation() && !self::can_view_assigned_lead($lead_id)) {
            wp_die('Sem permissao.');
        }
        check_admin_referer('savol_vsc_pdf_' . $lead_id);

        nocache_headers();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="lead-venda-seu-carro-' . $lead_id . '.pdf"');
        echo self::generate_lead_pdf($lead_id);
        exit;
    }

    private static function redirect_sellers(string $message): void {
        wp_safe_redirect(self::sellers_admin_url(['savol_msg' => $message]));
        exit;
    }

    private static function sellers_admin_url(array $args = []): string {
        $query = array_merge(['page' => self::SELLER_MENU_SLUG], $args);

        return add_query_arg($query, admin_url('admin.php'));
    }

    private static function seller_notice_label(string $message): string {
        $labels = [
            'vendedor_salvo' => 'Vendedor salvo com acesso restrito.',
            'lead_delegado' => 'Lead delegado com sucesso.',
            'email_enviado' => 'E-mail enviado ao vendedor.',
            'email_invalido' => 'Informe um e-mail valido.',
            'erro_usuario' => 'Nao foi possivel criar ou atualizar o vendedor.',
            'dados_invalidos' => 'Selecione um lead e um vendedor validos.',
            'email_erro' => 'Nao foi possivel enviar o e-mail.',
        ];

        return $labels[$message] ?? 'Operacao concluida.';
    }

    private static function get_sellers(): array {
        return get_users([
            'role' => self::SELLER_ROLE,
            'orderby' => 'display_name',
            'order' => 'ASC',
        ]);
    }

    private static function get_sell_your_car_leads(): array {
        return get_posts([
            'post_type' => self::SELL_YOUR_CAR_POST_TYPE,
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'posts_per_page' => 200,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
        ]);
    }

    private static function get_assigned_leads(int $seller_id): array {
        if ($seller_id <= 0) {
            return [];
        }

        return get_posts([
            'post_type' => self::SELL_YOUR_CAR_POST_TYPE,
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'posts_per_page' => 200,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'meta_query' => [
                [
                    'key' => self::ASSIGNED_SELLER_META,
                    'value' => (string) $seller_id,
                    'compare' => '=',
                ],
            ],
        ]);
    }

    private static function render_assignment_table(array $leads): void {
        if (empty($leads)) {
            echo '<p>Nenhum lead encontrado.</p>';
            return;
        }
        ?>
        <table class="widefat striped">
            <thead><tr><th>Lead</th><th>Cliente</th><th>Veiculo</th><th>Responsavel</th><th>Acoes</th></tr></thead>
            <tbody>
                <?php foreach ($leads as $lead) : ?>
                    <?php
                    $seller_id = absint(get_post_meta($lead->ID, self::ASSIGNED_SELLER_META, true));
                    $seller = $seller_id > 0 ? get_user_by('id', $seller_id) : null;
                    ?>
                    <tr>
                        <td><?php echo esc_html(self::lead_short_label((int) $lead->ID)); ?></td>
                        <td><?php echo esc_html((string) get_post_meta($lead->ID, 'savol_vsc_seller_full_name', true)); ?></td>
                        <td><?php echo esc_html(self::lead_vehicle_label((int) $lead->ID)); ?></td>
                        <td><?php echo $seller ? esc_html($seller->display_name . ' - ' . $seller->user_email) : '<span style="color:#777;">Nao delegado</span>'; ?></td>
                        <td>
                            <a class="button button-small" href="<?php echo esc_url(get_edit_post_link((int) $lead->ID, '')); ?>">Abrir</a>
                            <?php if ($seller) : ?>
                                <a class="button button-small" href="<?php echo esc_url(self::lead_email_url((int) $lead->ID)); ?>">Enviar e-mail</a>
                            <?php endif; ?>
                            <a class="button button-small" target="_blank" href="<?php echo esc_url(self::lead_pdf_url((int) $lead->ID)); ?>">PDF</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    private static function render_lead_details(int $lead_id): void {
        foreach (self::lead_sections($lead_id) as $title => $items) {
            echo '<h2>' . esc_html($title) . '</h2>';
            echo '<table class="widefat striped"><tbody>';
            foreach ($items as $label => $value) {
                echo '<tr><th style="width:190px;">' . esc_html($label) . '</th><td>' . esc_html($value !== '' ? $value : '-') . '</td></tr>';
            }
            echo '</tbody></table>';
        }
    }

    private static function lead_sections(int $lead_id): array {
        return [
            'Resumo' => [
                'Protocolo' => (string) get_post_meta($lead_id, 'savol_vsc_protocol', true),
                'Recebido em' => (string) get_post_meta($lead_id, 'savol_vsc_received_at', true),
                'Origem' => (string) get_post_meta($lead_id, 'savol_vsc_source_channel', true),
                'Pagina' => self::normalize_public_page_url((string) get_post_meta($lead_id, 'savol_vsc_source_page_url', true)),
            ],
            'Cliente' => [
                'Nome' => (string) get_post_meta($lead_id, 'savol_vsc_seller_full_name', true),
                'E-mail' => (string) get_post_meta($lead_id, 'savol_vsc_seller_email', true),
                'Telefone' => (string) get_post_meta($lead_id, 'savol_vsc_seller_phone', true),
                'CPF' => (string) get_post_meta($lead_id, 'savol_vsc_seller_cpf', true),
                'WhatsApp' => (string) get_post_meta($lead_id, 'savol_vsc_seller_whatsapp', true),
                'Cidade/UF' => trim((string) get_post_meta($lead_id, 'savol_vsc_seller_city', true) . ' / ' . (string) get_post_meta($lead_id, 'savol_vsc_seller_state', true), ' /'),
                'Preferencia de contato' => (string) get_post_meta($lead_id, 'savol_vsc_seller_contact_period', true),
                'Canal de contato' => (string) get_post_meta($lead_id, 'savol_vsc_seller_contact_channel', true),
            ],
            'Veiculo' => [
                'Marca' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_brand', true),
                'Modelo' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_model', true),
                'Versao' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_version', true),
                'Placa' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_plate', true),
                'Ano' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_year', true),
                'Ano modelo' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_model_year', true),
                'KM' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_km', true),
                'Cambio' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_transmission', true),
                'Combustivel' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_fuel', true),
                'Cor' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_color', true),
                'Preco desejado' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_desired_price', true),
                'Observacoes' => (string) get_post_meta($lead_id, 'savol_vsc_vehicle_notes', true),
            ],
        ];
    }

    private static function lead_short_label(int $lead_id): string {
        $protocol = trim((string) get_post_meta($lead_id, 'savol_vsc_protocol', true));
        $client = trim((string) get_post_meta($lead_id, 'savol_vsc_seller_full_name', true));
        $vehicle = self::lead_vehicle_label($lead_id);
        return trim(($protocol !== '' ? $protocol . ' - ' : '') . ($client !== '' ? $client . ' - ' : '') . $vehicle, ' -');
    }

    private static function lead_vehicle_label(int $lead_id): string {
        $parts = array_filter([
            (string) get_post_meta($lead_id, 'savol_vsc_vehicle_brand', true),
            (string) get_post_meta($lead_id, 'savol_vsc_vehicle_model', true),
            (string) get_post_meta($lead_id, 'savol_vsc_vehicle_model_year', true) ?: (string) get_post_meta($lead_id, 'savol_vsc_vehicle_year', true),
        ]);

        return !empty($parts) ? implode(' ', $parts) : get_the_title($lead_id);
    }

    private static function lead_email_url(int $lead_id): string {
        return wp_nonce_url(admin_url('admin-post.php?action=savol_vsc_email_lead&lead_id=' . $lead_id), 'savol_vsc_email_lead_' . $lead_id);
    }

    private static function lead_pdf_url(int $lead_id): string {
        return wp_nonce_url(admin_url('admin-post.php?action=savol_vsc_export_pdf&lead_id=' . $lead_id), 'savol_vsc_pdf_' . $lead_id);
    }

    private static function send_lead_email(int $lead_id, int $seller_id): bool {
        $seller = get_user_by('id', $seller_id);
        if (!$seller || !is_email($seller->user_email) || !self::is_sell_your_car_lead($lead_id)) {
            return false;
        }

        $temp_pdf = wp_tempnam('lead-venda-seu-carro-' . $lead_id . '.pdf');
        $attachments = [];
        if ($temp_pdf) {
            file_put_contents($temp_pdf, self::generate_lead_pdf($lead_id));
            $attachments[] = $temp_pdf;
        }

        $sent = wp_mail(
            $seller->user_email,
            'Novo lead Venda Seu Carro: ' . self::lead_vehicle_label($lead_id),
            self::lead_email_html($lead_id, $seller),
            ['Content-Type: text/html; charset=UTF-8'],
            $attachments
        );

        if ($temp_pdf && file_exists($temp_pdf)) {
            unlink($temp_pdf);
        }

        return $sent;
    }

    private static function lead_email_html(int $lead_id, \WP_User $seller): string {
        $detail_url = admin_url('admin.php?page=' . self::SELLER_LEADS_MENU_SLUG . '&lead_id=' . $lead_id);
        ob_start();
        ?>
        <div style="font-family:Arial,sans-serif;background:#f1f5f9;padding:24px;color:#0f172a">
            <div style="max-width:720px;margin:0 auto;background:#fff;border:1px solid #dbe4ef;border-radius:12px;overflow:hidden">
                <div style="background:#111827;color:#fff;padding:22px 26px">
                    <p style="margin:0 0 6px;color:#93c5fd;font-size:12px;font-weight:700;text-transform:uppercase">SAVOL Seminovos</p>
                    <h1 style="margin:0;font-size:24px">Novo lead Venda Seu Carro</h1>
                </div>
                <div style="padding:24px 26px">
                    <p>Ola, <?php echo esc_html($seller->display_name); ?>. Um lead foi delegado para seu acompanhamento.</p>
                    <h2 style="font-size:18px"><?php echo esc_html(self::lead_short_label($lead_id)); ?></h2>
                    <?php foreach (self::lead_sections($lead_id) as $title => $items) : ?>
                        <h3 style="font-size:15px;margin:20px 0 8px;color:#1d4ed8"><?php echo esc_html($title); ?></h3>
                        <table style="width:100%;border-collapse:collapse">
                            <?php foreach ($items as $label => $value) : ?>
                                <tr>
                                    <td style="border-top:1px solid #e2e8f0;padding:8px 0;color:#64748b;width:38%"><?php echo esc_html($label); ?></td>
                                    <td style="border-top:1px solid #e2e8f0;padding:8px 0;font-weight:700"><?php echo esc_html($value !== '' ? $value : '-'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    <?php endforeach; ?>
                    <p style="margin-top:24px"><a href="<?php echo esc_url($detail_url); ?>" style="background:#2563eb;color:#fff;text-decoration:none;border-radius:8px;padding:12px 16px;font-weight:700;display:inline-block">Abrir no painel</a></p>
                </div>
            </div>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function generate_lead_pdf(int $lead_id): string {
        $lines = [
            ['SAVOL Seminovos', 22],
            ['Lead Venda Seu Carro', 14],
            [self::lead_short_label($lead_id), 12],
            ['', 10],
        ];

        foreach (self::lead_sections($lead_id) as $title => $items) {
            $lines[] = [$title, 14];
            foreach ($items as $label => $value) {
                foreach (self::wrap_pdf_text($label . ': ' . ($value !== '' ? $value : '-'), 92) as $wrapped) {
                    $lines[] = [$wrapped, 10];
                }
            }
            $lines[] = ['', 6];
        }

        return self::simple_pdf($lines);
    }

    private static function wrap_pdf_text(string $text, int $limit): array {
        $text = self::pdf_clean_text($text);
        return strlen($text) <= $limit ? [$text] : explode("\n", wordwrap($text, $limit, "\n", true));
    }

    private static function simple_pdf(array $lines): string {
        $content = "0.92 0.95 0.99 rg\n0 0 595 842 re f\n0.07 0.09 0.16 rg\n0 770 595 72 re f\n";
        $y = 804;
        foreach ($lines as $line) {
            [$text, $size] = $line;
            if ($text === '') {
                $y -= max(8, (int) $size);
                continue;
            }
            if ($y < 54) {
                break;
            }
            $x = ((int) $size >= 14 && $y > 760) ? 44 : 54;
            $color = $y > 760 ? '1 1 1 rg' : (((int) $size >= 14) ? '0.10 0.22 0.46 rg' : '0.10 0.12 0.18 rg');
            $content .= $color . "\nBT /F1 " . (int) $size . " Tf {$x} {$y} Td (" . self::pdf_escape($text) . ") Tj ET\n";
            $y -= ((int) $size >= 14) ? 22 : 15;
        }
        $content .= "0.64 0.70 0.78 rg\nBT /F1 9 Tf 54 28 Td (Documento gerado pelo plugin Venda Seu Carro) Tj ET\n";

        $objects = [
            "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
            "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
            "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n",
            "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n",
            "5 0 obj\n<< /Length " . strlen($content) . " >>\nstream\n{$content}\nendstream\nendobj\n",
        ];
        $pdf = "%PDF-1.4\n";
        $offsets = [0];
        foreach ($objects as $object) {
            $offsets[] = strlen($pdf);
            $pdf .= $object;
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\nstartxref\n{$xref}\n%%EOF";
        return $pdf;
    }

    private static function pdf_clean_text(string $text): string {
        $text = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES, 'UTF-8');
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
        return $converted !== false ? $converted : preg_replace('/[^\x20-\x7E]/', '', $text);
    }

    private static function pdf_escape(string $text): string {
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], self::pdf_clean_text($text));
    }

    private static function is_sell_your_car_lead(int $lead_id): bool {
        return $lead_id > 0 && get_post_type($lead_id) === self::SELL_YOUR_CAR_POST_TYPE;
    }

    private static function is_seller_user(int $user_id): bool {
        $user = get_user_by('id', $user_id);
        return $user instanceof \WP_User && in_array(self::SELLER_ROLE, (array) $user->roles, true);
    }

    private static function can_view_assigned_lead(int $lead_id): bool {
        return self::is_sell_your_car_lead($lead_id)
            && self::is_seller()
            && absint(get_post_meta($lead_id, self::ASSIGNED_SELLER_META, true)) === get_current_user_id();
    }

    private static function is_seller(): bool {
        $user = wp_get_current_user();
        return $user && in_array(self::SELLER_ROLE, (array) $user->roles, true) && current_user_can(self::SELLER_CAPABILITY);
    }

    private static function is_gestor(): bool {
        $user = wp_get_current_user();
        return $user instanceof \WP_User && in_array(self::GESTOR_ROLE, (array) $user->roles, true);
    }

    private static function can_manage_sell_your_car_delegation(): bool {
        return current_user_can('manage_options')
            || self::is_gestor()
            || current_user_can(self::MANAGE_DELEGATION_CAPABILITY)
            || current_user_can('edit_venda_carro_leads')
            || current_user_can('savol_access_dashboard');
    }

    public static function render_autosync_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $sync_status = isset($_GET['sync']) ? sanitize_text_field((string) $_GET['sync']) : '';
        $saved_status = isset($_GET['saved']) ? sanitize_text_field((string) $_GET['saved']) : '';
        ?>
        <div class="wrap">
            <h1>AutoSync de Veiculos</h1>
            <?php if ($saved_status === '1') : ?>
                <div class="notice notice-success is-dismissible"><p>Token salvo com sucesso.</p></div>
            <?php endif; ?>
            <?php if ($sync_status === 'ok') : ?>
                <div class="notice notice-success is-dismissible"><p>Sincronizacao concluida.</p></div>
            <?php elseif ($sync_status === 'queued') : ?>
                <div class="notice notice-info is-dismissible"><p>Importacao enfileirada. O processamento continuara em segundo plano.</p></div>
            <?php elseif ($sync_status === 'error') : ?>
                <div class="notice notice-error is-dismissible"><p>Falha na sincronizacao. Verifique o token e tente novamente.</p></div>
                <?php $last_error = (string) get_option(self::AUTOSYNC_LAST_ERROR_OPTION, ''); ?>
                <?php if ($last_error !== '') : ?>
                    <div class="notice notice-warning"><p><strong>Detalhe:</strong> <?php echo esc_html($last_error); ?></p></div>
                <?php endif; ?>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="savol_veiculos_save_autosync" />
                <?php wp_nonce_field('savol_veiculos_save_autosync', 'savol_veiculos_autosync_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="savol_autosync_endpoint">URL da API</label></th>
                        <td>
                            <input type="url" id="savol_autosync_endpoint" name="savol_autosync_endpoint" class="regular-text" value="<?php echo esc_attr(self::get_autosync_endpoint()); ?>" />
                            <p class="description">Rota do estoque para sincronizacao (ex.: https://sync-backend.autoavaliar.com.br/vehicle/stock).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="savol_autosync_token">Token da API</label></th>
                        <td>
                            <input type="password" id="savol_autosync_token" name="savol_autosync_token" class="regular-text" autocomplete="new-password" />
                            <p class="description">O token fica armazenado de forma protegida no banco e nao e exibido no painel.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="savol_autosync_entity_ids">IDs de empresa/grupo</label></th>
                        <td>
                            <textarea id="savol_autosync_entity_ids" name="savol_autosync_entity_ids" rows="4" class="large-text code" placeholder="18882, 25813"><?php echo esc_textarea(self::get_autosync_entity_ids_text()); ?></textarea>
                            <p class="description">Opcional. Informe um ID de grupo ou varios IDs de empresas, separados por virgula, espaco ou linha. O filtro sera aplicado nas chaves do JSON retornado pela API.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="savol_autosync_cnpjs">CNPJs</label></th>
                        <td>
                            <textarea id="savol_autosync_cnpjs" name="savol_autosync_cnpjs" rows="4" class="large-text code" placeholder="5218146000123"><?php echo esc_textarea(self::get_autosync_cnpjs_text()); ?></textarea>
                            <p class="description">Opcional. Informe um ou varios CNPJs, separados por virgula, espaco ou linha. Apenas numeros serao salvos; o filtro sera aplicado nas chaves do JSON retornado pela API.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Situacoes APOLO permitidas</th>
                        <td>
                            <fieldset>
                                <?php $allowed_situations = self::get_apolo_allowed_situations(); ?>
                                <?php foreach (self::apolo_situation_choices() as $situation) : ?>
                                    <label style="display:inline-block;margin-right:16px;margin-bottom:6px;">
                                        <input type="checkbox" name="savol_apolo_allowed_situations[]" value="<?php echo esc_attr($situation); ?>" <?php checked(in_array($situation, $allowed_situations, true)); ?> />
                                        <?php echo esc_html($situation); ?>
                                    </label>
                                <?php endforeach; ?>
                            </fieldset>
                            <label for="savol_apolo_allowed_situations_extra" style="display:block;margin-top:8px;">Outras situacoes</label>
                            <input type="text" id="savol_apolo_allowed_situations_extra" name="savol_apolo_allowed_situations_extra" class="regular-text code" value="<?php echo esc_attr(self::get_apolo_allowed_situations_extra_text()); ?>" placeholder="Ex.: XX, YY" />
                            <p class="description">Selecione as situacoes do APOLO que podem ser publicadas no site. Padrao: ES e ED.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="savol_apolo_company_resellers">Empresas / revendas APOLO permitidas</label></th>
                        <td>
                            <textarea id="savol_apolo_company_resellers" name="savol_apolo_company_resellers" rows="5" class="large-text code" placeholder="16/1&#10;17/1&#10;1/1&#10;1/2"><?php echo esc_textarea(self::get_apolo_allowed_company_resellers_text()); ?></textarea>
                            <p class="description">Informe um par empresa/revenda por linha. Tambem aceita formatos como <code>16/1</code>, <code>16:1</code> ou <code>empresa 16 revenda 1</code>.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Salvar configuracoes'); ?>
            </form>

            <p>
                <button type="button" class="button button-primary" id="savol-autosync-run">Sincronizar estoque agora</button>
                <span class="description" style="margin-left:8px;">A API permite apenas uma chamada a cada 3 minutos.</span>
            </p>
            <p class="description">Sincronizacao automatica configurada para executar a cada 40 minutos. O botao acima permanece disponivel para atualizacoes manuais.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:10px 0 18px;">
                <input type="hidden" name="action" value="savol_veiculos_refresh_unidades" />
                <?php wp_nonce_field('savol_veiculos_refresh_unidades', 'savol_veiculos_refresh_unidades_nonce'); ?>
                <?php submit_button('Reaplicar contatos das unidades', 'secondary', 'submit', false); ?>
            </form>
            <div id="savol-autosync-progress-wrap" style="display:none;max-width:560px;">
                <div style="height:18px;background:#e5e7eb;border-radius:999px;overflow:hidden;">
                    <div id="savol-autosync-progress-bar" style="height:100%;width:0;background:#2271b1;transition:width .2s ease;"></div>
                </div>
                <p id="savol-autosync-progress-text">Aguardando...</p>
            </div>
            <?php wp_nonce_field('savol_veiculos_run_autosync', 'savol_veiculos_run_nonce'); ?>

            <hr style="margin:24px 0;" />
            <h2>Importacao Manual (sem API)</h2>
            <p class="description">Cole aqui o JSON bruto com formato <code>vehicles.rows</code> para importar sem depender da autenticacao da API.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="savol_veiculos_import_json" />
                <?php wp_nonce_field('savol_veiculos_import_json', 'savol_veiculos_import_json_nonce'); ?>
                <textarea name="savol_autosync_json_payload" rows="12" style="width:100%;max-width:960px;"></textarea>
                <p><?php submit_button('Importar JSON manualmente', 'secondary', 'submit', false); ?></p>
            </form>
        </div>
        <?php
    }

    public static function handle_save_autosync(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissao.');
        }
        if (!isset($_POST['savol_veiculos_autosync_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['savol_veiculos_autosync_nonce'])), 'savol_veiculos_save_autosync')) {
            wp_die('Nonce invalido.');
        }

        $token = isset($_POST['savol_autosync_token']) ? trim((string) wp_unslash($_POST['savol_autosync_token'])) : '';
        $endpoint = isset($_POST['savol_autosync_endpoint']) ? trim((string) wp_unslash($_POST['savol_autosync_endpoint'])) : '';
        $entity_ids = isset($_POST['savol_autosync_entity_ids']) ? self::normalize_autosync_list((string) wp_unslash($_POST['savol_autosync_entity_ids']), false) : [];
        $cnpjs = isset($_POST['savol_autosync_cnpjs']) ? self::normalize_autosync_list((string) wp_unslash($_POST['savol_autosync_cnpjs']), true) : [];
        $apolo_allowed_situations = isset($_POST['savol_apolo_allowed_situations'])
            ? self::normalize_apolo_situations((array) wp_unslash($_POST['savol_apolo_allowed_situations']))
            : [];
        $apolo_allowed_situations_extra = isset($_POST['savol_apolo_allowed_situations_extra'])
            ? self::normalize_apolo_situations_text((string) wp_unslash($_POST['savol_apolo_allowed_situations_extra']))
            : [];
        $apolo_company_resellers = isset($_POST['savol_apolo_company_resellers'])
            ? self::normalize_apolo_company_resellers((string) wp_unslash($_POST['savol_apolo_company_resellers']))
            : [];
        if ($endpoint !== '') {
            update_option(self::AUTOSYNC_ENDPOINT_OPTION, esc_url_raw($endpoint), false);
        }
        update_option(self::AUTOSYNC_ENTITY_IDS_OPTION, $entity_ids, false);
        update_option(self::AUTOSYNC_CNPJS_OPTION, $cnpjs, false);
        $apolo_allowed_situations = array_values(array_unique(array_merge($apolo_allowed_situations, $apolo_allowed_situations_extra)));
        update_option(self::APOLO_ALLOWED_SITUATIONS_OPTION, !empty($apolo_allowed_situations) ? $apolo_allowed_situations : self::APOLO_ALLOWED_SITUATIONS_DEFAULT, false);
        update_option(self::APOLO_ALLOWED_COMPANY_RESELLERS_OPTION, !empty($apolo_company_resellers) ? $apolo_company_resellers : self::APOLO_ALLOWED_COMPANY_RESELLERS_DEFAULT, false);
        if ($token !== '') {
            update_option(self::AUTOSYNC_OPTION, self::encrypt_token($token), false);
        }

        wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&saved=1'));
        exit;
    }

    public static function handle_run_autosync(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissao.');
        }
        if (!isset($_POST['savol_veiculos_run_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['savol_veiculos_run_nonce'])), 'savol_veiculos_run_autosync')) {
            wp_die('Nonce invalido.');
        }

        $token = self::decrypt_token((string) get_option(self::AUTOSYNC_OPTION, ''));
        if ($token === '') {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'Token vazio ou invalido.', false);
            wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&sync=error'));
            exit;
        }

        $ok = self::run_autosync($token);
        wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&sync=' . ($ok ? 'ok' : 'error')));
        exit;
    }

    public static function handle_run_autosync_ajax(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Sem permissao.'], 403);
        }
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'savol_veiculos_run_autosync')) {
            wp_send_json_error(['message' => 'Nonce invalido.'], 400);
        }

        $token = self::decrypt_token((string) get_option(self::AUTOSYNC_OPTION, ''));
        if ($token === '') {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'Token vazio ou invalido.', false);
            wp_send_json_error(['message' => 'Token vazio ou invalido.'], 400);
        }

        $progress = self::recover_stale_autosync_progress(
            get_option(self::AUTOSYNC_PROGRESS_OPTION, [])
        );
        if (is_array($progress) && isset($progress['status']) && in_array($progress['status'], ['queued', 'running'], true)) {
            wp_send_json_success(['message' => 'Sincronizacao ja em andamento.']);
        }
        $wait_seconds = self::get_autosync_api_wait_seconds();
        if ($wait_seconds > 0) {
            $message = self::format_autosync_wait_message($wait_seconds);
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
            wp_send_json_error(['message' => $message], 429);
        }

        self::update_progress([
            'status' => 'queued',
            'processed' => 0,
            'total' => 0,
            'percent' => 0,
            'message' => 'Sincronizacao enfileirada...',
        ]);

        self::schedule_autosync_cron();
        wp_send_json_success(['message' => 'Sincronizacao enfileirada e iniciada em segundo plano.']);
    }

    public static function handle_autosync_progress_ajax(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Sem permissao.'], 403);
        }
        $progress = self::recover_stale_autosync_progress(
            get_option(self::AUTOSYNC_PROGRESS_OPTION, [])
        );
        if (!is_array($progress)) {
            $progress = [];
        }
        wp_send_json_success($progress);
    }

    public static function run_autosync_cron_job(): void {
        if (self::process_queued_vehicles_batch()) {
            return;
        }

        $token = self::decrypt_token((string) get_option(self::AUTOSYNC_OPTION, ''));
        if ($token === '') {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'Token vazio ou invalido.', false);
            self::update_progress([
                'status' => 'error',
                'processed' => 0,
                'total' => 0,
                'percent' => 100,
                'message' => 'Token vazio ou invalido.',
            ]);
            return;
        }
        self::run_autosync($token);
    }

    public static function run_recurring_autosync_job(): void {
        $progress = self::recover_stale_autosync_progress(
            get_option(self::AUTOSYNC_PROGRESS_OPTION, [])
        );
        $status = is_array($progress) ? (string) ($progress['status'] ?? '') : '';
        if (in_array($status, ['queued', 'running'], true)) {
            return;
        }

        $token = self::decrypt_token((string) get_option(self::AUTOSYNC_OPTION, ''));
        if ($token === '' || self::get_autosync_api_wait_seconds() > 0) {
            return;
        }

        self::run_autosync($token);
    }

    public static function handle_refresh_unidades(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissao.');
        }
        if (!isset($_POST['savol_veiculos_refresh_unidades_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['savol_veiculos_refresh_unidades_nonce'])), 'savol_veiculos_refresh_unidades')) {
            wp_die('Nonce invalido.');
        }

        $terms = get_terms([
            'taxonomy' => 'veiculo_unidade',
            'hide_empty' => false,
        ]);
        if (!is_wp_error($terms)) {
            foreach ($terms as $term) {
                $contacts = self::find_unidade_contacts((string) $term->name);
                if (empty($contacts)) {
                    continue;
                }
                if (!empty($contacts['telefone'])) {
                    update_term_meta((int) $term->term_id, 'veiculo_unidade_telefone', $contacts['telefone']);
                }
                if (!empty($contacts['whatsapp'])) {
                    update_term_meta((int) $term->term_id, 'veiculo_unidade_whatsapp', $contacts['whatsapp']);
                }
                if (!empty($contacts['email'])) {
                    update_term_meta((int) $term->term_id, 'veiculo_unidade_email', $contacts['email']);
                }
                if (!empty($contacts['endereco'])) {
                    update_term_meta((int) $term->term_id, 'veiculo_unidade_endereco', $contacts['endereco']);
                }
            }
        }

        wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&saved=1'));
        exit;
    }

    public static function handle_import_json(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Sem permissao.');
        }
        if (!isset($_POST['savol_veiculos_import_json_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['savol_veiculos_import_json_nonce'])), 'savol_veiculos_import_json')) {
            wp_die('Nonce invalido.');
        }

        $raw_json = isset($_POST['savol_autosync_json_payload']) ? (string) wp_unslash($_POST['savol_autosync_json_payload']) : '';
        if (trim($raw_json) === '') {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'JSON manual vazio.', false);
            wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&sync=error'));
            exit;
        }

        $payload = json_decode($raw_json, true);
        if (!is_array($payload)) {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'JSON manual invalido.', false);
            wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&sync=error'));
            exit;
        }

        $ok = self::enqueue_vehicles_payload($payload, 'manual');
        if ($ok) {
            self::schedule_autosync_cron();
        }
        wp_safe_redirect(admin_url('edit.php?post_type=' . self::POST_TYPE . '&page=savol-veiculos-autosync&sync=' . ($ok ? 'queued' : 'error')));
        exit;
    }

    private static function run_autosync(string $token): bool {
        if (!self::acquire_autosync_api_lock()) {
            $message = 'Ja existe uma chamada AutoSync em andamento. Aguarde finalizar antes de iniciar outra.';
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
            self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
            return false;
        }

        try {
            $wait_seconds = self::get_autosync_api_wait_seconds();
            if ($wait_seconds > 0) {
                $message = self::format_autosync_wait_message($wait_seconds);
                update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
                self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
                return false;
            }

            update_option(self::AUTOSYNC_LAST_API_CALL_OPTION, time(), false);
            return self::request_autosync_stock($token);
        } finally {
            self::release_autosync_api_lock();
        }
    }

    private static function request_autosync_stock(string $token): bool {
        self::update_progress([
            'status' => 'running',
            'processed' => 0,
            'total' => 0,
            'percent' => 0,
            'message' => 'Conectando na API...',
        ]);

        $endpoint = self::get_autosync_endpoint();
        $args = [
            'timeout' => 60,
            'method' => 'GET',
            'headers' => ['Authorization' => $token, 'Content-Type' => 'application/json'],
            'user-agent' => 'SavolVeiculosAutoSync/1.2.17; WordPress',
        ];

        $response = wp_remote_request($endpoint, $args);
        if (is_wp_error($response)) {
            $message = $response->get_error_message();
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
            self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
            return false;
        }
        if ((int) wp_remote_retrieve_response_code($response) >= 300) {
            $code = (int) wp_remote_retrieve_response_code($response);
            $body = (string) wp_remote_retrieve_body($response);
            $message = 'HTTP ' . $code . ' em ' . self::mask_sensitive($endpoint) . ' - ' . mb_substr(wp_strip_all_tags($body), 0, 200);
            if ($code === 429) {
                $message = 'HTTP 429 - limite de requisicoes da API. Aguarde pelo menos 3 minutos e tente novamente.';
            }
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
            self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $payload = json_decode($body, true);
        return self::process_vehicles_payload($payload);
    }

    private static function process_vehicles_payload($payload): bool {
        if (!self::enqueue_vehicles_payload($payload, 'api')) {
            return false;
        }

        return self::process_queued_vehicles_batch();
    }

    private static function enqueue_vehicles_payload($payload, string $source): bool {
        if (!is_array($payload) || !isset($payload['vehicles']['rows']) || !is_array($payload['vehicles']['rows'])) {
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, 'JSON retornado nao esta no formato esperado (vehicles.rows).', false);
            self::update_progress(['status' => 'error', 'percent' => 100, 'message' => 'JSON fora do formato esperado.']);
            return false;
        }

        $apolo_stock_index = self::request_apolo_stock_index();
        if (is_wp_error($apolo_stock_index)) {
            $message = $apolo_stock_index->get_error_message();
            update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
            self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
            return false;
        }

        $autosync_rows = self::filter_autosync_rows($payload['vehicles']['rows']);
        $autosync_stock_index = self::build_autosync_stock_index($autosync_rows);
        $rows = isset($apolo_stock_index['_rows']) && is_array($apolo_stock_index['_rows'])
            ? $apolo_stock_index['_rows']
            : [];
        $total = count($rows);
        if ($total <= 0) {
            delete_option(self::AUTOSYNC_BATCH_OPTION);
            delete_option(self::AUTOSYNC_LAST_ERROR_OPTION);
            self::update_progress([
                'status' => 'done',
                'processed' => 0,
                'total' => 0,
                'percent' => 100,
                'message' => 'Nenhum veiculo APOLO para sincronizar.',
            ]);
            return true;
        }

        update_option(self::AUTOSYNC_BATCH_OPTION, [
            'source' => $source,
            'rows' => array_values($rows),
            'apolo_stock_index' => $apolo_stock_index,
            'autosync_stock_index' => $autosync_stock_index,
            'index' => 0,
            'total' => $total,
            'started_at' => time(),
        ], false);

        self::update_progress([
            'status' => 'queued',
            'processed' => 0,
            'total' => $total,
            'percent' => 0,
            'message' => 'Sincronizacao enfileirada com ' . $total . ' veiculos APOLO.',
        ]);

        return true;
    }

    private static function process_queued_vehicles_batch(): bool {
        $batch = get_option(self::AUTOSYNC_BATCH_OPTION, []);
        if (!is_array($batch) || empty($batch['rows']) || !isset($batch['index'], $batch['total'])) {
            return false;
        }

        $rows = is_array($batch['rows']) ? $batch['rows'] : [];
        $total = (int) $batch['total'];
        $index = max(0, (int) $batch['index']);
        $apolo_stock_index = isset($batch['apolo_stock_index']) && is_array($batch['apolo_stock_index']) ? $batch['apolo_stock_index'] : [];
        $autosync_stock_index = isset($batch['autosync_stock_index']) && is_array($batch['autosync_stock_index']) ? $batch['autosync_stock_index'] : [];
        if (empty($apolo_stock_index)) {
            $loaded_apolo_stock_index = self::request_apolo_stock_index();
            if (is_wp_error($loaded_apolo_stock_index)) {
                $message = $loaded_apolo_stock_index->get_error_message();
                update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
                self::update_progress(['status' => 'error', 'percent' => 100, 'message' => $message]);
                return false;
            }

            $apolo_stock_index = $loaded_apolo_stock_index;
            $batch['apolo_stock_index'] = $apolo_stock_index;
            update_option(self::AUTOSYNC_BATCH_OPTION, $batch, false);
        }
        $start = time();
        $processed_in_batch = 0;

        while ($index < $total && $processed_in_batch < self::AUTOSYNC_BATCH_SIZE && (time() - $start) < self::AUTOSYNC_BATCH_TIME_LIMIT) {
            $apolo_item = $rows[$index] ?? null;
            $index++;

            if (!is_array($apolo_item)) {
                continue;
            }

            $vehicle = self::find_autosync_vehicle_for_apolo($apolo_item, $autosync_stock_index);
            if ($vehicle === null) {
                $vehicle = self::build_vehicle_from_apolo_item($apolo_item);
            } else {
                $vehicle['_autosync_found'] = true;
                $vehicle = self::apply_apolo_item_to_vehicle($vehicle, $apolo_item);
            }

            self::upsert_vehicle($vehicle, $apolo_stock_index, $apolo_item);
            $processed_in_batch++;
            $percent = $total > 0 ? (int) floor(($index / $total) * 100) : 100;
            self::update_progress([
                'status' => 'running',
                'processed' => $index,
                'total' => $total,
                'percent' => $percent,
                'message' => 'Verificando veiculo ' . $index . ' de ' . $total,
            ]);
        }

        if ($index < $total) {
            $batch['index'] = $index;
            update_option(self::AUTOSYNC_BATCH_OPTION, $batch, false);
            $percent = $total > 0 ? (int) floor(($index / $total) * 100) : 100;
            self::update_progress([
                'status' => 'running',
                'processed' => $index,
                'total' => $total,
                'percent' => $percent,
                'message' => 'Sincronizacao em segundo plano: ' . $index . ' de ' . $total,
            ]);
            self::schedule_autosync_cron();
            return true;
        }

        self::mark_posts_missing_from_apolo_as_draft($apolo_stock_index);
        delete_option(self::AUTOSYNC_BATCH_OPTION);
        delete_option(self::AUTOSYNC_LAST_ERROR_OPTION);
        self::update_progress([
            'status' => 'done',
            'processed' => $total,
            'total' => $total,
            'percent' => 100,
            'message' => 'Sincronizacao concluida.',
        ]);
        return true;
    }

    private static function schedule_autosync_cron(): void {
        if (!wp_next_scheduled('savol_veiculos_run_autosync_cron')) {
            wp_schedule_single_event(time() + 5, 'savol_veiculos_run_autosync_cron');
        }
    }

    private static function request_apolo_stock_index() {
        $response = wp_remote_get(self::APOLO_STOCK_URL, [
            'timeout' => 30,
            'headers' => ['Accept' => 'application/json'],
            'user-agent' => 'SavolVeiculosAutoSync/1.2.18; WordPress',
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('savol_apolo_request_failed', 'Nao foi possivel consultar a base APOLO: ' . $response->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code >= 300) {
            $body = (string) wp_remote_retrieve_body($response);
            return new WP_Error('savol_apolo_http_error', 'HTTP ' . $code . ' ao consultar a base APOLO - ' . mb_substr(wp_strip_all_tags($body), 0, 200));
        }

        $payload = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($payload)) {
            return new WP_Error('savol_apolo_invalid_json', 'JSON da base APOLO nao esta em um formato valido.');
        }

        $rows = [];
        if (isset($payload['dados']) && is_array($payload['dados'])) {
            $rows = $payload['dados'];
        } elseif (isset($payload['data']) && is_array($payload['data'])) {
            $rows = $payload['data'];
        } elseif ($payload === array_values($payload)) {
            $rows = $payload;
        }

        if (empty($rows)) {
            return new WP_Error('savol_apolo_empty_json', 'Base APOLO sem veiculos para conciliacao.');
        }

        return self::build_apolo_stock_index($rows);
    }

    private static function build_apolo_stock_index(array $rows): array {
        $index = [
            '_rows' => [],
        ];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $description = trim((string) ($row['des_veiculo'] ?? ($row['descricao'] ?? '')));
            $item = [
                'empresa' => preg_replace('/\D+/', '', (string) ($row['empresa'] ?? '')),
                'revenda_origem' => preg_replace('/\D+/', '', (string) ($row['revenda_origem'] ?? '')),
                'situacao' => strtoupper(trim((string) ($row['situacao'] ?? ''))),
                'val_compra' => self::parse_money_value($row['val_compra'] ?? null),
                'valor_venda' => self::parse_money_value($row['valor_venda'] ?? null),
                'des_cor' => trim((string) ($row['des_cor'] ?? '')),
                'des_modelo' => trim((string) ($row['des_modelo'] ?? '')),
                'des_combustivel' => trim((string) ($row['des_combustivel'] ?? '')),
                'ano_fabricacao' => is_numeric($row['ano_fabricacao'] ?? null) ? (string) (int) $row['ano_fabricacao'] : '',
                'ano_modelo' => is_numeric($row['ano_modelo'] ?? null) ? (string) (int) $row['ano_modelo'] : '',
                'km_atual' => is_numeric($row['km_atual'] ?? null) ? (string) (float) $row['km_atual'] : '',
                'cambio' => trim((string) ($row['cambio'] ?? '')),
                'tipo' => trim((string) ($row['tipo'] ?? '')),
                'photo_urls' => [],
                'blindado_informado' => array_key_exists('blindado', $row)
                    && $row['blindado'] !== null
                    && (!is_string($row['blindado']) || trim($row['blindado']) !== ''),
                'blindado' => self::to_boolean_flag($row['blindado'] ?? false),
                'nome_fantasia' => trim((string) ($row['nome_fantasia'] ?? '')),
                'cnpj' => preg_replace('/\D+/', '', (string) ($row['cnpj'] ?? '')),
                'placa' => self::normalize_plate((string) ($row['placa'] ?? '')),
                'chassi' => self::normalize_vehicle_lookup_key((string) ($row['chassi'] ?? '')),
                'veiculo' => trim((string) ($row['veiculo'] ?? '')),
                'negociacao' => self::to_boolean_flag($row['negociacao'] ?? false),
                'proposta' => trim((string) ($row['proposta'] ?? '')),
                'vendedor_proposta' => trim((string) ($row['vendedor_proposta'] ?? '')),
                'repasse' => array_key_exists('repasse', $row)
                    ? self::to_boolean_flag($row['repasse'])
                    : self::canonicalize_text((string) ($row['vendedor_proposta'] ?? '')) === 'repasse',
                'transito' => self::to_boolean_flag($row['transito'] ?? false)
                    || strtoupper(trim((string) ($row['situacao'] ?? ''))) === 'TM',
                'dias_estoque' => self::extract_apolo_stock_days($row),
                'dias_proposta' => self::extract_apolo_proposal_days($row),
                'des_veiculo' => $description,
                'raw' => $row,
            ];
            $item['parsed'] = self::parse_apolo_vehicle_description($description);

            $index['_rows'][] = $item;
            if ($item['placa'] !== '') {
                $index['plate:' . $item['placa']] = $item;
            }
            if ($item['chassi'] !== '') {
                $index['vin:' . $item['chassi']] = $item;
            }
            if ($item['veiculo'] !== '') {
                $index['apolo:' . self::normalize_vehicle_lookup_key($item['veiculo'])] = $item;
            }
        }

        return $index;
    }

    private static function extract_apolo_photo_urls(array $row): array {
        $urls = [];
        foreach (['foto_frente', 'foto_traseira', 'foto_lateral', 'foto_interna', 'foto_extra_1', 'foto_extra_2'] as $key) {
            $value = $row[$key] ?? '';
            if (is_array($value)) {
                $value = $value['url'] ?? ($value['link'] ?? '');
            }

            $url = esc_url_raw(trim((string) $value));
            if ($url !== '') {
                $urls[] = $url;
            }
        }

        return array_values(array_unique($urls));
    }

    private static function extract_apolo_stock_days(array $row): int {
        if (array_key_exists('dias_estoque', $row) && is_numeric($row['dias_estoque'])) {
            return max(0, (int) $row['dias_estoque']);
        }

        $aliases = [
            'dias estoque',
            'dias de estoque',
            'dias em estoque',
            'dias no estoque',
            'qtd dias estoque',
            'tempo estoque',
        ];

        foreach ($row as $key => $value) {
            $normalized_key = self::canonicalize_text((string) $key);
            if (!in_array($normalized_key, $aliases, true) || !is_numeric($value)) {
                continue;
            }

            return max(0, (int) $value);
        }

        return 0;
    }

    private static function extract_apolo_proposal_days(array $row): ?int {
        if (array_key_exists('dias_proposta', $row) && is_numeric($row['dias_proposta'])) {
            $days = (int) $row['dias_proposta'];
            return max(0, $days);
        }

        $aliases = [
            'dias proposta',
            'dias de proposta',
            'dias em proposta',
            'tempo proposta',
        ];

        foreach ($row as $key => $value) {
            $normalized_key = self::canonicalize_text((string) $key);
            if (!in_array($normalized_key, $aliases, true) || !is_numeric($value)) {
                continue;
            }

            $days = (int) $value;
            return max(0, $days);
        }

        return null;
    }

    private static function build_autosync_stock_index(array $rows): array {
        $index = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $plate = self::normalize_plate((string) ($row['plate'] ?? ''));
            $vin = self::normalize_vehicle_lookup_key((string) ($row['vin'] ?? ($row['chassi'] ?? ($row['chassis'] ?? ''))));
            if ($plate !== '') {
                $index['plate:' . $plate] = $row;
            }
            if ($vin !== '') {
                $index['vin:' . $vin] = $row;
            }
        }

        return $index;
    }

    private static function find_autosync_vehicle_for_apolo(array $apolo_item, array $autosync_stock_index): ?array {
        $plate = self::normalize_plate((string) ($apolo_item['placa'] ?? ''));
        if ($plate !== '' && isset($autosync_stock_index['plate:' . $plate]) && is_array($autosync_stock_index['plate:' . $plate])) {
            return $autosync_stock_index['plate:' . $plate];
        }

        $vin = self::normalize_vehicle_lookup_key((string) ($apolo_item['chassi'] ?? ''));
        if ($vin !== '' && isset($autosync_stock_index['vin:' . $vin]) && is_array($autosync_stock_index['vin:' . $vin])) {
            return $autosync_stock_index['vin:' . $vin];
        }

        return null;
    }

    private static function reconcile_autosync_vehicle_with_apolo(array $vehicle, array $apolo_stock_index, ?array $apolo_item = null): array {
        if ($apolo_item === null) {
            $apolo_item = self::find_apolo_stock_item_for_vehicle($vehicle, $apolo_stock_index);
        }
        $reason = '';

        if ($apolo_item === null) {
            $reason = 'Não cadastrado no APOLO';
        } elseif (!self::is_allowed_apolo_company_reseller($apolo_item)) {
            $reason = 'Empresa não autorizada no APOLO';
        } elseif (!in_array((string) $apolo_item['situacao'], self::get_apolo_allowed_situations(), true)) {
            $reason = 'Situação não permitida no APOLO';
        } else {
            $purchase_price = self::parse_money_value($apolo_item['val_compra'] ?? null);
            $apolo_sale_price = self::parse_money_value($apolo_item['valor_venda'] ?? null);
            if ($apolo_sale_price <= 0) {
                $reason = 'Sem preco de venda no APOLO';
            } elseif ($purchase_price > 0 && $purchase_price > $apolo_sale_price) {
                $reason = 'Preço de compra acima do preço de venda';
            }
        }

        return [
            'status' => $reason === '' ? 'publish' : 'draft',
            'reason' => $reason,
            'apolo' => $apolo_item ?? [],
        ];
    }

    private static function is_allowed_apolo_company_reseller(array $apolo_item): bool {
        $company = preg_replace('/\D+/', '', (string) ($apolo_item['empresa'] ?? ''));
        $reseller = preg_replace('/\D+/', '', (string) ($apolo_item['revenda_origem'] ?? ''));

        if ($company === '' || $reseller === '') {
            return false;
        }

        return in_array($company . ':' . $reseller, self::get_apolo_allowed_company_resellers(), true);
    }

    private static function find_apolo_stock_item_for_vehicle(array $vehicle, array $apolo_stock_index): ?array {
        $plate = self::normalize_plate((string) ($vehicle['plate'] ?? ''));
        if ($plate !== '' && isset($apolo_stock_index['plate:' . $plate]) && is_array($apolo_stock_index['plate:' . $plate])) {
            return $apolo_stock_index['plate:' . $plate];
        }

        $vin = self::normalize_vehicle_lookup_key((string) ($vehicle['vin'] ?? ($vehicle['chassi'] ?? ($vehicle['chassis'] ?? ''))));
        if ($vin !== '' && isset($apolo_stock_index['vin:' . $vin]) && is_array($apolo_stock_index['vin:' . $vin])) {
            return $apolo_stock_index['vin:' . $vin];
        }

        return null;
    }

    private static function vehicle_exists_in_apolo_index(string $plate, string $vin, string $external_id, array $apolo_stock_index): bool {
        $plate = self::normalize_plate($plate);
        if ($plate !== '' && isset($apolo_stock_index['plate:' . $plate])) {
            return true;
        }

        $vin = self::normalize_vehicle_lookup_key($vin);
        if ($vin !== '' && isset($apolo_stock_index['vin:' . $vin])) {
            return true;
        }

        $external_id = self::normalize_vehicle_lookup_key($external_id);
        if ($external_id !== '' && isset($apolo_stock_index['apolo:' . $external_id])) {
            return true;
        }

        return false;
    }

    private static function mark_posts_missing_from_apolo_as_draft(array $apolo_stock_index): void {
        $query = new \WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => -1,
            'fields' => 'ids',
            'no_found_rows' => true,
        ]);

        if (empty($query->posts)) {
            return;
        }

        foreach ($query->posts as $post_id) {
            $post_id = (int) $post_id;
            $plate = (string) get_post_meta($post_id, 'placa', true);
            $vin = (string) get_post_meta($post_id, 'chassi_vin', true);
            $external_id = (string) get_post_meta($post_id, 'identificador_externo', true);
            if (self::vehicle_exists_in_apolo_index($plate, $vin, $external_id, $apolo_stock_index)) {
                continue;
            }

            update_post_meta($post_id, 'apolo_reconciliacao_motivo', 'Vendido');
            update_post_meta($post_id, 'apolo_presente', 0);
            $sold_at = (string) get_post_meta($post_id, 'apolo_vendido_em', true);
            $should_record_sale = $sold_at === '';
            if ((string) get_post_meta($post_id, 'apolo_removido_em', true) === '') {
                update_post_meta($post_id, 'apolo_removido_em', current_time('mysql'));
            }
            if ($sold_at === '') {
                $sold_at = current_time('mysql');
                update_post_meta($post_id, 'apolo_vendido_em', $sold_at);
            }
            update_post_meta($post_id, 'apolo_status_operacional', 'vendido');
            if ($should_record_sale) {
                self::record_dashboard_operation('saida', $post_id, $sold_at);
            }
            delete_post_meta($post_id, self::MANUAL_STATUS_LOCK_META);
            update_post_meta($post_id, 'savol_sync_signature', '');
            self::set_status_loja_term($post_id, 'Vendido');
            $post = get_post($post_id);
            $title = $post ? self::strip_apolo_draft_reason_from_title((string) $post->post_title) : '';
            $postarr = [
                'ID' => $post_id,
                'post_status' => 'draft',
            ];
            if ($title !== '') {
                $postarr['post_title'] = $title;
            }
            wp_update_post($postarr);
        }
    }

    private static function append_apolo_draft_reason_to_title(string $title, string $reason): string {
        $title = self::strip_apolo_draft_reason_from_title($title);
        if ($reason === '') {
            return $title;
        }

        return trim($title . ' - ' . $reason);
    }

    private static function strip_apolo_draft_reason_from_title(string $title): string {
        $title = trim($title);
        foreach (self::APOLO_DRAFT_REASONS as $reason) {
            $title = preg_replace('/\s+-\s+' . preg_quote($reason, '/') . '$/u', '', $title);
        }

        return trim((string) $title);
    }

    private static function parse_apolo_vehicle_description(string $description): array {
        $description = str_replace(["\r\n", "\r"], "\n", $description);
        $lines = array_values(array_filter(array_map('trim', explode("\n", $description))));
        $parsed = [
            'brandName' => '',
            'modelName' => '',
            'colorName' => '',
            'fuelName' => '',
            'renavam' => '',
            'manufacturingYear' => '',
            'modelYear' => '',
        ];

        foreach ($lines as $line) {
            if ($parsed['brandName'] === '' && !str_contains($line, '.:') && !str_contains($line, '..:') && !str_contains($line, ':')) {
                $parsed['brandName'] = $line;
            }

            if (preg_match('/MODELO\.*:\s*(.+)$/iu', $line, $matches)) {
                $parsed['modelName'] = trim($matches[1]);
                continue;
            }
            if (preg_match('/COR\.*:\s*(.+)$/iu', $line, $matches)) {
                $parsed['colorName'] = trim($matches[1]);
                continue;
            }
            if (preg_match('/COMBUST\.*:\s*(.+)$/iu', $line, $matches)) {
                $parsed['fuelName'] = trim($matches[1]);
                continue;
            }
            if (preg_match('/RENAVAM\.*:\s*(.+)$/iu', $line, $matches)) {
                $parsed['renavam'] = preg_replace('/\D+/', '', (string) $matches[1]);
                continue;
            }
            if (preg_match('/ANO\s*FAB\.*:\s*(\d{4})\s*\/\s*MOD\.*:\s*(\d{4})/iu', $line, $matches)) {
                $parsed['manufacturingYear'] = $matches[1];
                $parsed['modelYear'] = $matches[2];
            }
        }

        $context = $description . ' ' . (string) ($parsed['modelName'] ?? '');
        $parsed['brandName'] = self::normalize_vehicle_brand_name((string) ($parsed['brandName'] ?? ''), $context);
        $parsed['modelName'] = self::strip_vehicle_multibrand_label((string) ($parsed['modelName'] ?? ''));
        $parsed['modelName'] = self::strip_vehicle_leading_brand_label((string) $parsed['modelName'], (string) $parsed['brandName']);

        return $parsed;
    }

    private static function build_vehicle_from_apolo_item(array $apolo_item): array {
        $parsed = isset($apolo_item['parsed']) && is_array($apolo_item['parsed'])
            ? $apolo_item['parsed']
            : self::parse_apolo_vehicle_description((string) ($apolo_item['des_veiculo'] ?? ''));
        $apolo_id = self::resolve_apolo_external_id($apolo_item);

        return self::apply_apolo_item_to_vehicle([
            'id' => $apolo_id,
            'brandName' => (string) ($parsed['brandName'] ?? ''),
            'modelName' => (string) ($parsed['modelName'] ?? ($apolo_item['veiculo'] ?? '')),
            'versionName' => '',
            'modelYear' => (string) ($parsed['modelYear'] ?? ''),
            'manufacturingYear' => (string) ($parsed['manufacturingYear'] ?? ''),
            'plate' => (string) ($apolo_item['placa'] ?? ''),
            'vin' => (string) ($apolo_item['chassi'] ?? ''),
            'renavam' => (string) ($parsed['renavam'] ?? ''),
            'colorName' => (string) ($parsed['colorName'] ?? ''),
            'fuelName' => (string) ($parsed['fuelName'] ?? ''),
            'entityName' => (string) ($apolo_item['nome_fantasia'] ?? ''),
            'comments' => (string) ($apolo_item['des_veiculo'] ?? ''),
            'value' => '',
            '_autosync_found' => false,
        ], $apolo_item);
    }

    private static function apply_apolo_item_to_vehicle(array $vehicle, array $apolo_item): array {
        $parsed = isset($apolo_item['parsed']) && is_array($apolo_item['parsed'])
            ? $apolo_item['parsed']
            : self::parse_apolo_vehicle_description((string) ($apolo_item['des_veiculo'] ?? ''));

        $field_map = [
            'brandName' => (string) ($parsed['brandName'] ?? ''),
            'modelName' => (string) ($apolo_item['des_modelo'] ?? ($parsed['modelName'] ?? ($apolo_item['veiculo'] ?? ''))),
            'manufacturingYear' => (string) ($apolo_item['ano_fabricacao'] ?? ($parsed['manufacturingYear'] ?? '')),
            'modelYear' => (string) ($apolo_item['ano_modelo'] ?? ($parsed['modelYear'] ?? '')),
            'kilometers' => (string) ($apolo_item['km_atual'] ?? ''),
            'colorName' => (string) ($apolo_item['des_cor'] ?? ($parsed['colorName'] ?? '')),
            'fuelName' => (string) ($apolo_item['des_combustivel'] ?? ($parsed['fuelName'] ?? '')),
            'transmissionName' => (string) ($apolo_item['cambio'] ?? ''),
            'section' => (string) ($apolo_item['tipo'] ?? ''),
            'plate' => (string) ($apolo_item['placa'] ?? ''),
            'vin' => (string) ($apolo_item['chassi'] ?? ''),
            'renavam' => (string) ($parsed['renavam'] ?? ''),
            'entityName' => (string) ($apolo_item['nome_fantasia'] ?? ''),
            'comments' => (string) ($apolo_item['des_veiculo'] ?? ''),
            'value' => self::parse_money_value($apolo_item['valor_venda'] ?? null) > 0 ? (string) self::parse_money_value($apolo_item['valor_venda'] ?? null) : '',
            'fipeValue' => self::parse_money_value($apolo_item['fipeValue'] ?? ($apolo_item['fipe_value'] ?? ($apolo_item['valor_fipe'] ?? null))) > 0
                ? (string) self::parse_money_value($apolo_item['fipeValue'] ?? ($apolo_item['fipe_value'] ?? ($apolo_item['valor_fipe'] ?? null)))
                : '',
        ];
        $field_map = self::normalize_vehicle_identity($field_map, (string) ($apolo_item['des_veiculo'] ?? ''));

        foreach ($field_map as $key => $value) {
            if ($value !== '') {
                $vehicle[$key] = $value;
            }
        }

        if (!empty($apolo_item['blindado_informado'])) {
            $vehicle['blindado'] = !empty($apolo_item['blindado']);
            $vehicle['_apolo_blindado_informado'] = true;
        }

        return $vehicle;
    }

    private static function normalize_vehicle_identity(array $vehicle, string $context = ''): array {
        $brand = (string) ($vehicle['brandName'] ?? '');
        $model = (string) ($vehicle['modelName'] ?? '');
        $version = (string) ($vehicle['versionName'] ?? '');
        $full_context = trim($context . ' ' . $brand . ' ' . $model . ' ' . $version);

        $vehicle['brandName'] = self::normalize_vehicle_brand_name($brand, $full_context);
        $vehicle['modelName'] = self::strip_vehicle_leading_brand_label(self::strip_vehicle_multibrand_label($model), (string) $vehicle['brandName']);
        $vehicle['versionName'] = self::strip_vehicle_leading_brand_label(self::strip_vehicle_multibrand_label($version), (string) $vehicle['brandName']);

        return $vehicle;
    }

    private static function normalize_vehicle_brand_name(string $brand, string $context = ''): string {
        $brand = self::strip_vehicle_multibrand_label($brand);
        $normalized = self::canonicalize_text($brand);

        if ($normalized === 'kia' || $normalized === 'kia motors') {
            return 'KIA';
        }

        if ($brand === '' || $normalized === 'multimarca' || $normalized === 'multmarca') {
            return self::infer_vehicle_brand_from_text($context);
        }

        return trim($brand);
    }

    private static function strip_vehicle_multibrand_label(string $value): string {
        $value = preg_replace('/\bMULTI?MARCA\b|\bMULTMARCA\b/iu', ' ', $value);
        $value = preg_replace('/\s+/', ' ', (string) $value);
        return trim((string) $value);
    }

    private static function strip_vehicle_leading_brand_label(string $value, string $brand): string {
        $value = trim($value);
        if ($value === '' || $brand === '') {
            return $value;
        }

        $aliases = strtoupper($brand) === 'KIA' ? ['KIA MOTORS', 'KIA'] : [$brand];
        $changed = true;
        while ($changed) {
            $changed = false;
            foreach ($aliases as $alias) {
                $alias_words = self::canonicalize_text($alias);
                $value_words = self::canonicalize_text($value);
                if ($value_words === $alias_words) {
                    return '';
                }
                if (str_starts_with($value_words, $alias_words . ' ')) {
                    $alias_pattern = preg_replace('/\s+/', '[^[:alnum:]]+', preg_quote($alias, '/'));
                    $next_value = trim((string) preg_replace('/^' . $alias_pattern . '\s*/iu', '', $value));
                    if ($next_value === $value) {
                        return $value;
                    }
                    $value = $next_value;
                    $changed = true;
                    break;
                }
            }
        }

        return $value;
    }

    private static function infer_vehicle_brand_from_text(string $text): string {
        $source = ' ' . self::canonicalize_text($text) . ' ';
        $patterns = [
            'CHEVROLET' => ['onix', 'tracker', 'cruze', 'cobalt', 'prisma', 'spin', 's10', 'montana'],
            'FIAT' => ['fastback', 'argo', 'mobi', 'toro', 'strada', 'cronos', 'pulse', 'uno', 'palio', 'siena'],
            'VOLKSWAGEN' => ['polo', 't cross', 'nivus', 'fox', 'gol', 'taos', 'tera', 'saveiro', 'tiguan', 'virtus', 'jetta'],
            'KIA' => ['kia', 'sportage', 'sorento', 'cerato', 'picanto', 'seltos', 'soul', 'carnival'],
            'JEEP' => ['compass', 'renegade', 'commander'],
            'HYUNDAI' => ['hb20', 'creta', 'tucson', 'ix35', 'santa fe'],
            'TOYOTA' => ['corolla', 'yaris', 'hilux', 'sw4', 'etios', 'rav4'],
            'PEUGEOT' => ['208', '2008', '3008', 'partner'],
            'CITROEN' => ['c3', 'c4', 'aircross', 'jumpy'],
            'FORD' => ['ecosport', 'ka', 'ranger', 'fiesta', 'focus'],
            'HONDA' => ['city', 'civic', 'fit', 'hr v', 'hrv', 'wr v', 'wrv'],
            'RENAULT' => ['kwid', 'logan', 'sandero', 'captur', 'duster'],
            'NISSAN' => ['versa', 'kicks', 'sentra', 'frontier'],
            'CHERY' => ['tiggo', 'arrizo'],
            'BYD' => ['song', 'dolphin', 'yuan', 'seal'],
            'GWM' => ['haval', 'ora', 'tank'],
            'MG' => ['mg', 'zs', 'hs'],
        ];

        foreach ($patterns as $brand => $brand_patterns) {
            foreach ($brand_patterns as $pattern) {
                if (str_contains($source, ' ' . self::canonicalize_text($pattern) . ' ')) {
                    return $brand;
                }
            }
        }

        return '';
    }

    private static function resolve_apolo_external_id(array $apolo_item): string {
        $plate = self::normalize_plate((string) ($apolo_item['placa'] ?? ''));
        if ($plate !== '') {
            return 'apolo-plate-' . $plate;
        }

        $vin = self::normalize_vehicle_lookup_key((string) ($apolo_item['chassi'] ?? ''));
        if ($vin !== '') {
            return 'apolo-vin-' . $vin;
        }

        $apolo_code = self::normalize_vehicle_lookup_key((string) ($apolo_item['veiculo'] ?? ''));
        if ($apolo_code !== '') {
            return 'apolo-' . $apolo_code;
        }

        return 'apolo-' . md5(wp_json_encode($apolo_item));
    }

    private static function extract_vehicle_photo_urls(array $vehicle): array {
        $photo_urls = [];
        if (isset($vehicle['VehiclePhotos']) && is_array($vehicle['VehiclePhotos'])) {
            $photos = [];
            foreach ($vehicle['VehiclePhotos'] as $index => $photo) {
                if (is_array($photo) && !empty($photo['link'])) {
                    $photos[] = [
                        'index' => (int) $index,
                        'order' => isset($photo['order']) && is_numeric($photo['order']) ? (int) $photo['order'] : PHP_INT_MAX,
                        'url' => esc_url_raw((string) $photo['link']),
                    ];
                }
            }

            usort($photos, static function (array $left, array $right): int {
                $order_comparison = $left['order'] <=> $right['order'];
                return $order_comparison !== 0 ? $order_comparison : ($left['index'] <=> $right['index']);
            });
            $photo_urls = array_column($photos, 'url');
        }

        return array_values(array_unique(array_filter($photo_urls)));
    }

    private static function normalize_photo_reference(string $value): string {
        $decoded = rawurldecode($value);
        $normalized = strtolower(remove_accents($decoded));
        return (string) preg_replace('/[^a-z0-9]+/', '', $normalized);
    }

    private static function is_preparation_photo_url(string $url): bool {
        if ($url === '') {
            return false;
        }

        $normalized = self::normalize_photo_reference($url);
        foreach (['imagesempreparacao', 'imagesfallbackatualizado', 'empreparacao', 'empreparao', 'preparacao', 'prepacacao'] as $needle) {
            if (str_contains($normalized, $needle)) {
                return true;
            }
        }

        return false;
    }

    private static function extract_real_vehicle_photo_urls(array $photo_urls): array {
        $real_photo_urls = [];
        foreach ($photo_urls as $url) {
            $url = esc_url_raw((string) $url);
            if ($url === '' || self::is_preparation_photo_url($url)) {
                continue;
            }
            $real_photo_urls[] = $url;
        }

        return array_values(array_unique($real_photo_urls));
    }

    private static function build_vehicle_sync_signature(array $vehicle, array $apolo_reconciliation, array $photo_urls, string $official_unit_name, string $title): string {
        $payload = [
            'photo_source_rule_version' => '2026-09-autosync-links-featured-only-v1',
            'proposal_days_rule_version' => '2026-08-positive-only-v1',
            'apolo_priority_rule_version' => '2026-08-apolo-first-v1',
            'title' => $title,
            'status' => (string) ($apolo_reconciliation['status'] ?? ''),
            'reason' => (string) ($apolo_reconciliation['reason'] ?? ''),
            'manual_status_lock' => !empty($apolo_reconciliation['manual_status_lock']),
            'unit' => $official_unit_name,
            'photos' => $photo_urls,
            'apolo' => [
                'empresa' => (string) ($apolo_reconciliation['apolo']['empresa'] ?? ''),
                'revenda_origem' => (string) ($apolo_reconciliation['apolo']['revenda_origem'] ?? ''),
                'situacao' => (string) ($apolo_reconciliation['apolo']['situacao'] ?? ''),
                'val_compra' => self::parse_money_value($apolo_reconciliation['apolo']['val_compra'] ?? null),
                'valor_venda' => self::parse_money_value($apolo_reconciliation['apolo']['valor_venda'] ?? null),
                'fipeValue' => self::parse_money_value($apolo_reconciliation['apolo']['fipeValue'] ?? ($apolo_reconciliation['apolo']['fipe_value'] ?? ($apolo_reconciliation['apolo']['valor_fipe'] ?? null))),
                'des_cor' => (string) ($apolo_reconciliation['apolo']['des_cor'] ?? ''),
                'des_modelo' => (string) ($apolo_reconciliation['apolo']['des_modelo'] ?? ''),
                'des_combustivel' => (string) ($apolo_reconciliation['apolo']['des_combustivel'] ?? ''),
                'ano_fabricacao' => (string) ($apolo_reconciliation['apolo']['ano_fabricacao'] ?? ''),
                'ano_modelo' => (string) ($apolo_reconciliation['apolo']['ano_modelo'] ?? ''),
                'km_atual' => (string) ($apolo_reconciliation['apolo']['km_atual'] ?? ''),
                'cambio' => (string) ($apolo_reconciliation['apolo']['cambio'] ?? ''),
                'tipo' => (string) ($apolo_reconciliation['apolo']['tipo'] ?? ''),
                'photo_urls' => isset($apolo_reconciliation['apolo']['photo_urls']) && is_array($apolo_reconciliation['apolo']['photo_urls'])
                    ? $apolo_reconciliation['apolo']['photo_urls']
                    : [],
                'nome_fantasia' => (string) ($apolo_reconciliation['apolo']['nome_fantasia'] ?? ''),
                'cnpj' => (string) ($apolo_reconciliation['apolo']['cnpj'] ?? ''),
                'placa' => (string) ($apolo_reconciliation['apolo']['placa'] ?? ''),
                'chassi' => (string) ($apolo_reconciliation['apolo']['chassi'] ?? ''),
                'veiculo' => (string) ($apolo_reconciliation['apolo']['veiculo'] ?? ''),
            'negociacao' => !empty($apolo_reconciliation['apolo']['negociacao']),
            'transito' => !empty($apolo_reconciliation['apolo']['transito']),
            'blindado_informado' => !empty($apolo_reconciliation['apolo']['blindado_informado']),
                'blindado' => !empty($apolo_reconciliation['apolo']['blindado']),
                'proposta' => (string) ($apolo_reconciliation['apolo']['proposta'] ?? ''),
                'vendedor_proposta' => (string) ($apolo_reconciliation['apolo']['vendedor_proposta'] ?? ''),
                'repasse' => !empty($apolo_reconciliation['apolo']['repasse']),
                'dias_estoque' => max(0, (int) ($apolo_reconciliation['apolo']['dias_estoque'] ?? 0)),
                'dias_proposta' => self::extract_apolo_proposal_days($apolo_reconciliation['apolo'] ?? []),
                'des_veiculo' => (string) ($apolo_reconciliation['apolo']['des_veiculo'] ?? ''),
            ],
            'autosync' => [
                'highlight_rule_version' => '2026-08-low-mileage-100k-cap-v2',
                'id' => (string) ($vehicle['id'] ?? ''),
                'brandName' => (string) ($vehicle['brandName'] ?? ''),
                'modelName' => (string) ($vehicle['modelName'] ?? ''),
                'versionName' => (string) ($vehicle['versionName'] ?? ''),
                'manufacturingYear' => (string) ($vehicle['manufacturingYear'] ?? ''),
                'modelYear' => (string) ($vehicle['modelYear'] ?? ''),
                'kilometers' => (string) ($vehicle['kilometers'] ?? ''),
                'value' => self::parse_money_value($vehicle['value'] ?? null),
                'fipeValue' => self::parse_money_value($vehicle['fipeValue'] ?? null),
                'status' => (string) ($vehicle['status'] ?? ''),
                'fuelName' => (string) ($vehicle['fuelName'] ?? ''),
                'transmissionName' => (string) ($vehicle['transmissionName'] ?? ''),
                'section' => (string) ($vehicle['section'] ?? ''),
                'colorName' => (string) ($vehicle['colorName'] ?? ''),
                'entityName' => (string) ($vehicle['entityName'] ?? ''),
                'comments' => (string) ($vehicle['comments'] ?? ''),
                'blindado' => self::is_vehicle_armored($vehicle),
                'features' => self::extract_named_items($vehicle['VehicleFeatures'] ?? []),
                'optionals' => self::extract_named_items($vehicle['VehicleOptionals'] ?? []),
                'equipments' => self::extract_named_items($vehicle['VehicleEquipments'] ?? []),
            ],
        ];

        return hash('sha256', (string) wp_json_encode($payload));
    }

    private static function normalize_vehicle_lookup_key(string $value): string {
        return strtoupper((string) preg_replace('/[^A-Z0-9]+/i', '', $value));
    }

    private static function parse_money_value($value): float {
        if (is_int($value) || is_float($value)) {
            return (float) $value;
        }

        $text = trim((string) $value);
        if ($text === '') {
            return 0.0;
        }

        $text = preg_replace('/[^\d,.\-]+/', '', $text);
        if ($text === '' || $text === '-' || $text === null) {
            return 0.0;
        }

        $has_comma = str_contains($text, ',');
        $has_dot = str_contains($text, '.');
        if ($has_comma && $has_dot) {
            $text = str_replace('.', '', $text);
            $text = str_replace(',', '.', $text);
        } elseif ($has_comma) {
            $text = str_replace(',', '.', $text);
        } elseif (preg_match('/^\d{1,3}(\.\d{3})+$/', $text)) {
            $text = str_replace('.', '', $text);
        }

        return is_numeric($text) ? (float) $text : 0.0;
    }

    private static function dashboard_term_name(int $post_id, string $taxonomy): string {
        $terms = get_the_terms($post_id, $taxonomy);
        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }

        $term = reset($terms);
        return $term instanceof \WP_Term ? html_entity_decode((string) $term->name, ENT_QUOTES, get_bloginfo('charset')) : '';
    }

    private static function dashboard_meta_number(int $post_id, string $key): float {
        return self::parse_money_value(get_post_meta($post_id, $key, true));
    }

    private static function get_dashboard_operations_log(): array {
        $operations = get_option(self::DASHBOARD_OPERATIONS_OPTION, []);
        return is_array($operations) ? $operations : [];
    }

    private static function record_dashboard_operation(string $type, int $post_id, string $occurred_at): void {
        $type = sanitize_key($type);
        if ($type === '' || $post_id <= 0 || $occurred_at === '') {
            return;
        }

        $post = get_post($post_id);
        if (!$post instanceof \WP_Post) {
            return;
        }

        $vehicle = self::dashboard_vehicle_payload($post);
        $operation = array_merge($vehicle, [
            'operationId' => $type . ':' . $post_id . ':' . substr($occurred_at, 0, 10),
            'type' => $type,
            'occurredAt' => $occurred_at,
            'createdAt' => $occurred_at,
            'operationalStatus' => $type === 'saida' ? 'vendido' : 'em_estoque',
        ]);

        $operations = self::get_dashboard_operations_log();
        $operations = array_values(array_filter($operations, static function ($item) use ($operation): bool {
            return is_array($item) && (string) ($item['operationId'] ?? '') !== (string) $operation['operationId'];
        }));
        array_unshift($operations, $operation);

        if (count($operations) > self::DASHBOARD_OPERATIONS_MAX_ITEMS) {
            $operations = array_slice($operations, 0, self::DASHBOARD_OPERATIONS_MAX_ITEMS);
        }

        update_option(self::DASHBOARD_OPERATIONS_OPTION, $operations, false);
    }

    private static function dashboard_photo_urls(int $post_id): array {
        $urls = [];
        $featured_id = get_post_thumbnail_id($post_id);
        if ($featured_id) {
            $featured_url = wp_get_attachment_image_url($featured_id, 'medium_large');
            if ($featured_url) {
                $urls[] = $featured_url;
            }
        }

        $autosync_urls = (string) get_post_meta($post_id, 'autosync_photo_urls', true);
        if ($autosync_urls !== '') {
            $urls = array_merge($urls, preg_split('/[\r\n]+/', $autosync_urls) ?: []);
        }

        return array_values(array_unique(array_filter(array_map('esc_url_raw', $urls))));
    }

    private static function dashboard_vehicle_payload(\WP_Post $post): array {
        $post_id = (int) $post->ID;
        $post_status = (string) $post->post_status;
        $reason = trim((string) get_post_meta($post_id, 'apolo_reconciliacao_motivo', true));
        $plate = (string) get_post_meta($post_id, 'placa', true);
        $year = (string) get_post_meta($post_id, 'ano', true);
        $model_year = (string) get_post_meta($post_id, 'ano_modelo', true);
        $photos = self::dashboard_photo_urls($post_id);
        $price = self::dashboard_meta_number($post_id, 'preco');
        $cost = self::dashboard_meta_number($post_id, 'apolo_val_compra');
        $sale_price = self::dashboard_meta_number($post_id, 'apolo_valor_venda');
        $fipe = self::dashboard_meta_number($post_id, 'fipe');
        if ($fipe <= 0) {
            $fipe = self::dashboard_meta_number($post_id, 'apolo_fipe');
        }
        $status_label = $post_status === 'publish' ? 'Publicado no site' : ($reason !== '' ? $reason : 'Rascunho');
        $slug = (string) $post->post_name;
        $in_apolo = (string) get_post_meta($post_id, 'apolo_presente', true);
        $in_apolo = $in_apolo === '' ? !str_contains(self::canonicalize_text($reason), 'vendido') : $in_apolo === '1';

        return [
            'id' => $post_id,
            'slug' => $slug !== '' ? $slug : (string) $post_id,
            'name' => self::strip_apolo_draft_reason_from_title(html_entity_decode(get_the_title($post_id), ENT_QUOTES, get_bloginfo('charset'))),
            'brand' => self::dashboard_term_name($post_id, 'veiculo_marca'),
            'model' => self::dashboard_term_name($post_id, 'veiculo_modelo'),
            'store' => self::dashboard_term_name($post_id, 'veiculo_unidade'),
            'plate' => $plate,
            'year' => trim($year . ($model_year !== '' ? '/' . $model_year : ''), '/'),
            'km' => self::dashboard_meta_number($post_id, 'km'),
            'price' => $price > 0 ? $price : null,
            'cost' => $cost > 0 ? $cost : null,
            'salePrice' => $sale_price > 0 ? $sale_price : ($price > 0 ? $price : null),
            'fipe' => $fipe > 0 ? $fipe : null,
            'fipeValue' => $fipe > 0 ? $fipe : null,
            'image' => $photos[0] ?? '',
            'link' => get_edit_post_link($post_id, 'raw') ?: get_permalink($post_id),
            'publicUrl' => self::PUBLIC_SITE_URL . '/veiculos/' . ($slug !== '' ? $slug : $post_id),
            'photoCount' => count($photos),
            'stockDays' => max(0, (int) get_post_meta($post_id, 'dias_estoque', true)),
            'proposalDays' => get_post_meta($post_id, 'dias_proposta', true) !== ''
                ? max(0, (int) get_post_meta($post_id, 'dias_proposta', true))
                : null,
            'purchaseDate' => (string) get_post_meta($post_id, 'apolo_comprado_em', true),
            'saleDate' => (string) get_post_meta($post_id, 'apolo_vendido_em', true),
            'repasse' => (int) get_post_meta($post_id, 'repasse', true) === 1,
            'negotiated' => (int) get_post_meta($post_id, 'negociacao', true) === 1,
            'transit' => (int) get_post_meta($post_id, 'transito', true) === 1
                || (int) get_post_meta($post_id, 'apolo_transito', true) === 1
                || strtoupper((string) get_post_meta($post_id, 'apolo_situacao', true)) === 'TM'
                || str_contains(self::canonicalize_text($reason . ' ' . self::dashboard_term_name($post_id, 'status-loja')), 'transito'),
            'missingPhoto' => empty($photos),
            'missingPrice' => $price <= 0,
            'status' => $status_label,
            'postStatus' => $post_status,
            'draftReason' => $reason,
            'visibleOnSite' => $post_status === 'publish',
            'inApolo' => $in_apolo,
            'apoloCompany' => (string) get_post_meta($post_id, 'apolo_empresa', true),
            'apoloReseller' => (string) get_post_meta($post_id, 'apolo_revenda_origem', true),
            'apoloRemovedAt' => (string) get_post_meta($post_id, 'apolo_removido_em', true),
            'apoloSoldAt' => (string) get_post_meta($post_id, 'apolo_vendido_em', true),
            'apoloFirstSeenAt' => (string) get_post_meta($post_id, 'apolo_primeiro_visto_em', true),
            'apoloPurchasedAt' => (string) get_post_meta($post_id, 'apolo_comprado_em', true),
            'apoloLastSeenAt' => (string) get_post_meta($post_id, 'apolo_ultimo_visto_em', true),
            'apoloOperationalStatus' => (string) get_post_meta($post_id, 'apolo_status_operacional', true),
            'apoloSituation' => strtoupper((string) get_post_meta($post_id, 'apolo_situacao', true)),
            'apoloUpdatedAt' => (string) get_post_meta($post_id, 'apolo_atualizado_em', true),
            'createdAt' => get_post_time('c', true, $post_id),
        ];
    }

    private static function dashboard_vehicle_is_allowed_company_reseller(array $vehicle): bool {
        $company = preg_replace('/\D+/', '', (string) ($vehicle['apoloCompany'] ?? ''));
        $reseller = preg_replace('/\D+/', '', (string) ($vehicle['apoloReseller'] ?? ''));

        if ($company === '' || $reseller === '') {
            return false;
        }

        return in_array(ltrim($company, '0') . ':' . ltrim($reseller, '0'), self::get_apolo_allowed_company_resellers(), true);
    }

    private static function resolve_vehicle_sale_price(array $vehicle, array $apolo_item): float {
        $apolo_sale_price = self::parse_money_value($apolo_item['valor_venda'] ?? null);
        if ($apolo_sale_price > 0) {
            return $apolo_sale_price;
        }

        return self::parse_money_value($vehicle['value'] ?? null);
    }

    private static function upsert_vehicle(array $vehicle, array $apolo_stock_index, ?array $apolo_item = null): void {
        $external_id = (string) $vehicle['id'];
        $plate = self::normalize_plate((string) ($vehicle['plate'] ?? ''));
        $vin = self::normalize_vehicle_lookup_key((string) ($vehicle['vin'] ?? ($vehicle['chassi'] ?? ($vehicle['chassis'] ?? ''))));
        $existing = get_posts([
            'post_type' => self::POST_TYPE,
            'post_status' => 'any',
            'meta_key' => 'identificador_externo',
            'meta_value' => $external_id,
            'posts_per_page' => 1,
            'fields' => 'ids',
        ]);
        $post_id_by_external = !empty($existing) ? (int) $existing[0] : 0;
        $post_id_by_plate_oldest = $plate !== '' ? self::find_oldest_post_id_by_plate($plate) : 0;
        $post_id_by_vin_oldest = $vin !== '' ? self::find_oldest_post_id_by_vin($vin) : 0;
        $post_id = $post_id_by_plate_oldest > 0 ? $post_id_by_plate_oldest : ($post_id_by_vin_oldest > 0 ? $post_id_by_vin_oldest : $post_id_by_external);
        $vehicle = self::normalize_vehicle_identity($vehicle);
        $apolo_reconciliation = self::reconcile_autosync_vehicle_with_apolo($vehicle, $apolo_stock_index, $apolo_item);

        $title_model = trim((string) ($apolo_reconciliation['apolo']['des_modelo'] ?? ''));
        if ($title_model === '') {
            $title_model = (string) ($vehicle['modelName'] ?? '');
        }
        $title_model = self::strip_vehicle_leading_brand_label(
            self::strip_vehicle_multibrand_label($title_model),
            (string) ($vehicle['brandName'] ?? '')
        );
        $title_parts = [
            isset($vehicle['brandName']) ? (string) $vehicle['brandName'] : '',
            $title_model,
            isset($vehicle['modelYear']) ? (string) $vehicle['modelYear'] : '',
        ];
        $title = trim(preg_replace('/\s+/', ' ', implode(' ', array_filter($title_parts))));
        if ($title === '') {
            $title = 'Veiculo ' . $external_id;
        }
        $title = self::strip_apolo_draft_reason_from_title($title);
        $current_post = $post_id > 0 ? get_post($post_id) : null;
        $current_status = $current_post ? (string) $current_post->post_status : '';
        if (
            $post_id > 0
            && $apolo_reconciliation['reason'] === self::PRICE_OVERRIDE_REASON
            && self::has_price_override_justification($post_id)
        ) {
            $apolo_reconciliation['status'] = 'publish';
        }
        if (
            $post_id > 0
            && self::has_manual_status_lock($post_id)
            && in_array($current_status, ['publish', 'draft', 'pending', 'private', 'future'], true)
        ) {
            $apolo_reconciliation['status'] = $current_status;
            $apolo_reconciliation['manual_status_lock'] = true;
        }
        $official_unit_name = self::resolve_official_unidade_name($apolo_reconciliation['apolo'] ?? [], (string) ($vehicle['entityName'] ?? ''));
        $published_price = self::resolve_vehicle_sale_price($vehicle, $apolo_reconciliation['apolo'] ?? []);
        $photo_urls = self::extract_vehicle_photo_urls($vehicle);
        $sync_signature = self::build_vehicle_sync_signature($vehicle, $apolo_reconciliation, $photo_urls, $official_unit_name, $title);

        if ($post_id > 0) {
            $previous_signature = (string) get_post_meta($post_id, 'savol_sync_signature', true);
            $current_price = self::parse_money_value(get_post_meta($post_id, 'preco', true));
            $current_title = $current_post ? self::strip_apolo_draft_reason_from_title((string) $current_post->post_title) : '';
            if (
                $previous_signature !== ''
                && hash_equals($previous_signature, $sync_signature)
                && $current_status === (string) $apolo_reconciliation['status']
                && $current_title === $title
                && abs($current_price - $published_price) < 0.01
            ) {
                return;
            }
        }

        $postarr = [
            'post_type' => self::POST_TYPE,
            'post_title' => $title,
            'post_status' => $apolo_reconciliation['status'],
            'post_content' => isset($vehicle['comments']) ? wp_kses_post((string) $vehicle['comments']) : '',
        ];
        if ($post_id > 0) {
            $postarr['ID'] = $post_id;
            $post_id = (int) wp_update_post($postarr, true);
        } else {
            $post_id = (int) wp_insert_post($postarr, true);
        }
        if ($post_id <= 0 || is_wp_error($post_id)) {
            return;
        }

        update_post_meta($post_id, 'identificador_externo', $external_id);
        update_post_meta($post_id, 'placa', $plate);
        update_post_meta($post_id, 'renavam', (string) ($vehicle['renavam'] ?? ''));
        update_post_meta($post_id, 'chassi_vin', $vin);
        update_post_meta($post_id, 'ano', is_numeric($vehicle['manufacturingYear'] ?? null) ? (float) $vehicle['manufacturingYear'] : 0);
        update_post_meta($post_id, 'ano_modelo', is_numeric($vehicle['modelYear'] ?? null) ? (float) $vehicle['modelYear'] : 0);
        update_post_meta($post_id, 'km', is_numeric($vehicle['kilometers'] ?? null) ? (float) $vehicle['kilometers'] : 0);
        update_post_meta($post_id, 'preco', $published_price);
        $fipe_value = self::parse_money_value($vehicle['fipeValue'] ?? ($apolo_reconciliation['apolo']['fipeValue'] ?? ($apolo_reconciliation['apolo']['fipe_value'] ?? ($apolo_reconciliation['apolo']['valor_fipe'] ?? null))));
        update_post_meta($post_id, 'fipe', $fipe_value);
        update_post_meta($post_id, 'apolo_fipe', $fipe_value);
        update_post_meta($post_id, 'status', isset($vehicle['status']) ? (string) $vehicle['status'] : '');
        update_post_meta($post_id, 'apolo_empresa', (string) ($apolo_reconciliation['apolo']['empresa'] ?? ''));
        update_post_meta($post_id, 'apolo_revenda_origem', (string) ($apolo_reconciliation['apolo']['revenda_origem'] ?? ''));
        update_post_meta($post_id, 'apolo_situacao', (string) ($apolo_reconciliation['apolo']['situacao'] ?? ''));
        update_post_meta($post_id, 'apolo_val_compra', self::parse_money_value($apolo_reconciliation['apolo']['val_compra'] ?? null));
        update_post_meta($post_id, 'apolo_valor_venda', self::parse_money_value($apolo_reconciliation['apolo']['valor_venda'] ?? null));
        update_post_meta($post_id, 'apolo_des_cor', (string) ($apolo_reconciliation['apolo']['des_cor'] ?? ''));
        update_post_meta($post_id, 'apolo_des_modelo', (string) ($apolo_reconciliation['apolo']['des_modelo'] ?? ''));
        update_post_meta($post_id, 'apolo_des_combustivel', (string) ($apolo_reconciliation['apolo']['des_combustivel'] ?? ''));
        update_post_meta($post_id, 'apolo_ano_fabricacao', (string) ($apolo_reconciliation['apolo']['ano_fabricacao'] ?? ''));
        update_post_meta($post_id, 'apolo_ano_modelo', (string) ($apolo_reconciliation['apolo']['ano_modelo'] ?? ''));
        update_post_meta($post_id, 'apolo_km_atual', (string) ($apolo_reconciliation['apolo']['km_atual'] ?? ''));
        update_post_meta($post_id, 'apolo_cambio', (string) ($apolo_reconciliation['apolo']['cambio'] ?? ''));
        update_post_meta($post_id, 'apolo_tipo', (string) ($apolo_reconciliation['apolo']['tipo'] ?? ''));
        update_post_meta(
            $post_id,
            'apolo_fotos_urls',
            implode("\n", isset($apolo_reconciliation['apolo']['photo_urls']) && is_array($apolo_reconciliation['apolo']['photo_urls'])
                ? $apolo_reconciliation['apolo']['photo_urls']
                : [])
        );
        update_post_meta($post_id, 'apolo_nome_fantasia', (string) ($apolo_reconciliation['apolo']['nome_fantasia'] ?? ''));
        update_post_meta($post_id, 'apolo_cnpj', (string) ($apolo_reconciliation['apolo']['cnpj'] ?? ''));
        update_post_meta($post_id, 'apolo_negociacao', !empty($apolo_reconciliation['apolo']['negociacao']) ? 1 : 0);
        update_post_meta($post_id, 'apolo_transito', !empty($apolo_reconciliation['apolo']['transito']) ? 1 : 0);
        update_post_meta($post_id, 'apolo_proposta', (string) ($apolo_reconciliation['apolo']['proposta'] ?? ''));
        update_post_meta($post_id, 'apolo_vendedor_proposta', (string) ($apolo_reconciliation['apolo']['vendedor_proposta'] ?? ''));
        update_post_meta($post_id, 'apolo_dias_estoque', max(0, (int) ($apolo_reconciliation['apolo']['dias_estoque'] ?? 0)));
        $apolo_proposal_days = self::extract_apolo_proposal_days($apolo_reconciliation['apolo'] ?? []);
        if ($apolo_proposal_days !== null) {
            update_post_meta($post_id, 'apolo_dias_proposta', $apolo_proposal_days);
        } else {
            delete_post_meta($post_id, 'apolo_dias_proposta');
        }
        update_post_meta(
            $post_id,
            'apolo_blindado',
            !empty($apolo_reconciliation['apolo']['blindado_informado'])
                ? (!empty($apolo_reconciliation['apolo']['blindado']) ? 1 : 0)
                : ''
        );
        $now = current_time('mysql');
        $was_in_apolo = (string) get_post_meta($post_id, 'apolo_presente', true) === '1';

        if ((string) get_post_meta($post_id, 'apolo_primeiro_visto_em', true) === '') {
            update_post_meta($post_id, 'apolo_primeiro_visto_em', $now);
        }
        if (!$was_in_apolo) {
            update_post_meta($post_id, 'apolo_comprado_em', $now);
        }

        update_post_meta($post_id, 'apolo_reconciliacao_motivo', (string) $apolo_reconciliation['reason']);
        update_post_meta($post_id, 'apolo_presente', 1);
        update_post_meta($post_id, 'apolo_atualizado_em', $now);
        update_post_meta($post_id, 'apolo_ultimo_visto_em', $now);
        delete_post_meta($post_id, 'apolo_removido_em');
        delete_post_meta($post_id, 'apolo_vendido_em');
        update_post_meta($post_id, 'apolo_status_operacional', 'em_estoque');
        update_post_meta($post_id, 'combustivel', (string) ($vehicle['fuelName'] ?? ''));
        update_post_meta($post_id, 'cambio', (string) ($vehicle['transmissionName'] ?? ''));
        update_post_meta($post_id, 'categoria', (string) ($vehicle['section'] ?? ''));
        update_post_meta($post_id, 'carroceria', (string) ($vehicle['section'] ?? ''));
        update_post_meta($post_id, 'portas', is_numeric($vehicle['doors'] ?? null) ? (float) $vehicle['doors'] : 0);
        update_post_meta($post_id, 'lugares', is_numeric($vehicle['passengers'] ?? null) ? (float) $vehicle['passengers'] : 0);
        update_post_meta($post_id, 'tracao', '');
        update_post_meta($post_id, 'motor', isset($vehicle['engineCapacity']) ? (string) $vehicle['engineCapacity'] : '');
        update_post_meta($post_id, 'potencia_cv', is_numeric($vehicle['power'] ?? null) ? (float) $vehicle['power'] : 0);
        update_post_meta($post_id, 'torque_nm', 0);
        update_post_meta($post_id, 'qtd_donos', 0);
        update_post_meta($post_id, 'condicao', isset($vehicle['conditionType']) ? (string) $vehicle['conditionType'] : '');
        update_post_meta($post_id, 'ipva_pago', 0);
        update_post_meta($post_id, 'licenciado', 0);
        update_post_meta($post_id, 'blindado', self::is_vehicle_armored($vehicle) ? 1 : 0);
        update_post_meta($post_id, 'negociacao', !empty($apolo_reconciliation['apolo']['negociacao']) ? 1 : 0);
        update_post_meta($post_id, 'repasse', !empty($apolo_reconciliation['apolo']['repasse']) ? 1 : 0);
        update_post_meta($post_id, 'transito', !empty($apolo_reconciliation['apolo']['transito']) ? 1 : 0);
        update_post_meta($post_id, 'dias_estoque', max(0, (int) ($apolo_reconciliation['apolo']['dias_estoque'] ?? 0)));
        if ($apolo_proposal_days !== null) {
            update_post_meta($post_id, 'dias_proposta', $apolo_proposal_days);
        } else {
            delete_post_meta($post_id, 'dias_proposta');
        }
        self::set_term_if_value($post_id, 'veiculo_marca', (string) ($vehicle['brandName'] ?? ''));
        self::set_term_if_value($post_id, 'veiculo_modelo', (string) ($vehicle['modelName'] ?? ''));
        self::set_term_if_value($post_id, 'veiculo_versao', (string) ($vehicle['versionName'] ?? ''));
        self::set_term_if_value($post_id, 'veiculo_cor', (string) ($vehicle['colorName'] ?? ''));
        self::set_status_loja_term($post_id, (string) $apolo_reconciliation['reason']);
        self::set_term_if_value($post_id, 'veiculo_cidade', self::extract_city_from_unidade($official_unit_name));
        self::set_term_if_value($post_id, 'veiculo_uf', 'SP');
        self::assign_unidade_term_with_contacts($post_id, $official_unit_name);
        self::assign_informacao_destaque_terms(
            $post_id,
            $vehicle,
            !empty($apolo_reconciliation['apolo']['repasse'])
        );
        self::assign_destaque_secundario_terms(
            $post_id,
            $vehicle,
            $published_price,
            !empty($apolo_reconciliation['apolo']['repasse'])
        );
        if (!$was_in_apolo) {
            self::record_dashboard_operation('entrada', $post_id, $now);
        }

        $real_photo_urls = self::extract_real_vehicle_photo_urls($photo_urls);
        $card_photo_url = (string) ($real_photo_urls[0] ?? '');
        $photo_urls_text = implode("\n", $photo_urls);
        update_post_meta($post_id, 'autosync_photo_urls', $photo_urls_text);
        update_post_meta($post_id, 'autosync_foto_destaque_url', $card_photo_url);
        update_post_meta($post_id, 'autosync_galeria_urls', $photo_urls_text);
        update_post_meta($post_id, 'quantidade_fotos', count($real_photo_urls));
        self::sync_vehicle_featured_photo($post_id, $card_photo_url);
        update_post_meta($post_id, 'savol_sync_signature', $sync_signature);
        if ($plate !== '') {
            self::cleanup_duplicate_plate_posts($post_id, $plate);
        }
    }

    private static function assign_informacao_destaque_terms(int $post_id, array $vehicle, bool $is_repasse = false): void {
        if ($is_repasse) {
            wp_set_object_terms($post_id, [], 'veiculo_informacao_destaque', false);
            return;
        }

        $terms = self::extract_named_items($vehicle['VehicleFeatures'] ?? []);
        wp_set_object_terms($post_id, $terms, 'veiculo_informacao_destaque', false);
    }

    private static function assign_destaque_secundario_terms(
        int $post_id,
        array $vehicle,
        ?float $published_price = null,
        bool $is_repasse = false
    ): void {
        if ($is_repasse) {
            wp_set_object_terms($post_id, [], 'veiculo_destaque_secundario', false);
            return;
        }

        $terms = [];

        if (self::has_low_annual_mileage($vehicle)) {
            $terms[] = 'Baixa km';
        }

        if (self::has_complete_optionals($vehicle)) {
            $terms[] = 'Completo';
        }

        wp_set_object_terms($post_id, array_values(array_unique($terms)), 'veiculo_destaque_secundario', false);
    }

    private static function has_low_annual_mileage(array $vehicle): bool {
        $km = is_numeric($vehicle['kilometers'] ?? null) ? (float) $vehicle['kilometers'] : 0;
        $manufacturing_year = is_numeric($vehicle['manufacturingYear'] ?? null) ? (int) $vehicle['manufacturingYear'] : 0;
        $current_year = (int) gmdate('Y');

        if ($km <= 0 || $km > 100000 || $manufacturing_year < 1980 || $manufacturing_year > $current_year) {
            return false;
        }

        $vehicle_age_years = max(1, $current_year - $manufacturing_year);
        return ($km / $vehicle_age_years) <= 10000;
    }

    private static function extract_named_items($items): array {
        if (!is_array($items)) {
            return [];
        }

        $names = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $name = '';
            foreach (['optionalName', 'name', 'label', 'title'] as $key) {
                if (!empty($item[$key])) {
                    $name = (string) $item[$key];
                    break;
                }
            }

            $name = trim($name);
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return array_values(array_unique($names));
    }

    private static function has_avaria_photo(array $vehicle): bool {
        if (empty($vehicle['VehiclePhotos']) || !is_array($vehicle['VehiclePhotos'])) {
            return false;
        }

        foreach ($vehicle['VehiclePhotos'] as $photo) {
            if (!is_array($photo)) {
                continue;
            }
            $label = self::canonicalize_text((string) ($photo['label'] ?? ''));
            if (str_contains($label, 'avaria')) {
                return true;
            }
        }

        return false;
    }

    private static function has_complete_optionals(array $vehicle): bool {
        $optionals = array_merge(
            self::extract_named_items($vehicle['VehicleOptionals'] ?? []),
            self::extract_named_items($vehicle['VehicleEquipments'] ?? [])
        );
        $normalized = array_map([__CLASS__, 'canonicalize_text'], $optionals);
        $matched = 0;

        $rules = [
            ['ar condicionado'],
            ['direcao hidraulica', 'direcao eletrica'],
            ['vidro eletrico', 'vidros eletricos'],
            ['trava eletrica', 'travas eletricas'],
            ['retrovisor eletrico', 'retrovisores eletricos'],
            ['airbag'],
            ['freio abs', 'freios abs', 'abs'],
            ['alarme'],
            ['som', 'central multimidia', 'multimidia', 'multimedia'],
        ];

        foreach ($rules as $needles) {
            if (self::optional_list_contains_any($normalized, $needles)) {
                $matched++;
            }
        }

        return $matched >= 8;
    }

    private static function is_vehicle_armored(array $vehicle): bool {
        if (!empty($vehicle['_apolo_blindado_informado'])) {
            return self::to_boolean_flag($vehicle['blindado'] ?? false);
        }

        foreach (['blindado', 'blindagem', 'isBlindado', 'is_blindado', 'armored', 'armor', 'isArmored', 'is_armored', 'shielded', 'isShielded'] as $key) {
            if (array_key_exists($key, $vehicle) && self::to_boolean_flag($vehicle[$key])) {
                return true;
            }
        }

        $texts = [
            (string) ($vehicle['comments'] ?? ''),
            (string) ($vehicle['versionName'] ?? ''),
            (string) ($vehicle['modelName'] ?? ''),
            (string) ($vehicle['section'] ?? ''),
        ];
        $texts = array_merge(
            $texts,
            self::extract_named_items($vehicle['VehicleFeatures'] ?? []),
            self::extract_named_items($vehicle['VehicleOptionals'] ?? []),
            self::extract_named_items($vehicle['VehicleEquipments'] ?? [])
        );

        foreach ($texts as $text) {
            if (self::text_indicates_armored((string) $text)) {
                return true;
            }
        }

        return false;
    }

    private static function text_indicates_armored(string $text): bool {
        $normalized = self::canonicalize_text($text);
        if (!str_contains($normalized, 'blindado') && !str_contains($normalized, 'blindagem')) {
            return false;
        }

        foreach (['nao blindado', 'blindado nao', 'sem blindagem', 'blindagem nao', 'nao possui blindagem'] as $negative) {
            if (str_contains($normalized, $negative)) {
                return false;
            }
        }

        return true;
    }

    private static function to_boolean_flag($value): bool {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (float) $value > 0;
        }

        $normalized = self::canonicalize_text((string) $value);
        return in_array($normalized, ['1', 's', 'sim', 'true', 'yes', 'y'], true);
    }

    private static function optional_list_contains_any(array $optionals, array $needles): bool {
        foreach ($optionals as $optional) {
            foreach ($needles as $needle) {
                if (str_contains($optional, $needle)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static function normalize_plate(string $plate): string {
        $plate = strtoupper(trim($plate));
        $plate = preg_replace('/[^A-Z0-9]/', '', $plate);
        return (string) $plate;
    }

    private static function find_oldest_post_id_by_plate(string $plate): int {
        $plate = self::normalize_plate($plate);
        if ($plate === '') {
            return 0;
        }

        $query = new \WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => 'placa',
                    'value' => $plate,
                    'compare' => '=',
                ],
            ],
            'orderby' => [
                'date' => 'ASC',
                'ID' => 'ASC',
            ],
        ]);

        if (!empty($query->posts)) {
            return (int) $query->posts[0];
        }

        return 0;
    }

    private static function find_oldest_post_id_by_vin(string $vin): int {
        $vin = self::normalize_vehicle_lookup_key($vin);
        if ($vin === '') {
            return 0;
        }

        $query = new \WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => 'chassi_vin',
                    'value' => $vin,
                    'compare' => '=',
                ],
            ],
            'orderby' => [
                'date' => 'ASC',
                'ID' => 'ASC',
            ],
        ]);

        if (!empty($query->posts)) {
            return (int) $query->posts[0];
        }

        return 0;
    }

    private static function cleanup_duplicate_plate_posts(int $keep_post_id, string $plate): void {
        $plate = self::normalize_plate($plate);
        if ($plate === '' || $keep_post_id <= 0) {
            return;
        }

        $query = new \WP_Query([
            'post_type' => self::POST_TYPE,
            'post_status' => ['publish', 'draft', 'pending', 'private', 'future'],
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => 'placa',
                    'value' => $plate,
                    'compare' => '=',
                ],
            ],
        ]);

        if (empty($query->posts)) {
            return;
        }

        foreach ($query->posts as $duplicate_id) {
            $duplicate_id = (int) $duplicate_id;
            if ($duplicate_id === $keep_post_id) {
                continue;
            }
            wp_trash_post($duplicate_id);
        }
    }

    private static function sync_vehicle_featured_photo(int $post_id, string $url): void {
        $url = esc_url_raw($url);
        delete_post_meta($post_id, 'galeria_fotos');

        if ($url === '') {
            delete_post_thumbnail($post_id);
            return;
        }

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        add_filter('http_request_timeout', [__CLASS__, 'get_photo_import_timeout']);
        try {
            $attachment_id = self::find_attachment_by_source_url($url);
            if ($attachment_id <= 0) {
                $attachment_id = media_sideload_image($url, $post_id, null, 'id');
                if (is_wp_error($attachment_id)) {
                    delete_post_thumbnail($post_id);
                    return;
                }
                $attachment_id = (int) $attachment_id;
                if ($attachment_id <= 0) {
                    delete_post_thumbnail($post_id);
                    return;
                }
                update_post_meta($attachment_id, '_savol_source_url', $url);
            }

            wp_update_post(['ID' => $attachment_id, 'post_parent' => $post_id]);
            update_post_meta($post_id, 'galeria_fotos', (string) $attachment_id);
            set_post_thumbnail($post_id, $attachment_id);
        } finally {
            remove_filter('http_request_timeout', [__CLASS__, 'get_photo_import_timeout']);
        }
    }

    private static function find_attachment_by_source_url(string $url): int {
        $query = new \WP_Query([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_key' => '_savol_source_url',
            'meta_value' => $url,
        ]);
        if (!empty($query->posts)) {
            return (int) $query->posts[0];
        }
        return 0;
    }

    public static function get_photo_import_timeout(): int {
        return self::PHOTO_IMPORT_TIMEOUT;
    }

    private static function update_progress(array $progress): void {
        $progress['updated_at'] = time();
        update_option(self::AUTOSYNC_PROGRESS_OPTION, $progress, false);
    }

    private static function recover_stale_autosync_progress($progress): array {
        if (!is_array($progress)) {
            return [];
        }

        $status = (string) ($progress['status'] ?? '');
        if (!in_array($status, ['queued', 'running'], true)) {
            return $progress;
        }

        $now = time();
        $batch = get_option(self::AUTOSYNC_BATCH_OPTION, []);
        $has_batch = is_array($batch) && !empty($batch['rows']) && isset($batch['index'], $batch['total']);
        $last_activity = (int) ($progress['updated_at'] ?? 0);
        if ($last_activity <= 0 && $has_batch) {
            $last_activity = (int) ($batch['started_at'] ?? 0);
        }

        $next_event = wp_next_scheduled('savol_veiculos_run_autosync_cron');
        $api_lock_started = (int) get_option(self::AUTOSYNC_API_LOCK_OPTION, 0);
        $has_active_api_lock = $api_lock_started > 0
            && ($now - $api_lock_started) <= self::AUTOSYNC_API_LOCK_TTL;
        $has_worker_event = $next_event !== false;

        if (!$has_batch && !$has_worker_event && !$has_active_api_lock) {
            $is_stale = true;
        } elseif ($last_activity > 0) {
            $is_stale = ($now - $last_activity) > self::AUTOSYNC_PROGRESS_STALE_TTL;
        } elseif ($has_batch) {
            $is_stale = true;
        } else {
            $is_stale = ((int) $next_event) < ($now - self::AUTOSYNC_PROGRESS_STALE_TTL);
        }

        if (!$is_stale) {
            return $progress;
        }

        delete_option(self::AUTOSYNC_BATCH_OPTION);
        delete_option(self::AUTOSYNC_API_LOCK_OPTION);
        wp_clear_scheduled_hook('savol_veiculos_run_autosync_cron');

        $message = 'A sincronizacao anterior foi interrompida. O botao foi liberado para uma nova tentativa.';
        update_option(self::AUTOSYNC_LAST_ERROR_OPTION, $message, false);
        $recovered = [
            'status' => 'error',
            'processed' => (int) ($progress['processed'] ?? 0),
            'total' => (int) ($progress['total'] ?? 0),
            'percent' => 100,
            'message' => $message,
        ];
        self::update_progress($recovered);

        return array_merge($recovered, ['updated_at' => time()]);
    }

    private static function get_autosync_api_wait_seconds(): int {
        $last_call = (int) get_option(self::AUTOSYNC_LAST_API_CALL_OPTION, 0);
        if ($last_call <= 0) {
            return 0;
        }

        $elapsed = time() - $last_call;
        if ($elapsed >= self::AUTOSYNC_API_MIN_INTERVAL) {
            return 0;
        }

        return self::AUTOSYNC_API_MIN_INTERVAL - max(0, $elapsed);
    }

    private static function format_autosync_wait_message(int $wait_seconds): string {
        $minutes = (int) ceil(max(1, $wait_seconds) / 60);
        return 'A API AutoSync permite apenas uma chamada a cada 3 minutos. Aguarde cerca de ' . $minutes . ' min para tentar novamente.';
    }

    private static function acquire_autosync_api_lock(): bool {
        $now = time();
        $current = (int) get_option(self::AUTOSYNC_API_LOCK_OPTION, 0);
        if ($current > 0 && ($now - $current) > self::AUTOSYNC_API_LOCK_TTL) {
            delete_option(self::AUTOSYNC_API_LOCK_OPTION);
        }

        return add_option(self::AUTOSYNC_API_LOCK_OPTION, $now, '', 'no');
    }

    private static function release_autosync_api_lock(): void {
        delete_option(self::AUTOSYNC_API_LOCK_OPTION);
    }

    private static function set_term_if_value(int $post_id, string $taxonomy, string $value): void {
        $value = trim($value);
        if ($value === '') {
            return;
        }
        wp_set_object_terms($post_id, [$value], $taxonomy, false);
    }

    private static function set_status_loja_term(int $post_id, string $reason): void {
        $term = trim($reason);
        if ($term === '') {
            $term = 'Publicado';
        }

        wp_set_object_terms($post_id, [$term], 'status-loja', false);
    }

    private static function resolve_official_unidade_name(array $apolo_item, string $fallback_entity_name): string {
        $cnpj = preg_replace('/\D+/', '', (string) ($apolo_item['cnpj'] ?? ''));
        $fantasy_name = trim((string) ($apolo_item['nome_fantasia'] ?? ''));
        $normalized = self::canonicalize_text($fantasy_name . ' ' . $fallback_entity_name);

        if (str_contains($normalized, 'mg') || str_contains($normalized, 'motor')) {
            if (str_contains($normalized, 'analia')) {
                return 'Unidade SAVOL MG Motor Anália Franco';
            }
            return 'Unidade SAVOL MG Motor São Caetano';
        }

        if (str_contains($normalized, 'jetour')) {
            if (str_contains($normalized, 'sao caetano') || str_contains($normalized, 'scs')) {
                return 'Unidade SAVOL JETOUR São Caetano do Sul';
            }
            return 'Unidade SAVOL JETOUR Santo André';
        }

        $by_cnpj = [
            '62870730000109' => 'Unidade SAVOL MG Motor São Caetano',
            '65214691000171' => 'Unidade SAVOL JETOUR Santo André',
        ];
        if ($cnpj !== '' && isset($by_cnpj[$cnpj])) {
            return $by_cnpj[$cnpj];
        }

        return trim($fallback_entity_name);
    }

    private static function assign_unidade_term_with_contacts(int $post_id, string $entity_name): void {
        $entity_name = trim($entity_name);
        if ($entity_name === '') {
            return;
        }

        wp_set_object_terms($post_id, [$entity_name], 'veiculo_unidade', false);
        $term = get_term_by('name', $entity_name, 'veiculo_unidade');
        if (!$term || is_wp_error($term)) {
            return;
        }

        $contacts = self::find_unidade_contacts($entity_name);
        if (empty($contacts)) {
            return;
        }

        if (!empty($contacts['telefone'])) {
            update_term_meta((int) $term->term_id, 'veiculo_unidade_telefone', $contacts['telefone']);
        }
        if (!empty($contacts['whatsapp'])) {
            update_term_meta((int) $term->term_id, 'veiculo_unidade_whatsapp', $contacts['whatsapp']);
        }
        if (!empty($contacts['email'])) {
            update_term_meta((int) $term->term_id, 'veiculo_unidade_email', $contacts['email']);
        }
        if (!empty($contacts['endereco'])) {
            update_term_meta((int) $term->term_id, 'veiculo_unidade_endereco', $contacts['endereco']);
        }
    }

    private static function find_unidade_contacts(string $name): array {
        $normalized_name = self::normalize_text($name);
        $canonical_name = self::canonicalize_text($name);
        $candidates = array_values(array_unique([
            $normalized_name,
            'unidade ' . $normalized_name,
            $canonical_name,
            self::canonicalize_text('unidade ' . $name),
        ]));

        foreach (self::UNIDADE_CONTACTS as $key => $contacts) {
            $key_canonical = self::canonicalize_text($key);
            foreach ($candidates as $candidate) {
                if ($candidate === $key || $candidate === $key_canonical) {
                    return $contacts;
                }
                if (str_contains($key, $candidate) || str_contains($candidate, $key)) {
                    return $contacts;
                }
                if (str_contains($key_canonical, $candidate) || str_contains($candidate, $key_canonical)) {
                    return $contacts;
                }
            }
        }

        return [];
    }

    private static function extract_city_from_unidade(string $unit_name): string {
        $normalized = self::canonicalize_text($unit_name);
        if (str_contains($normalized, 'sao caetano')) {
            return 'São Caetano do Sul';
        }
        if (str_contains($normalized, 'santo andre')) {
            return 'Santo André';
        }
        if (str_contains($normalized, 'sao bernardo')) {
            return 'São Bernardo do Campo';
        }
        if (str_contains($normalized, 'sao paulo') || str_contains($normalized, 'analia franco') || str_contains($normalized, 'ipiranga')) {
            return 'São Paulo';
        }
        if (str_contains($normalized, 'maua')) {
            return 'Mauá';
        }
        if (str_contains($normalized, 'praia grande')) {
            return 'Praia Grande';
        }

        return self::extract_city($unit_name);
    }

    private static function normalize_text(string $value): string {
        $value = strtolower($value);
        if (function_exists('remove_accents')) {
            $value = remove_accents($value);
        }
        $value = preg_replace('/\s+/', ' ', $value);
        return trim((string) $value);
    }

    private static function canonicalize_text(string $value): string {
        $value = self::normalize_text($value);
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        $value = preg_replace('/\s+/', ' ', (string) $value);
        return trim((string) $value);
    }

    private static function get_autosync_endpoint(): string {
        $stored = (string) get_option(self::AUTOSYNC_ENDPOINT_OPTION, '');
        if ($stored !== '') {
            return untrailingslashit($stored);
        }
        return untrailingslashit(self::AUTOSYNC_ENDPOINT_DEFAULT);
    }

    private static function get_autosync_endpoint_candidates(): array {
        $base = self::get_autosync_endpoint();
        $is_custom = (string) get_option(self::AUTOSYNC_ENDPOINT_OPTION, '') !== '';
        if ($is_custom) {
            return array_values(array_unique([
                esc_url_raw(untrailingslashit($base)),
                esc_url_raw(trailingslashit($base)),
            ]));
        }

        $parsed = wp_parse_url($base);
        $host_root = '';
        if (is_array($parsed) && isset($parsed['scheme'], $parsed['host'])) {
            $host_root = $parsed['scheme'] . '://' . $parsed['host'];
        }

        $candidates = [
            $base,
            trailingslashit($base),
        ];

        if ($host_root !== '') {
            $candidates[] = $host_root . '/vehicle/stock';
            $candidates[] = $host_root . '/vehicle/stocks';
            $candidates[] = $host_root . '/vehicles/stock';
            $candidates[] = $host_root . '/vehicles/stocks';
            $candidates[] = $host_root . '/stock';
            $candidates[] = $host_root . '/api/vehicle/stock';
            $candidates[] = $host_root . '/api/vehicles/stock';
        }

        $clean = [];
        foreach ($candidates as $url) {
            $url = trim((string) $url);
            if ($url === '') {
                continue;
            }
            $clean[] = esc_url_raw($url);
        }

        return array_values(array_unique($clean));
    }

    private static function get_autosync_entity_ids_text(): string {
        return implode("\n", self::get_stored_autosync_list(self::AUTOSYNC_ENTITY_IDS_OPTION));
    }

    private static function get_autosync_cnpjs_text(): string {
        return implode("\n", self::get_stored_autosync_list(self::AUTOSYNC_CNPJS_OPTION));
    }

    private static function apolo_situation_choices(): array {
        return array_values(array_unique(array_merge(
            self::APOLO_ALLOWED_SITUATIONS_DEFAULT,
            ['TM', 'SD']
        )));
    }

    private static function get_apolo_allowed_situations(): array {
        $stored = get_option(self::APOLO_ALLOWED_SITUATIONS_OPTION, []);
        $situations = is_array($stored)
            ? self::normalize_apolo_situations($stored)
            : self::normalize_apolo_situations([(string) $stored]);

        return !empty($situations) ? $situations : self::APOLO_ALLOWED_SITUATIONS_DEFAULT;
    }

    private static function get_apolo_allowed_situations_extra_text(): string {
        $extra = array_values(array_diff(self::get_apolo_allowed_situations(), self::apolo_situation_choices()));
        return implode(', ', $extra);
    }

    private static function normalize_apolo_situations(array $items): array {
        $clean = [];
        foreach ($items as $item) {
            $value = strtoupper(preg_replace('/[^A-Z0-9]+/i', '', (string) $item));
            if ($value !== '' && strlen($value) <= 10 && !in_array($value, $clean, true)) {
                $clean[] = $value;
            }
        }

        return array_slice($clean, 0, 20);
    }

    private static function normalize_apolo_situations_text(string $raw): array {
        return self::normalize_apolo_situations((array) preg_split('/[\s,;]+/', $raw));
    }

    private static function get_apolo_allowed_company_resellers_text(): string {
        return implode("\n", array_map(static function (string $pair): string {
            return str_replace(':', '/', $pair);
        }, self::get_apolo_allowed_company_resellers()));
    }

    private static function get_apolo_allowed_company_resellers(): array {
        $stored = get_option(self::APOLO_ALLOWED_COMPANY_RESELLERS_OPTION, []);
        $pairs = is_array($stored)
            ? self::normalize_apolo_company_resellers(implode("\n", array_map('strval', $stored)))
            : self::normalize_apolo_company_resellers((string) $stored);

        return !empty($pairs) ? $pairs : self::APOLO_ALLOWED_COMPANY_RESELLERS_DEFAULT;
    }

    private static function normalize_apolo_company_resellers(string $raw): array {
        $items = preg_split('/[\r\n,;]+/', $raw);
        $clean = [];
        foreach ((array) $items as $item) {
            if (!preg_match('/(\d+)\D+(\d+)/', (string) $item, $matches)) {
                continue;
            }

            $company = ltrim($matches[1], '0');
            $reseller = ltrim($matches[2], '0');
            if ($company === '') {
                $company = '0';
            }
            if ($reseller === '') {
                $reseller = '0';
            }

            $pair = $company . ':' . $reseller;
            if (!in_array($pair, $clean, true)) {
                $clean[] = $pair;
            }
        }

        return array_slice($clean, 0, 100);
    }

    private static function get_stored_autosync_list(string $option): array {
        $stored = get_option($option, []);
        if (is_array($stored)) {
            return array_values(array_filter(array_map('strval', $stored)));
        }

        return self::normalize_autosync_list((string) $stored, $option === self::AUTOSYNC_CNPJS_OPTION);
    }

    private static function normalize_autosync_list(string $raw, bool $digits_only): array {
        $parts = preg_split('/[\s,;]+/', $raw);
        $clean = [];
        foreach ((array) $parts as $part) {
            $value = trim((string) $part);
            if ($digits_only) {
                $value = preg_replace('/\D+/', '', $value);
            } else {
                $value = preg_replace('/[^0-9A-Za-z_\-]+/', '', $value);
            }
            if ($value !== '' && !in_array($value, $clean, true)) {
                $clean[] = $value;
            }
        }

        return array_slice($clean, 0, 100);
    }

    private static function filter_autosync_rows(array $rows): array {
        $entity_ids = self::get_stored_autosync_list(self::AUTOSYNC_ENTITY_IDS_OPTION);
        $cnpjs = self::get_stored_autosync_list(self::AUTOSYNC_CNPJS_OPTION);
        if (empty($entity_ids) && empty($cnpjs)) {
            return $rows;
        }

        $filtered = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (self::autosync_row_matches_filters($row, $entity_ids, $cnpjs)) {
                $filtered[] = $row;
            }
        }

        return $filtered;
    }

    private static function autosync_row_matches_filters(array $row, array $entity_ids, array $cnpjs): bool {
        if (!empty($entity_ids) && self::autosync_row_has_value_for_keys($row, $entity_ids, [
            'entityid',
            'entity_id',
            'companyid',
            'company_id',
            'groupid',
            'group_id',
            'dealerid',
            'dealer_id',
            'storeid',
            'store_id',
        ], false)) {
            return true;
        }

        if (!empty($cnpjs) && self::autosync_row_has_value_for_keys($row, $cnpjs, [
            'cnpj',
            'document',
            'documentnumber',
            'document_number',
            'taxid',
            'tax_id',
            'federaltaxnumber',
            'federal_tax_number',
        ], true)) {
            return true;
        }

        return false;
    }

    private static function autosync_row_has_value_for_keys(array $row, array $expected_values, array $keys, bool $digits_only): bool {
        foreach ($row as $key => $value) {
            $normalized_key = strtolower(preg_replace('/[^a-zA-Z0-9_]+/', '', (string) $key));
            if (is_array($value) && self::autosync_row_has_value_for_keys($value, $expected_values, $keys, $digits_only)) {
                return true;
            }
            if (!in_array($normalized_key, $keys, true)) {
                continue;
            }
            if (is_array($value) || is_object($value)) {
                continue;
            }

            $normalized_value = $digits_only
                ? preg_replace('/\D+/', '', (string) $value)
                : preg_replace('/[^0-9A-Za-z_\-]+/', '', (string) $value);
            if ($normalized_value !== '' && in_array($normalized_value, $expected_values, true)) {
                return true;
            }
        }

        return false;
    }

    private static function mask_sensitive(string $text): string {
        if ($text === '') {
            return '';
        }
        $text = preg_replace('/([?&](?:token|access_token)=)[^&]+/i', '$1***', $text);
        return (string) $text;
    }

    private static function extract_city(string $entity_name): string {
        $parts = array_map('trim', explode('-', $entity_name));
        $last = end($parts);
        return is_string($last) ? $last : '';
    }

    private static function encrypt_token(string $plain): string {
        if (!function_exists('openssl_encrypt')) {
            return base64_encode($plain);
        }
        $key = hash('sha256', wp_salt('auth'), true);
        $iv = random_bytes(16);
        $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($cipher === false) {
            return base64_encode($plain);
        }
        return base64_encode($iv . $cipher);
    }

    private static function decrypt_token(string $encoded): string {
        if ($encoded === '') {
            return '';
        }
        $raw = base64_decode($encoded, true);
        if ($raw === false) {
            return '';
        }
        if (!function_exists('openssl_decrypt') || strlen($raw) < 17) {
            return $raw;
        }
        $key = hash('sha256', wp_salt('auth'), true);
        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);
        $plain = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
        if ($plain !== false) {
            return $plain;
        }
        return $raw;
    }
    public static function render_cor_add_fields(): void {
        ?>
        <div class="form-field term-group">
            <label for="veiculo_cor_hex">Cor (hex)</label>
            <input type="text" id="veiculo_cor_hex" name="veiculo_cor_hex" value="#000000" class="savol-color-field" />
        </div>
        <?php
    }

    public static function render_cor_edit_fields(\WP_Term $term): void {
        $hex = (string) get_term_meta($term->term_id, 'veiculo_cor_hex', true);
        if ($hex === '') {
            $hex = '#000000';
        }
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_cor_hex">Cor (hex)</label></th>
            <td><input type="text" id="veiculo_cor_hex" name="veiculo_cor_hex" value="<?php echo esc_attr($hex); ?>" class="savol-color-field" /></td>
        </tr>
        <?php
    }

    public static function save_cor_term_meta(int $term_id): void {
        if (!current_user_can('manage_categories') || !isset($_POST['veiculo_cor_hex'])) {
            return;
        }

        $hex = sanitize_hex_color((string) wp_unslash($_POST['veiculo_cor_hex']));
        if (!$hex) {
            $hex = '#000000';
        }
        update_term_meta($term_id, 'veiculo_cor_hex', $hex);
    }

    public static function render_marca_add_fields(): void {
        ?>
        <div class="form-field term-group">
            <label for="veiculo_marca_logo_id">Logo da marca (PNG/WebP)</label>
            <input type="hidden" id="veiculo_marca_logo_id" name="veiculo_marca_logo_id" class="savol-marca-logo-id" value="" />
            <p>
                <button type="button" class="button savol-marca-logo-upload">Selecionar logo</button>
                <button type="button" class="button savol-marca-logo-remove">Remover</button>
            </p>
            <img class="savol-term-logo-preview" src="" alt="" style="display:none;" />
        </div>
        <?php
    }

    public static function render_marca_edit_fields(\WP_Term $term): void {
        $logo_id = (int) get_term_meta($term->term_id, 'veiculo_marca_logo_id', true);
        $logo_url = $logo_id > 0 ? wp_get_attachment_image_url($logo_id, 'thumbnail') : '';
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_marca_logo_id">Logo da marca (PNG/WebP)</label></th>
            <td>
                <input type="hidden" id="veiculo_marca_logo_id" name="veiculo_marca_logo_id" class="savol-marca-logo-id" value="<?php echo esc_attr((string) $logo_id); ?>" />
                <p>
                    <button type="button" class="button savol-marca-logo-upload">Selecionar logo</button>
                    <button type="button" class="button savol-marca-logo-remove">Remover</button>
                </p>
                <img class="savol-term-logo-preview" src="<?php echo esc_url((string) $logo_url); ?>" alt=""<?php echo $logo_url === '' ? ' style="display:none;"' : ''; ?> />
            </td>
        </tr>
        <?php
    }

    public static function save_marca_term_meta(int $term_id): void {
        if (!current_user_can('manage_categories')) {
            return;
        }

        $logo_id = isset($_POST['veiculo_marca_logo_id']) ? (int) wp_unslash($_POST['veiculo_marca_logo_id']) : 0;
        if ($logo_id <= 0) {
            delete_term_meta($term_id, 'veiculo_marca_logo_id');
            return;
        }

        $file = get_attached_file($logo_id);
        if (!$file) {
            return;
        }

        $file_type = wp_check_filetype($file);
        if (!in_array($file_type['type'], ['image/png', 'image/webp'], true)) {
            return;
        }

        update_term_meta($term_id, 'veiculo_marca_logo_id', $logo_id);
    }

    public static function render_unidade_add_fields(): void {
        ?>
        <div class="form-field term-group">
            <label for="veiculo_unidade_telefone">Telefone</label>
            <input type="text" id="veiculo_unidade_telefone" name="veiculo_unidade_telefone" value="" />
        </div>
        <div class="form-field term-group">
            <label for="veiculo_unidade_whatsapp">WhatsApp</label>
            <input type="text" id="veiculo_unidade_whatsapp" name="veiculo_unidade_whatsapp" value="" />
        </div>
        <div class="form-field term-group">
            <label for="veiculo_unidade_email">E-mail</label>
            <input type="email" id="veiculo_unidade_email" name="veiculo_unidade_email" value="" />
        </div>
        <div class="form-field term-group">
            <label for="veiculo_unidade_endereco">Endereco</label>
            <textarea id="veiculo_unidade_endereco" name="veiculo_unidade_endereco" rows="4"></textarea>
        </div>
        <?php
    }

    public static function render_unidade_edit_fields(\WP_Term $term): void {
        $telefone = (string) get_term_meta($term->term_id, 'veiculo_unidade_telefone', true);
        $whatsapp = (string) get_term_meta($term->term_id, 'veiculo_unidade_whatsapp', true);
        $email = (string) get_term_meta($term->term_id, 'veiculo_unidade_email', true);
        $endereco = (string) get_term_meta($term->term_id, 'veiculo_unidade_endereco', true);
        ?>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_unidade_telefone">Telefone</label></th>
            <td><input type="text" id="veiculo_unidade_telefone" name="veiculo_unidade_telefone" value="<?php echo esc_attr($telefone); ?>" /></td>
        </tr>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_unidade_whatsapp">WhatsApp</label></th>
            <td><input type="text" id="veiculo_unidade_whatsapp" name="veiculo_unidade_whatsapp" value="<?php echo esc_attr($whatsapp); ?>" /></td>
        </tr>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_unidade_email">E-mail</label></th>
            <td><input type="email" id="veiculo_unidade_email" name="veiculo_unidade_email" value="<?php echo esc_attr($email); ?>" /></td>
        </tr>
        <tr class="form-field term-group-wrap">
            <th scope="row"><label for="veiculo_unidade_endereco">Endereco</label></th>
            <td><textarea id="veiculo_unidade_endereco" name="veiculo_unidade_endereco" rows="4"><?php echo esc_textarea($endereco); ?></textarea></td>
        </tr>
        <?php
    }

    public static function save_unidade_term_meta(int $term_id): void {
        if (!current_user_can('manage_categories')) {
            return;
        }
        if (isset($_POST['veiculo_unidade_telefone'])) {
            update_term_meta($term_id, 'veiculo_unidade_telefone', sanitize_text_field((string) wp_unslash($_POST['veiculo_unidade_telefone'])));
        }
        if (isset($_POST['veiculo_unidade_whatsapp'])) {
            update_term_meta($term_id, 'veiculo_unidade_whatsapp', sanitize_text_field((string) wp_unslash($_POST['veiculo_unidade_whatsapp'])));
        }
        if (isset($_POST['veiculo_unidade_email'])) {
            update_term_meta($term_id, 'veiculo_unidade_email', sanitize_email((string) wp_unslash($_POST['veiculo_unidade_email'])));
        }
        if (isset($_POST['veiculo_unidade_endereco'])) {
            update_term_meta($term_id, 'veiculo_unidade_endereco', sanitize_textarea_field((string) wp_unslash($_POST['veiculo_unidade_endereco'])));
        }
    }
}

endif;

